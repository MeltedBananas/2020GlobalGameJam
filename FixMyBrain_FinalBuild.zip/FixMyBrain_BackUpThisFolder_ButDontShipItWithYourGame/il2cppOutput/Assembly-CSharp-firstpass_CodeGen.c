﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 UnityEngine.Vector3 LTDescr::get_from()
extern void LTDescr_get_from_m78D35CDCC70785F5C6CE56BF6DACDF864A0E154A ();
// 0x00000002 System.Void LTDescr::set_from(UnityEngine.Vector3)
extern void LTDescr_set_from_mA2A3DE5FA1E580963BD8887FC1BB556C701BA046 ();
// 0x00000003 UnityEngine.Vector3 LTDescr::get_to()
extern void LTDescr_get_to_m420D67414500804A7B0ED74340739934B1162945 ();
// 0x00000004 System.Void LTDescr::set_to(UnityEngine.Vector3)
extern void LTDescr_set_to_m799273499065B010DE8C42C33364BDBA2B80525C ();
// 0x00000005 LTDescr_ActionMethodDelegate LTDescr::get_easeInternal()
extern void LTDescr_get_easeInternal_mBBB8833EF0EEC8AD819D0C80F54F4114C2DAE8BC ();
// 0x00000006 System.Void LTDescr::set_easeInternal(LTDescr_ActionMethodDelegate)
extern void LTDescr_set_easeInternal_mBE53461DC3A689CF128A6F8C8AE7C4517EB43E5F ();
// 0x00000007 LTDescr_ActionMethodDelegate LTDescr::get_initInternal()
extern void LTDescr_get_initInternal_m9E7F123BEB03ACB16022CD1BF964EE607F19098D ();
// 0x00000008 System.Void LTDescr::set_initInternal(LTDescr_ActionMethodDelegate)
extern void LTDescr_set_initInternal_mE56619A9765A443A38EB5D9B41C90BE8E87C3544 ();
// 0x00000009 System.String LTDescr::ToString()
extern void LTDescr_ToString_m4F679F79020EEF9EED34A8D005DFD7118B740835 ();
// 0x0000000A System.Void LTDescr::.ctor()
extern void LTDescr__ctor_m22626F3C47487479FC8598D285244D33D6DD4E5F ();
// 0x0000000B LTDescr LTDescr::cancel(UnityEngine.GameObject)
extern void LTDescr_cancel_mFF8E0A22B2AC338E2DB1074CF983EF32D77044D4 ();
// 0x0000000C System.Int32 LTDescr::get_uniqueId()
extern void LTDescr_get_uniqueId_mCBD2BDB9081F478DC8B369BD61F4FF868625A894 ();
// 0x0000000D System.Int32 LTDescr::get_id()
extern void LTDescr_get_id_m81AB80E07C8FE161D19F3BE9ED44A9EB359648A4 ();
// 0x0000000E LTDescrOptional LTDescr::get_optional()
extern void LTDescr_get_optional_m910B64FCD676A5C1C509CD068B72C73F7D017380 ();
// 0x0000000F System.Void LTDescr::set_optional(LTDescrOptional)
extern void LTDescr_set_optional_m0386812024A8548BFBFB30F422667703DC2435F3 ();
// 0x00000010 System.Void LTDescr::reset()
extern void LTDescr_reset_m3B0B1D4A1BECA8D5D7AFCC51A8B9225D972C7167 ();
// 0x00000011 LTDescr LTDescr::setMoveX()
extern void LTDescr_setMoveX_m402AA3712A5050D3ED582E76FD3BF9B63ECADC33 ();
// 0x00000012 LTDescr LTDescr::setMoveY()
extern void LTDescr_setMoveY_mE8954E83A49F417DA9584C3D55098C4BFB1630B2 ();
// 0x00000013 LTDescr LTDescr::setMoveZ()
extern void LTDescr_setMoveZ_mFFB63BB6A29902C4FD5F712E3152AD9676218273 ();
// 0x00000014 LTDescr LTDescr::setMoveLocalX()
extern void LTDescr_setMoveLocalX_m0D2FC50834F8E3ED915FACDBCB13548A7E6363FF ();
// 0x00000015 LTDescr LTDescr::setMoveLocalY()
extern void LTDescr_setMoveLocalY_mAFBAA07C6C9E2F72C28267FF4AC05B121A79C0BE ();
// 0x00000016 LTDescr LTDescr::setMoveLocalZ()
extern void LTDescr_setMoveLocalZ_mB89DC3E0BD11B820A8E643538652F9041A03CE9E ();
// 0x00000017 System.Void LTDescr::initFromInternal()
extern void LTDescr_initFromInternal_m8E46DBF940B0406074656914ADAAD979A9441713 ();
// 0x00000018 LTDescr LTDescr::setMoveCurved()
extern void LTDescr_setMoveCurved_mE8BFCF92727DC625340BB412A45B1A1E7A2849E0 ();
// 0x00000019 LTDescr LTDescr::setMoveCurvedLocal()
extern void LTDescr_setMoveCurvedLocal_mAABA442CDFE85B24C02EB264BBC656C5F094ED70 ();
// 0x0000001A LTDescr LTDescr::setMoveSpline()
extern void LTDescr_setMoveSpline_mB436AD3F5A8B5F84DF87C1170BEA6A729913FE98 ();
// 0x0000001B LTDescr LTDescr::setMoveSplineLocal()
extern void LTDescr_setMoveSplineLocal_mF45E817D7530DE54BBE391036060A94C260B2966 ();
// 0x0000001C LTDescr LTDescr::setScaleX()
extern void LTDescr_setScaleX_m1140E5B67917A5A402323E15630554F53C78B0CB ();
// 0x0000001D LTDescr LTDescr::setScaleY()
extern void LTDescr_setScaleY_mFB75FC6F70F2962C2B11A91839A6B98A0B3743F2 ();
// 0x0000001E LTDescr LTDescr::setScaleZ()
extern void LTDescr_setScaleZ_m55CED6D5714FFD0FAD0A64DF8B95AB363F17A444 ();
// 0x0000001F LTDescr LTDescr::setRotateX()
extern void LTDescr_setRotateX_m6800D95A85D500D68A998188501A07FBB6B47235 ();
// 0x00000020 LTDescr LTDescr::setRotateY()
extern void LTDescr_setRotateY_m2197D5E026FBD6506F43A56F1D6BC402D30184C6 ();
// 0x00000021 LTDescr LTDescr::setRotateZ()
extern void LTDescr_setRotateZ_m754F1C216FDB8D99E50A6ED80454A4EC73F9B08C ();
// 0x00000022 LTDescr LTDescr::setRotateAround()
extern void LTDescr_setRotateAround_m9448891C970D47337F40370292B2EA04C7D2D125 ();
// 0x00000023 LTDescr LTDescr::setRotateAroundLocal()
extern void LTDescr_setRotateAroundLocal_mE70C4C427853F6AB25B7A737F440DFA402E5D04C ();
// 0x00000024 LTDescr LTDescr::setAlpha()
extern void LTDescr_setAlpha_m829B4982F4B2063E01782BB3149D6C6DCEDBBE5E ();
// 0x00000025 LTDescr LTDescr::setTextAlpha()
extern void LTDescr_setTextAlpha_mCE3CEA97A82696AA35409E96311A7ECEC05AB158 ();
// 0x00000026 LTDescr LTDescr::setAlphaVertex()
extern void LTDescr_setAlphaVertex_m14D7B515A5120EC37CE0F227E10A29FFFE579906 ();
// 0x00000027 LTDescr LTDescr::setColor()
extern void LTDescr_setColor_mA286D6F2E820F2671E304CE8F67AE69CBCAD16AA ();
// 0x00000028 LTDescr LTDescr::setCallbackColor()
extern void LTDescr_setCallbackColor_m881BE50E3F047FA60488E6F8A8B121FADAC1CEEB ();
// 0x00000029 LTDescr LTDescr::setTextColor()
extern void LTDescr_setTextColor_m8C93C0044CD6E3AC6E500BBE2DDC066E2476ACD2 ();
// 0x0000002A LTDescr LTDescr::setCanvasAlpha()
extern void LTDescr_setCanvasAlpha_mDB6D99B1B524308F2890DD00600833A71FDBA425 ();
// 0x0000002B LTDescr LTDescr::setCanvasGroupAlpha()
extern void LTDescr_setCanvasGroupAlpha_m6C90EEF2B6E424F6F05F79322F176B7594C5D6E1 ();
// 0x0000002C LTDescr LTDescr::setCanvasColor()
extern void LTDescr_setCanvasColor_mE0D299B6BB0ACDE16C22301FBFBC2B3E33A188E7 ();
// 0x0000002D LTDescr LTDescr::setCanvasMoveX()
extern void LTDescr_setCanvasMoveX_mAD9EF00E8AFAA4CB582CCFBC1542227CE2D9563F ();
// 0x0000002E LTDescr LTDescr::setCanvasMoveY()
extern void LTDescr_setCanvasMoveY_mA66FEF0817CA8B95C7765D14EBEF9F14B6123DDA ();
// 0x0000002F LTDescr LTDescr::setCanvasMoveZ()
extern void LTDescr_setCanvasMoveZ_m023367C10AC010545D696532C76EF0F73842DEB0 ();
// 0x00000030 System.Void LTDescr::initCanvasRotateAround()
extern void LTDescr_initCanvasRotateAround_m47977E1F604279D9E8A71EF9F6E90CE12A6DE859 ();
// 0x00000031 LTDescr LTDescr::setCanvasRotateAround()
extern void LTDescr_setCanvasRotateAround_m4722C180A00F677807C1F2F07CD2DF8972B9907C ();
// 0x00000032 LTDescr LTDescr::setCanvasRotateAroundLocal()
extern void LTDescr_setCanvasRotateAroundLocal_m05C440234EAD0B99F97C50CF64ACA6018E4F0972 ();
// 0x00000033 LTDescr LTDescr::setCanvasPlaySprite()
extern void LTDescr_setCanvasPlaySprite_m038BB423ADE0BA5BBA3D9B02C65C071947DE0359 ();
// 0x00000034 LTDescr LTDescr::setCanvasMove()
extern void LTDescr_setCanvasMove_mA7D212EE3C5E53EF5C524635B7BDB4CD3108CEE6 ();
// 0x00000035 LTDescr LTDescr::setCanvasScale()
extern void LTDescr_setCanvasScale_m3B3BFD433039C9E8D0FC6AF0F52724BF556A4BDA ();
// 0x00000036 LTDescr LTDescr::setCanvasSizeDelta()
extern void LTDescr_setCanvasSizeDelta_m31D8FA820C50854450973EDEF4E445001C7AD28F ();
// 0x00000037 System.Void LTDescr::callback()
extern void LTDescr_callback_m46ECDAC987FEFF56067D681A449D0330985FF184 ();
// 0x00000038 LTDescr LTDescr::setCallback()
extern void LTDescr_setCallback_m463C7BDB21E12791E7F3E889E64E1E1051F66D49 ();
// 0x00000039 LTDescr LTDescr::setValue3()
extern void LTDescr_setValue3_mA3FE29090505B900E5E6C9E698B56293E240B12E ();
// 0x0000003A LTDescr LTDescr::setMove()
extern void LTDescr_setMove_m98F1C5B0C7C06F382A36E756F189E1BC94B1F95B ();
// 0x0000003B LTDescr LTDescr::setMoveLocal()
extern void LTDescr_setMoveLocal_m7D80BDEE0E8BD25C55C798468075C5FF4B57EE07 ();
// 0x0000003C LTDescr LTDescr::setMoveToTransform()
extern void LTDescr_setMoveToTransform_mAD20C37E6D479457C9BE547691BDDE1F9CA8AAF0 ();
// 0x0000003D LTDescr LTDescr::setRotate()
extern void LTDescr_setRotate_mA209146FC88C0126CE850B881A87AD68DB3A7F3C ();
// 0x0000003E LTDescr LTDescr::setRotateLocal()
extern void LTDescr_setRotateLocal_mAA715477CA9552F98306851AED9C58C31E9DA689 ();
// 0x0000003F LTDescr LTDescr::setScale()
extern void LTDescr_setScale_mEB70D47029BC79C6A0A5D33A98937CFC5ABC1E63 ();
// 0x00000040 LTDescr LTDescr::setGUIMove()
extern void LTDescr_setGUIMove_m78172C786814BBBD344FE33104E90544164BBF0D ();
// 0x00000041 LTDescr LTDescr::setGUIMoveMargin()
extern void LTDescr_setGUIMoveMargin_mD5D3EEAF5C7B92694544E17744A04F49DED52454 ();
// 0x00000042 LTDescr LTDescr::setGUIScale()
extern void LTDescr_setGUIScale_m8055CF760F5CFC4A374E8351EF4BB0510CA1D513 ();
// 0x00000043 LTDescr LTDescr::setGUIAlpha()
extern void LTDescr_setGUIAlpha_m7E6CB2E4D723C524BC091534DAD4F001288F2DB0 ();
// 0x00000044 LTDescr LTDescr::setGUIRotate()
extern void LTDescr_setGUIRotate_m6D458F3704FEB5AA2E03A4339C567E5C0D99E31C ();
// 0x00000045 LTDescr LTDescr::setDelayedSound()
extern void LTDescr_setDelayedSound_m08D11FD19D6344CCC54F9D7B33CF4DB9EB610D45 ();
// 0x00000046 System.Void LTDescr::init()
extern void LTDescr_init_m81950E0D1693101E6609FD57477A95DDFFB8AEF2 ();
// 0x00000047 System.Void LTDescr::initSpeed()
extern void LTDescr_initSpeed_m59165798AE9820491F8857C33893E5033E2E8A45 ();
// 0x00000048 LTDescr LTDescr::updateNow()
extern void LTDescr_updateNow_m848259F413F180D1F59848D23B0F718B18227DB6 ();
// 0x00000049 System.Boolean LTDescr::updateInternal()
extern void LTDescr_updateInternal_m7B9FB2E5DE2570A84047211EE3E5281B0801AA7D ();
// 0x0000004A System.Void LTDescr::callOnCompletes()
extern void LTDescr_callOnCompletes_mE439CCB47B45169210C537E36561CF64F4330736 ();
// 0x0000004B LTDescr LTDescr::setFromColor(UnityEngine.Color)
extern void LTDescr_setFromColor_m35481AA1A2866C74F7FA16BED58FA6A22B25D8D9 ();
// 0x0000004C System.Void LTDescr::alphaRecursive(UnityEngine.Transform,System.Single,System.Boolean)
extern void LTDescr_alphaRecursive_m986E47DD08566B89873BA8EB49B5779EF3A104F0 ();
// 0x0000004D System.Void LTDescr::colorRecursive(UnityEngine.Transform,UnityEngine.Color,System.Boolean)
extern void LTDescr_colorRecursive_m2DC4704B9D940297192C2F5372E85C3C9C4AD1E6 ();
// 0x0000004E System.Void LTDescr::alphaRecursive(UnityEngine.RectTransform,System.Single,System.Int32)
extern void LTDescr_alphaRecursive_m4D75C97463DA1F1E3C045853F451FC102074E7E8 ();
// 0x0000004F System.Void LTDescr::alphaRecursiveSprite(UnityEngine.Transform,System.Single)
extern void LTDescr_alphaRecursiveSprite_mC46FCB3AD0F777D8DBF0A7EA8DC4D17710EDD4A3 ();
// 0x00000050 System.Void LTDescr::colorRecursiveSprite(UnityEngine.Transform,UnityEngine.Color)
extern void LTDescr_colorRecursiveSprite_m0A52BBFBB1FA0AB3844D5BBAD0F48BDC34231393 ();
// 0x00000051 System.Void LTDescr::colorRecursive(UnityEngine.RectTransform,UnityEngine.Color)
extern void LTDescr_colorRecursive_m47C878C8399404D538E30939F1DDBC6AD76CE725 ();
// 0x00000052 System.Void LTDescr::textAlphaChildrenRecursive(UnityEngine.Transform,System.Single,System.Boolean)
extern void LTDescr_textAlphaChildrenRecursive_m16EF87F680E7AB2CC466F8507C26C4F0D73323E5 ();
// 0x00000053 System.Void LTDescr::textAlphaRecursive(UnityEngine.Transform,System.Single,System.Boolean)
extern void LTDescr_textAlphaRecursive_m26865107C9DEECA24A4D89CC111033A67B8A8D18 ();
// 0x00000054 System.Void LTDescr::textColorRecursive(UnityEngine.Transform,UnityEngine.Color)
extern void LTDescr_textColorRecursive_m8F3C7D2B0FE5AFEEE0E17E774887AAA8ACAE6C00 ();
// 0x00000055 UnityEngine.Color LTDescr::tweenColor(LTDescr,System.Single)
extern void LTDescr_tweenColor_m5165F9B2E6EBADFDAA730B2B15188AC10A9B8BCD ();
// 0x00000056 LTDescr LTDescr::pause()
extern void LTDescr_pause_mE89497C343C0F4D95B265DE7262A25E836E0F4E2 ();
// 0x00000057 LTDescr LTDescr::resume()
extern void LTDescr_resume_mC1535DDB45FBBEB15F31110F7398EBDB762D5EEF ();
// 0x00000058 LTDescr LTDescr::setAxis(UnityEngine.Vector3)
extern void LTDescr_setAxis_mBD4316513D9DEE6FED4F3FFC01AAB16C6D671C7B ();
// 0x00000059 LTDescr LTDescr::setDelay(System.Single)
extern void LTDescr_setDelay_m17C575E82E7ECB6111AE6124BD177A2A5F97C6FB ();
// 0x0000005A LTDescr LTDescr::setEase(LeanTweenType)
extern void LTDescr_setEase_m7B66587D7B2A0B4B65F2FB78BA2B5E26C688D301 ();
// 0x0000005B LTDescr LTDescr::setEaseLinear()
extern void LTDescr_setEaseLinear_m54F00A11167F1B04E0D1A2C1C7A438EEA31061B6 ();
// 0x0000005C LTDescr LTDescr::setEaseSpring()
extern void LTDescr_setEaseSpring_m813031BE3866C204428395FE7E4144540FA884EF ();
// 0x0000005D LTDescr LTDescr::setEaseInQuad()
extern void LTDescr_setEaseInQuad_mA097964ACE48F45F234C5F2ED1037A6F53AA6C27 ();
// 0x0000005E LTDescr LTDescr::setEaseOutQuad()
extern void LTDescr_setEaseOutQuad_m9EC32659C4A5DCE1A0B2F3217876E52DEC19B21B ();
// 0x0000005F LTDescr LTDescr::setEaseInOutQuad()
extern void LTDescr_setEaseInOutQuad_mC44A80958D233577C043C8E0FE57497C0D23123A ();
// 0x00000060 LTDescr LTDescr::setEaseInCubic()
extern void LTDescr_setEaseInCubic_m19A5750D6ACE144DFC2B11B26FA2AAE069B46262 ();
// 0x00000061 LTDescr LTDescr::setEaseOutCubic()
extern void LTDescr_setEaseOutCubic_mE4CFCA71B600BE22ADE6FF47ED415E762A348FBB ();
// 0x00000062 LTDescr LTDescr::setEaseInOutCubic()
extern void LTDescr_setEaseInOutCubic_mD01FBD63A0C967050CAD77057B209CF9F6191134 ();
// 0x00000063 LTDescr LTDescr::setEaseInQuart()
extern void LTDescr_setEaseInQuart_m6056CCCFB1813FEBC597DA15A53EA2FCAE7FE2AF ();
// 0x00000064 LTDescr LTDescr::setEaseOutQuart()
extern void LTDescr_setEaseOutQuart_mFC521D3DE137DCAB7F1CE063F7540DF360E1D999 ();
// 0x00000065 LTDescr LTDescr::setEaseInOutQuart()
extern void LTDescr_setEaseInOutQuart_mDC47FB39F8E6ED5CA7CD9055BE38F8522D2AF948 ();
// 0x00000066 LTDescr LTDescr::setEaseInQuint()
extern void LTDescr_setEaseInQuint_mB05AE487A295E2488C79B4AD74F8D0ED52DDE241 ();
// 0x00000067 LTDescr LTDescr::setEaseOutQuint()
extern void LTDescr_setEaseOutQuint_m9CEE0F934808B802AABE6AB8CAF09B6DAE958F8E ();
// 0x00000068 LTDescr LTDescr::setEaseInOutQuint()
extern void LTDescr_setEaseInOutQuint_m41949483F235FE3F4A73C43E80CA5EF0977DE7DC ();
// 0x00000069 LTDescr LTDescr::setEaseInSine()
extern void LTDescr_setEaseInSine_mD85621F8246B6A61D79CA27A226B5FE7166CF4C3 ();
// 0x0000006A LTDescr LTDescr::setEaseOutSine()
extern void LTDescr_setEaseOutSine_m45532255622E889E6AB63FF652C3FF342588C46A ();
// 0x0000006B LTDescr LTDescr::setEaseInOutSine()
extern void LTDescr_setEaseInOutSine_m9AB3C9E802D35012D708D71787A4659C7FA61C78 ();
// 0x0000006C LTDescr LTDescr::setEaseInExpo()
extern void LTDescr_setEaseInExpo_mCA94F6EBDCD664F85721E529016FFE2207DF4D56 ();
// 0x0000006D LTDescr LTDescr::setEaseOutExpo()
extern void LTDescr_setEaseOutExpo_m42DAB1DF8CD2DE65D23F9B4CBF5BECF84D993338 ();
// 0x0000006E LTDescr LTDescr::setEaseInOutExpo()
extern void LTDescr_setEaseInOutExpo_m0655C5D6536F4E4D8133AC773FB855FD69CE8601 ();
// 0x0000006F LTDescr LTDescr::setEaseInCirc()
extern void LTDescr_setEaseInCirc_m270A3181AF137B8C844EE3E1D19D9976D75147A7 ();
// 0x00000070 LTDescr LTDescr::setEaseOutCirc()
extern void LTDescr_setEaseOutCirc_m37ADA9FAB0D04C3A02D0984EA19243302FADB8B9 ();
// 0x00000071 LTDescr LTDescr::setEaseInOutCirc()
extern void LTDescr_setEaseInOutCirc_mC577B629AB997F700B3471D6C0AA6B475D786490 ();
// 0x00000072 LTDescr LTDescr::setEaseInBounce()
extern void LTDescr_setEaseInBounce_m3CDAC77964FC337FE22D6F6B6AB59A2D9F4D2861 ();
// 0x00000073 LTDescr LTDescr::setEaseOutBounce()
extern void LTDescr_setEaseOutBounce_m9159FC0EC260819215E356BE03BD28B4D12E65D3 ();
// 0x00000074 LTDescr LTDescr::setEaseInOutBounce()
extern void LTDescr_setEaseInOutBounce_m74F9B21439AFB4A6739AAC9EE85EACA8A0E36056 ();
// 0x00000075 LTDescr LTDescr::setEaseInBack()
extern void LTDescr_setEaseInBack_m96C8AB183C1EFA6BF49476E617863F0DE05CF2C8 ();
// 0x00000076 LTDescr LTDescr::setEaseOutBack()
extern void LTDescr_setEaseOutBack_mDD43652F56DF575D17928B384373D105384EF0C2 ();
// 0x00000077 LTDescr LTDescr::setEaseInOutBack()
extern void LTDescr_setEaseInOutBack_m246AB15A49AF3C62EA9F9587867FDEABE45A0D52 ();
// 0x00000078 LTDescr LTDescr::setEaseInElastic()
extern void LTDescr_setEaseInElastic_m90B4ECA35E49E37787DF96800FD855CA4E7ECE76 ();
// 0x00000079 LTDescr LTDescr::setEaseOutElastic()
extern void LTDescr_setEaseOutElastic_m24CC0CF30EE6D3A083B37A9AC206A66A7485F8AB ();
// 0x0000007A LTDescr LTDescr::setEaseInOutElastic()
extern void LTDescr_setEaseInOutElastic_m6F8CE494EFAC887A2B794E3A0E27AD0E7AADA726 ();
// 0x0000007B LTDescr LTDescr::setEasePunch()
extern void LTDescr_setEasePunch_m79DB407F1E11BAEA43ACF288F8E7586B2A7D5B00 ();
// 0x0000007C LTDescr LTDescr::setEaseShake()
extern void LTDescr_setEaseShake_m333BFD09A98BD76134E18DDCDE914E72843F58B9 ();
// 0x0000007D UnityEngine.Vector3 LTDescr::tweenOnCurve()
extern void LTDescr_tweenOnCurve_mCD59533C5731F409AC279B1811EED54E49411A67 ();
// 0x0000007E UnityEngine.Vector3 LTDescr::easeInOutQuad()
extern void LTDescr_easeInOutQuad_m6915DDAD37762681D5AD14BA399C455B5C11BD7A ();
// 0x0000007F UnityEngine.Vector3 LTDescr::easeInQuad()
extern void LTDescr_easeInQuad_m60D0ED9140AB90832338F7E2062F3E0760509048 ();
// 0x00000080 UnityEngine.Vector3 LTDescr::easeOutQuad()
extern void LTDescr_easeOutQuad_mCF7D63D6090F492162F9B5C17D56FE36DDD83A24 ();
// 0x00000081 UnityEngine.Vector3 LTDescr::easeLinear()
extern void LTDescr_easeLinear_m22F31F2A8634CD3FB1D6E238E6F6DB33BA98B866 ();
// 0x00000082 UnityEngine.Vector3 LTDescr::easeSpring()
extern void LTDescr_easeSpring_m5F2EBD9FFC333CFC978A49FE77D81BFF643396B4 ();
// 0x00000083 UnityEngine.Vector3 LTDescr::easeInCubic()
extern void LTDescr_easeInCubic_m0B740991790EAF32CD91DE076C4CBF0297512608 ();
// 0x00000084 UnityEngine.Vector3 LTDescr::easeOutCubic()
extern void LTDescr_easeOutCubic_m0AD929484DB35F292F299C0DF8DA4282A60FE333 ();
// 0x00000085 UnityEngine.Vector3 LTDescr::easeInOutCubic()
extern void LTDescr_easeInOutCubic_mAB1FAACFBE99695FB0119C8B44B4F66E0E66CF6E ();
// 0x00000086 UnityEngine.Vector3 LTDescr::easeInQuart()
extern void LTDescr_easeInQuart_m6B35D5660B4A98E968E60355F56BF216DAF343AB ();
// 0x00000087 UnityEngine.Vector3 LTDescr::easeOutQuart()
extern void LTDescr_easeOutQuart_mC97B6E5DB20D3464395A40A83CA344C3A89A54E0 ();
// 0x00000088 UnityEngine.Vector3 LTDescr::easeInOutQuart()
extern void LTDescr_easeInOutQuart_m996E4A8C5B440A365092702098D1B407FAD12FF0 ();
// 0x00000089 UnityEngine.Vector3 LTDescr::easeInQuint()
extern void LTDescr_easeInQuint_m65CAACB87841DC6A3201ABB58FAA2D292C551047 ();
// 0x0000008A UnityEngine.Vector3 LTDescr::easeOutQuint()
extern void LTDescr_easeOutQuint_mDA4580526D49B9A10AB75415F531CF8790AE3290 ();
// 0x0000008B UnityEngine.Vector3 LTDescr::easeInOutQuint()
extern void LTDescr_easeInOutQuint_m2F45C6D073399C6171076FB42B99A558D9A86F43 ();
// 0x0000008C UnityEngine.Vector3 LTDescr::easeInSine()
extern void LTDescr_easeInSine_m882A92BAC86E20686430D3770867E0B88BD8C2E0 ();
// 0x0000008D UnityEngine.Vector3 LTDescr::easeOutSine()
extern void LTDescr_easeOutSine_m3C01F288C50CB37FBA90308D63554C3A7783E1FB ();
// 0x0000008E UnityEngine.Vector3 LTDescr::easeInOutSine()
extern void LTDescr_easeInOutSine_m76B06B8A875131BAB7D62957A201B5B0B0587112 ();
// 0x0000008F UnityEngine.Vector3 LTDescr::easeInExpo()
extern void LTDescr_easeInExpo_mB5CC53F9BAAF2965E1821C435F253CD4A557430C ();
// 0x00000090 UnityEngine.Vector3 LTDescr::easeOutExpo()
extern void LTDescr_easeOutExpo_m14C739205653FEDD99DEC5BED4128CFA16DD56E7 ();
// 0x00000091 UnityEngine.Vector3 LTDescr::easeInOutExpo()
extern void LTDescr_easeInOutExpo_mC49A98ED2F7A9AAAFAA440D49D9B053ED07943F1 ();
// 0x00000092 UnityEngine.Vector3 LTDescr::easeInCirc()
extern void LTDescr_easeInCirc_mA145A08F12DF33F8C2B47D587CB7187F545E5450 ();
// 0x00000093 UnityEngine.Vector3 LTDescr::easeOutCirc()
extern void LTDescr_easeOutCirc_m33DF496165252D0DF90C23DDBC115A9F4652925A ();
// 0x00000094 UnityEngine.Vector3 LTDescr::easeInOutCirc()
extern void LTDescr_easeInOutCirc_mC78C97B3570955DD6905542172ADA750C8AB6595 ();
// 0x00000095 UnityEngine.Vector3 LTDescr::easeInBounce()
extern void LTDescr_easeInBounce_m2AE600AA25490CE419B699F36BDB0C42BE631905 ();
// 0x00000096 UnityEngine.Vector3 LTDescr::easeOutBounce()
extern void LTDescr_easeOutBounce_m3DF1745F1CB4C447195CFB9BB6B89FF343F0CD15 ();
// 0x00000097 UnityEngine.Vector3 LTDescr::easeInOutBounce()
extern void LTDescr_easeInOutBounce_mA95D061538FACCE8B9580B132A67782F49367927 ();
// 0x00000098 UnityEngine.Vector3 LTDescr::easeInBack()
extern void LTDescr_easeInBack_m108ABEB0A39FF07E3AEC96D6B48B49811D9C7B67 ();
// 0x00000099 UnityEngine.Vector3 LTDescr::easeOutBack()
extern void LTDescr_easeOutBack_m9AD5A6FCDB0ED16836B0B3F57218C26E0AA35540 ();
// 0x0000009A UnityEngine.Vector3 LTDescr::easeInOutBack()
extern void LTDescr_easeInOutBack_m4704847A8B6231D28D509347F4C204A5BABCD0F1 ();
// 0x0000009B UnityEngine.Vector3 LTDescr::easeInElastic()
extern void LTDescr_easeInElastic_mDBFEBBF8886813E812F4C1E6951CD6ADB1F0637E ();
// 0x0000009C UnityEngine.Vector3 LTDescr::easeOutElastic()
extern void LTDescr_easeOutElastic_mFC227E235F6FF91CC1F1C0CB0FEF5DF699E3B9C6 ();
// 0x0000009D UnityEngine.Vector3 LTDescr::easeInOutElastic()
extern void LTDescr_easeInOutElastic_mD2B6C86443DD08280120CD1FCE24CA8A4653D3AE ();
// 0x0000009E LTDescr LTDescr::setOvershoot(System.Single)
extern void LTDescr_setOvershoot_m525737132ABCF1F06AE299DAC8341821CBB54F85 ();
// 0x0000009F LTDescr LTDescr::setPeriod(System.Single)
extern void LTDescr_setPeriod_m5DAEA4417D899D633A921AE75F46C08D4E97D6D1 ();
// 0x000000A0 LTDescr LTDescr::setScale(System.Single)
extern void LTDescr_setScale_m0D8B00C154BD5E1F9B6D5B3751E268F200BF1E1E ();
// 0x000000A1 LTDescr LTDescr::setEase(UnityEngine.AnimationCurve)
extern void LTDescr_setEase_mA13966EB89C908BA73460AD6C2980665FF95FDEB ();
// 0x000000A2 LTDescr LTDescr::setTo(UnityEngine.Vector3)
extern void LTDescr_setTo_m433F36B84399D346E2A40E690AA2470F39198C74 ();
// 0x000000A3 LTDescr LTDescr::setTo(UnityEngine.Transform)
extern void LTDescr_setTo_mE356E82135AC20DFAE86DED349E09552BF1CDC3D ();
// 0x000000A4 LTDescr LTDescr::setFrom(UnityEngine.Vector3)
extern void LTDescr_setFrom_m0DE294DF15BCF3D81F0716A0BEA8C5D7267AA398 ();
// 0x000000A5 LTDescr LTDescr::setFrom(System.Single)
extern void LTDescr_setFrom_m97150B1C1A1FB7B52FDD4F536CED64487B766FE9 ();
// 0x000000A6 LTDescr LTDescr::setDiff(UnityEngine.Vector3)
extern void LTDescr_setDiff_m66354480512FEE628959E9D1A07B680E3D7A3168 ();
// 0x000000A7 LTDescr LTDescr::setHasInitialized(System.Boolean)
extern void LTDescr_setHasInitialized_mF24ED2AB3F981B9CF3102C9E85D94547B461A066 ();
// 0x000000A8 LTDescr LTDescr::setId(System.UInt32,System.UInt32)
extern void LTDescr_setId_m71293A9DB7751FDD4F4149E4A5D0ABF3E1FAE22A ();
// 0x000000A9 LTDescr LTDescr::setPassed(System.Single)
extern void LTDescr_setPassed_m2E6EEE58EBE05E1E7A49A100AC6FC28094F2233A ();
// 0x000000AA LTDescr LTDescr::setTime(System.Single)
extern void LTDescr_setTime_mFA06A0D5CC2F72B8D647693B65F91BE6A9F7CAC9 ();
// 0x000000AB LTDescr LTDescr::setSpeed(System.Single)
extern void LTDescr_setSpeed_mCFABDDF7947D3A8987BB3A73B3F92A126EB0EC21 ();
// 0x000000AC LTDescr LTDescr::setRepeat(System.Int32)
extern void LTDescr_setRepeat_m6F11E6A632B830938240EEE78D85570289050025 ();
// 0x000000AD LTDescr LTDescr::setLoopType(LeanTweenType)
extern void LTDescr_setLoopType_mA482E7E3DCF74FB08432C8A5E3D52FB52453DA9B ();
// 0x000000AE LTDescr LTDescr::setUseEstimatedTime(System.Boolean)
extern void LTDescr_setUseEstimatedTime_mA51B6D8A0C1425D4D05C4E4CE7CF27759B70E753 ();
// 0x000000AF LTDescr LTDescr::setIgnoreTimeScale(System.Boolean)
extern void LTDescr_setIgnoreTimeScale_mB7978E3F0EB37FB5E2B49E2618F1917EB576BA28 ();
// 0x000000B0 LTDescr LTDescr::setUseFrames(System.Boolean)
extern void LTDescr_setUseFrames_mCF0E71BA4203563896DCDB058C731D216AF04F9E ();
// 0x000000B1 LTDescr LTDescr::setUseManualTime(System.Boolean)
extern void LTDescr_setUseManualTime_mAE5B2628CA1FEE9E546BBF0E8D69B88598071BD3 ();
// 0x000000B2 LTDescr LTDescr::setLoopCount(System.Int32)
extern void LTDescr_setLoopCount_m0F81199444BDBE9D6FEF24CB5874F33C5AA8A3E5 ();
// 0x000000B3 LTDescr LTDescr::setLoopOnce()
extern void LTDescr_setLoopOnce_m5B7B9509895ECDBDB6447E5C5429887E46CD146D ();
// 0x000000B4 LTDescr LTDescr::setLoopClamp()
extern void LTDescr_setLoopClamp_m265DE6025C2B4B2A2E9405CBD795CAB41640EE99 ();
// 0x000000B5 LTDescr LTDescr::setLoopClamp(System.Int32)
extern void LTDescr_setLoopClamp_m170890F9038A9350A78DE676B6C210ED8D6C4552 ();
// 0x000000B6 LTDescr LTDescr::setLoopPingPong()
extern void LTDescr_setLoopPingPong_mA960C0FC617354580B8AD52D96E7630F693B91E5 ();
// 0x000000B7 LTDescr LTDescr::setLoopPingPong(System.Int32)
extern void LTDescr_setLoopPingPong_m500A08D4CC2FCACBF82463C72196849CC180DDDB ();
// 0x000000B8 LTDescr LTDescr::setOnComplete(System.Action)
extern void LTDescr_setOnComplete_m8CCAE85BD9176574E1688DF1817703FE826ADEA7 ();
// 0x000000B9 LTDescr LTDescr::setOnComplete(System.Action`1<System.Object>)
extern void LTDescr_setOnComplete_m913F7B4D1C1478C120B985F6A4F628C13B514ECE ();
// 0x000000BA LTDescr LTDescr::setOnComplete(System.Action`1<System.Object>,System.Object)
extern void LTDescr_setOnComplete_m2D04A5093C8EC0942F23FDA55B3958DA9FFA4A27 ();
// 0x000000BB LTDescr LTDescr::setOnCompleteParam(System.Object)
extern void LTDescr_setOnCompleteParam_mF03EC9B6BCCE1A13DF1435286E6B84A3CD24F2A2 ();
// 0x000000BC LTDescr LTDescr::setOnUpdate(System.Action`1<System.Single>)
extern void LTDescr_setOnUpdate_mD514424805DE6AA444AAFFB2A78849DC2ED24F83 ();
// 0x000000BD LTDescr LTDescr::setOnUpdateRatio(System.Action`2<System.Single,System.Single>)
extern void LTDescr_setOnUpdateRatio_m9C63BD592F642592526BCF414DF9CA394C7D8D77 ();
// 0x000000BE LTDescr LTDescr::setOnUpdateObject(System.Action`2<System.Single,System.Object>)
extern void LTDescr_setOnUpdateObject_mC12BB1EB2ED48C4BC3762BB5D6346B7D4317FDD4 ();
// 0x000000BF LTDescr LTDescr::setOnUpdateVector2(System.Action`1<UnityEngine.Vector2>)
extern void LTDescr_setOnUpdateVector2_m5032D644DDD7E79878C37EE96433C4A7F0993F46 ();
// 0x000000C0 LTDescr LTDescr::setOnUpdateVector3(System.Action`1<UnityEngine.Vector3>)
extern void LTDescr_setOnUpdateVector3_mFDDE049C7826037515B167E499C57C6E54320944 ();
// 0x000000C1 LTDescr LTDescr::setOnUpdateColor(System.Action`1<UnityEngine.Color>)
extern void LTDescr_setOnUpdateColor_m866743E527099E21D0C5DBF5784BE36533C87D90 ();
// 0x000000C2 LTDescr LTDescr::setOnUpdateColor(System.Action`2<UnityEngine.Color,System.Object>)
extern void LTDescr_setOnUpdateColor_m38AA50CE34255E6E4693B8053BF96DF7159AC593 ();
// 0x000000C3 LTDescr LTDescr::setOnUpdate(System.Action`1<UnityEngine.Color>)
extern void LTDescr_setOnUpdate_m26FD3B633FD2FF9942B260148B862AB1C04286BF ();
// 0x000000C4 LTDescr LTDescr::setOnUpdate(System.Action`2<UnityEngine.Color,System.Object>)
extern void LTDescr_setOnUpdate_m1BD910E3D340D0AF60000EAF245DACF1AAF26BE0 ();
// 0x000000C5 LTDescr LTDescr::setOnUpdate(System.Action`2<System.Single,System.Object>,System.Object)
extern void LTDescr_setOnUpdate_m4B784572E92AC1F3CA32AB49F2B8C2097D38B911 ();
// 0x000000C6 LTDescr LTDescr::setOnUpdate(System.Action`2<UnityEngine.Vector3,System.Object>,System.Object)
extern void LTDescr_setOnUpdate_mFB6DF3C34A17C6FAA89280381A932046675CAC97 ();
// 0x000000C7 LTDescr LTDescr::setOnUpdate(System.Action`1<UnityEngine.Vector2>,System.Object)
extern void LTDescr_setOnUpdate_mE4F309BB9AE4DD798DDDB74C46A62346B8D11F41 ();
// 0x000000C8 LTDescr LTDescr::setOnUpdate(System.Action`1<UnityEngine.Vector3>,System.Object)
extern void LTDescr_setOnUpdate_mF5476AC35CEA5E4A91B716221D72EE04F4F5ECD1 ();
// 0x000000C9 LTDescr LTDescr::setOnUpdateParam(System.Object)
extern void LTDescr_setOnUpdateParam_mAADE496BF612EC4AEA8BB56EC878EB3769C6EEC4 ();
// 0x000000CA LTDescr LTDescr::setOrientToPath(System.Boolean)
extern void LTDescr_setOrientToPath_mFD37EA5A564665BF6BD9AC5C2D8A3405ADAC784D ();
// 0x000000CB LTDescr LTDescr::setOrientToPath2d(System.Boolean)
extern void LTDescr_setOrientToPath2d_m908CDD2CBF70CCF0D0AA49FD6848A5C7D77DB7AF ();
// 0x000000CC LTDescr LTDescr::setRect(LTRect)
extern void LTDescr_setRect_mB36958D5E6ABEA6C05543F3C6752567BA3603B32 ();
// 0x000000CD LTDescr LTDescr::setRect(UnityEngine.Rect)
extern void LTDescr_setRect_mA2191EFB70E1C5308150D780D7450D85C7CE15A3 ();
// 0x000000CE LTDescr LTDescr::setPath(LTBezierPath)
extern void LTDescr_setPath_m889A9ADA196043CB42E95A9A936F548EAE9430E7 ();
// 0x000000CF LTDescr LTDescr::setPoint(UnityEngine.Vector3)
extern void LTDescr_setPoint_m4473549864A9D2376DCC8D97395918A2B69BEC4C ();
// 0x000000D0 LTDescr LTDescr::setDestroyOnComplete(System.Boolean)
extern void LTDescr_setDestroyOnComplete_mFBD0151333DF8D264FC48CF071254C32A3BDAE2C ();
// 0x000000D1 LTDescr LTDescr::setAudio(System.Object)
extern void LTDescr_setAudio_mC30B114290D0874D38424A5A1DA0BDB411EC9214 ();
// 0x000000D2 LTDescr LTDescr::setOnCompleteOnRepeat(System.Boolean)
extern void LTDescr_setOnCompleteOnRepeat_mDCF46E8952AC831263CCC7850D4A0498914A090D ();
// 0x000000D3 LTDescr LTDescr::setOnCompleteOnStart(System.Boolean)
extern void LTDescr_setOnCompleteOnStart_m111620D91E0BE6A1C1009C57884083EF75B9CE65 ();
// 0x000000D4 LTDescr LTDescr::setRect(UnityEngine.RectTransform)
extern void LTDescr_setRect_m428F8D578582E8C44D09350725F8B4718D04206B ();
// 0x000000D5 LTDescr LTDescr::setSprites(UnityEngine.Sprite[])
extern void LTDescr_setSprites_m69FF53F8CFDFBC25B5940404DD6E75F2626DB349 ();
// 0x000000D6 LTDescr LTDescr::setFrameRate(System.Single)
extern void LTDescr_setFrameRate_mCF4AF5480041DFFC23EC4D3C7329AF8C317A64C0 ();
// 0x000000D7 LTDescr LTDescr::setOnStart(System.Action)
extern void LTDescr_setOnStart_m2E090D8059E042E0834ED71BEFA3556EE4CD6B42 ();
// 0x000000D8 LTDescr LTDescr::setDirection(System.Single)
extern void LTDescr_setDirection_m2D6D65172541E380FAB24CEB37FF8DCABFF7A4AA ();
// 0x000000D9 LTDescr LTDescr::setRecursive(System.Boolean)
extern void LTDescr_setRecursive_m3A95FC34AE2FE034F0072826A89A6C23E6DC2322 ();
// 0x000000DA System.Void LTDescr::<setMoveX>b__70_0()
extern void LTDescr_U3CsetMoveXU3Eb__70_0_m85C392B96D7E1B178B73802FB0D7C4B439ABA9E6 ();
// 0x000000DB System.Void LTDescr::<setMoveX>b__70_1()
extern void LTDescr_U3CsetMoveXU3Eb__70_1_m972223FF7D3A9C131D84F9E5AC4B63CBA2F570B0 ();
// 0x000000DC System.Void LTDescr::<setMoveY>b__71_0()
extern void LTDescr_U3CsetMoveYU3Eb__71_0_m17335CB64369BAA75406D8E4272CF3BBB224D5D7 ();
// 0x000000DD System.Void LTDescr::<setMoveY>b__71_1()
extern void LTDescr_U3CsetMoveYU3Eb__71_1_m4C43AAF6D5B100847A8B3800367145225981F5C1 ();
// 0x000000DE System.Void LTDescr::<setMoveZ>b__72_0()
extern void LTDescr_U3CsetMoveZU3Eb__72_0_m23D516C7A444B95FC5B0008F99733F63BC9D9B17 ();
// 0x000000DF System.Void LTDescr::<setMoveZ>b__72_1()
extern void LTDescr_U3CsetMoveZU3Eb__72_1_m3C02F77150F08A01F24FBFEBAE443F8C64BD0327 ();
// 0x000000E0 System.Void LTDescr::<setMoveLocalX>b__73_0()
extern void LTDescr_U3CsetMoveLocalXU3Eb__73_0_mA38CD11B83777D4C8CFEF57539F16437861DE022 ();
// 0x000000E1 System.Void LTDescr::<setMoveLocalX>b__73_1()
extern void LTDescr_U3CsetMoveLocalXU3Eb__73_1_m14B32D48CE791E7CD1BF892EDB9B351BEE6AFB76 ();
// 0x000000E2 System.Void LTDescr::<setMoveLocalY>b__74_0()
extern void LTDescr_U3CsetMoveLocalYU3Eb__74_0_m82FC4978CE3DEFA7F0B403EA8E9A2D7A5F35F365 ();
// 0x000000E3 System.Void LTDescr::<setMoveLocalY>b__74_1()
extern void LTDescr_U3CsetMoveLocalYU3Eb__74_1_m693EBBBC819D71F5DC98BD390143D077B2DA3BAD ();
// 0x000000E4 System.Void LTDescr::<setMoveLocalZ>b__75_0()
extern void LTDescr_U3CsetMoveLocalZU3Eb__75_0_m5370A512055F9E14A4CE8A2D8143C6EA77550043 ();
// 0x000000E5 System.Void LTDescr::<setMoveLocalZ>b__75_1()
extern void LTDescr_U3CsetMoveLocalZU3Eb__75_1_m8057F793A4A29FC64C63A5A3D5FC4783EDDA7D34 ();
// 0x000000E6 System.Void LTDescr::<setMoveCurved>b__77_0()
extern void LTDescr_U3CsetMoveCurvedU3Eb__77_0_m90B4D2CA5DE78923748639A144A0F9BC949305E7 ();
// 0x000000E7 System.Void LTDescr::<setMoveCurvedLocal>b__78_0()
extern void LTDescr_U3CsetMoveCurvedLocalU3Eb__78_0_m90A308A70E3A100F47AD90544DDA979ED75A5560 ();
// 0x000000E8 System.Void LTDescr::<setMoveSpline>b__79_0()
extern void LTDescr_U3CsetMoveSplineU3Eb__79_0_m8B9A7880D890F5C39AA2071877727F57145D442A ();
// 0x000000E9 System.Void LTDescr::<setMoveSplineLocal>b__80_0()
extern void LTDescr_U3CsetMoveSplineLocalU3Eb__80_0_m2FC95069246D8E725D0C63C744DF2479DA0BB82B ();
// 0x000000EA System.Void LTDescr::<setScaleX>b__81_0()
extern void LTDescr_U3CsetScaleXU3Eb__81_0_m043E36F6F194FCB4507FE0ED0B8EE88E46A06253 ();
// 0x000000EB System.Void LTDescr::<setScaleX>b__81_1()
extern void LTDescr_U3CsetScaleXU3Eb__81_1_m03D45F62F977B9C1904A77191CAC9EF71C620AC9 ();
// 0x000000EC System.Void LTDescr::<setScaleY>b__82_0()
extern void LTDescr_U3CsetScaleYU3Eb__82_0_m9A55E680C128B917D929321FEBA977E2EE25AF7C ();
// 0x000000ED System.Void LTDescr::<setScaleY>b__82_1()
extern void LTDescr_U3CsetScaleYU3Eb__82_1_m16C789DF8D3793E2723781CBA4A52E02A3F818D6 ();
// 0x000000EE System.Void LTDescr::<setScaleZ>b__83_0()
extern void LTDescr_U3CsetScaleZU3Eb__83_0_mAD2EF57DC478929F5740862578A9059C640CDEA5 ();
// 0x000000EF System.Void LTDescr::<setScaleZ>b__83_1()
extern void LTDescr_U3CsetScaleZU3Eb__83_1_mFC67C018AD21FAE36DE72A2B809675773BE55390 ();
// 0x000000F0 System.Void LTDescr::<setRotateX>b__84_0()
extern void LTDescr_U3CsetRotateXU3Eb__84_0_m2A72481DC6A981F272B63370F720013FD1AEA4D7 ();
// 0x000000F1 System.Void LTDescr::<setRotateX>b__84_1()
extern void LTDescr_U3CsetRotateXU3Eb__84_1_mDD7D0C94A5C4DC51FE97F8CC2AD0E19898BB72A6 ();
// 0x000000F2 System.Void LTDescr::<setRotateY>b__85_0()
extern void LTDescr_U3CsetRotateYU3Eb__85_0_m80D532A7476E5C2FE77BD9388ED98D18651FD7C3 ();
// 0x000000F3 System.Void LTDescr::<setRotateY>b__85_1()
extern void LTDescr_U3CsetRotateYU3Eb__85_1_m16AE0DD429ECDACEA0F05E0C4C719E78620929E0 ();
// 0x000000F4 System.Void LTDescr::<setRotateZ>b__86_0()
extern void LTDescr_U3CsetRotateZU3Eb__86_0_mC5D90C9A709FAA3C801872D3BCD19E58F6D77699 ();
// 0x000000F5 System.Void LTDescr::<setRotateZ>b__86_1()
extern void LTDescr_U3CsetRotateZU3Eb__86_1_m08A2A6B1F54D29139A76BB166A2C7EBB52B5CEAA ();
// 0x000000F6 System.Void LTDescr::<setRotateAround>b__87_0()
extern void LTDescr_U3CsetRotateAroundU3Eb__87_0_m3C73F52643C6F22139A755A4D3DEC628D2F9EE30 ();
// 0x000000F7 System.Void LTDescr::<setRotateAround>b__87_1()
extern void LTDescr_U3CsetRotateAroundU3Eb__87_1_m89879D2C93C6860C239434F38F9BC6FC6726E9C8 ();
// 0x000000F8 System.Void LTDescr::<setRotateAroundLocal>b__88_0()
extern void LTDescr_U3CsetRotateAroundLocalU3Eb__88_0_m21352E2B36657F92D8E9E0F95DA74649F656EF76 ();
// 0x000000F9 System.Void LTDescr::<setRotateAroundLocal>b__88_1()
extern void LTDescr_U3CsetRotateAroundLocalU3Eb__88_1_mB058FB46E81DDB20592AA23C6EA0B78B4B1B2DB0 ();
// 0x000000FA System.Void LTDescr::<setAlpha>b__89_0()
extern void LTDescr_U3CsetAlphaU3Eb__89_0_m1AFAB1D9A1AA7560DA67FBB7D35EA17B44751500 ();
// 0x000000FB System.Void LTDescr::<setAlpha>b__89_2()
extern void LTDescr_U3CsetAlphaU3Eb__89_2_m4376BFAB661538E87C47CB0AF7CE333A20AB4F11 ();
// 0x000000FC System.Void LTDescr::<setAlpha>b__89_1()
extern void LTDescr_U3CsetAlphaU3Eb__89_1_mE03506955EE1A8F1C0FAF37B3BBFAF88CCCECC1B ();
// 0x000000FD System.Void LTDescr::<setTextAlpha>b__90_0()
extern void LTDescr_U3CsetTextAlphaU3Eb__90_0_m309DB4C30BCF61C26C69A42722CBADD2E7921CA0 ();
// 0x000000FE System.Void LTDescr::<setTextAlpha>b__90_1()
extern void LTDescr_U3CsetTextAlphaU3Eb__90_1_m1681C4B1A2C76AE1340B4A1C8499AB98AE46E909 ();
// 0x000000FF System.Void LTDescr::<setAlphaVertex>b__91_0()
extern void LTDescr_U3CsetAlphaVertexU3Eb__91_0_m91E4C42B4E39A4A9E40282D677F53F7276F7D47B ();
// 0x00000100 System.Void LTDescr::<setAlphaVertex>b__91_1()
extern void LTDescr_U3CsetAlphaVertexU3Eb__91_1_m07B356D53DBA361CE94D0D50617F8D01A8ED12A8 ();
// 0x00000101 System.Void LTDescr::<setColor>b__92_0()
extern void LTDescr_U3CsetColorU3Eb__92_0_m13B9F7EE151ACB78A4A0B052047E65801D67DB2A ();
// 0x00000102 System.Void LTDescr::<setColor>b__92_1()
extern void LTDescr_U3CsetColorU3Eb__92_1_m2A67B21B1EB3E3E2B36B641BC62F6B46B07BB062 ();
// 0x00000103 System.Void LTDescr::<setCallbackColor>b__93_0()
extern void LTDescr_U3CsetCallbackColorU3Eb__93_0_m8E71B55AD8C5B0E24E5691710725D3C4B69F7106 ();
// 0x00000104 System.Void LTDescr::<setCallbackColor>b__93_1()
extern void LTDescr_U3CsetCallbackColorU3Eb__93_1_m3C00ABAE6C15F8059D555365356C5CBEBFD829F1 ();
// 0x00000105 System.Void LTDescr::<setTextColor>b__94_0()
extern void LTDescr_U3CsetTextColorU3Eb__94_0_m963E0A1CECE51B444757CD9808374E2801D84980 ();
// 0x00000106 System.Void LTDescr::<setTextColor>b__94_1()
extern void LTDescr_U3CsetTextColorU3Eb__94_1_mE779CCC9D0DC6595CEB2283118B667EF12CB949D ();
// 0x00000107 System.Void LTDescr::<setCanvasAlpha>b__95_0()
extern void LTDescr_U3CsetCanvasAlphaU3Eb__95_0_mF27594F3B7BA34A42F6D7B24DC2F33EAD67CB976 ();
// 0x00000108 System.Void LTDescr::<setCanvasAlpha>b__95_1()
extern void LTDescr_U3CsetCanvasAlphaU3Eb__95_1_m5889FAA1B69DBDFAC9D33EF49E49B0E62F689855 ();
// 0x00000109 System.Void LTDescr::<setCanvasGroupAlpha>b__96_0()
extern void LTDescr_U3CsetCanvasGroupAlphaU3Eb__96_0_m87C46256B9E6190F7E4BC525C04B14E2979CF160 ();
// 0x0000010A System.Void LTDescr::<setCanvasGroupAlpha>b__96_1()
extern void LTDescr_U3CsetCanvasGroupAlphaU3Eb__96_1_mFB41FC0F66EE73C30F8EA4927B10F4A5CCD86FB9 ();
// 0x0000010B System.Void LTDescr::<setCanvasColor>b__97_0()
extern void LTDescr_U3CsetCanvasColorU3Eb__97_0_m4507F381646E5A941FB2544951C8E826AEA4F120 ();
// 0x0000010C System.Void LTDescr::<setCanvasColor>b__97_1()
extern void LTDescr_U3CsetCanvasColorU3Eb__97_1_m3CC39DAE832A8AABF0D26A4239CF77D15161B165 ();
// 0x0000010D System.Void LTDescr::<setCanvasMoveX>b__98_0()
extern void LTDescr_U3CsetCanvasMoveXU3Eb__98_0_mA74762AB885AD3F0003EA4B6C6AE43F0F0124CCA ();
// 0x0000010E System.Void LTDescr::<setCanvasMoveX>b__98_1()
extern void LTDescr_U3CsetCanvasMoveXU3Eb__98_1_m185BD3882C677C38269B56933DDA8514D5CC60EB ();
// 0x0000010F System.Void LTDescr::<setCanvasMoveY>b__99_0()
extern void LTDescr_U3CsetCanvasMoveYU3Eb__99_0_mCCC0ABF4892F03FE11A3B3A14040D623E64C50C4 ();
// 0x00000110 System.Void LTDescr::<setCanvasMoveY>b__99_1()
extern void LTDescr_U3CsetCanvasMoveYU3Eb__99_1_mA24E002DA1057CCDA5A33AF69EB4227DC5800A20 ();
// 0x00000111 System.Void LTDescr::<setCanvasMoveZ>b__100_0()
extern void LTDescr_U3CsetCanvasMoveZU3Eb__100_0_mC6D2803E76FAFDA1CF205C0B1D497AFE685F1334 ();
// 0x00000112 System.Void LTDescr::<setCanvasMoveZ>b__100_1()
extern void LTDescr_U3CsetCanvasMoveZU3Eb__100_1_m3CADCFA948FB541AA770AA79AF1CCAB9B7F265BD ();
// 0x00000113 System.Void LTDescr::<setCanvasRotateAround>b__102_0()
extern void LTDescr_U3CsetCanvasRotateAroundU3Eb__102_0_mB8F259A34776B45637CB105B97A1D2641188DEAF ();
// 0x00000114 System.Void LTDescr::<setCanvasRotateAroundLocal>b__103_0()
extern void LTDescr_U3CsetCanvasRotateAroundLocalU3Eb__103_0_m7506F0CAF5A219B0282BEC06F8BF74D67285E684 ();
// 0x00000115 System.Void LTDescr::<setCanvasPlaySprite>b__104_0()
extern void LTDescr_U3CsetCanvasPlaySpriteU3Eb__104_0_m383DE758F44CD402E33B9A069E3995C6800F8CFB ();
// 0x00000116 System.Void LTDescr::<setCanvasPlaySprite>b__104_1()
extern void LTDescr_U3CsetCanvasPlaySpriteU3Eb__104_1_m23D3E058DFB47A63703782EC55102E374FE18F83 ();
// 0x00000117 System.Void LTDescr::<setCanvasMove>b__105_0()
extern void LTDescr_U3CsetCanvasMoveU3Eb__105_0_mEE7B7CAD9EEFF0B864544EFC0C15D85D1B9EFEF1 ();
// 0x00000118 System.Void LTDescr::<setCanvasMove>b__105_1()
extern void LTDescr_U3CsetCanvasMoveU3Eb__105_1_mC3174EB13AF8FED68DBF81D48A97142863A85C96 ();
// 0x00000119 System.Void LTDescr::<setCanvasScale>b__106_0()
extern void LTDescr_U3CsetCanvasScaleU3Eb__106_0_mA5DC0EE7A92E9F28D0A76CCC5693B3092A059CC4 ();
// 0x0000011A System.Void LTDescr::<setCanvasScale>b__106_1()
extern void LTDescr_U3CsetCanvasScaleU3Eb__106_1_m8E5B88D595B2E4963842E1DFCBBB6D48133B9BAF ();
// 0x0000011B System.Void LTDescr::<setCanvasSizeDelta>b__107_0()
extern void LTDescr_U3CsetCanvasSizeDeltaU3Eb__107_0_mB6798ED46BD45A579D1399667998DD416D1140B8 ();
// 0x0000011C System.Void LTDescr::<setCanvasSizeDelta>b__107_1()
extern void LTDescr_U3CsetCanvasSizeDeltaU3Eb__107_1_mDE41C32201F0EAA33B232F059E8BAEB2F2E641F1 ();
// 0x0000011D System.Void LTDescr::<setMove>b__111_0()
extern void LTDescr_U3CsetMoveU3Eb__111_0_m354F8AC13CED797EFEA001B7E872B08369638340 ();
// 0x0000011E System.Void LTDescr::<setMove>b__111_1()
extern void LTDescr_U3CsetMoveU3Eb__111_1_m12658E361011304F02ED2D6CDC219B54A003E277 ();
// 0x0000011F System.Void LTDescr::<setMoveLocal>b__112_0()
extern void LTDescr_U3CsetMoveLocalU3Eb__112_0_m7D1ABFFF1EEEEE02AEFAA918C17A98E98B00D710 ();
// 0x00000120 System.Void LTDescr::<setMoveLocal>b__112_1()
extern void LTDescr_U3CsetMoveLocalU3Eb__112_1_m28C40D6427D961B7F00DF41E2FD6A654914EBE7B ();
// 0x00000121 System.Void LTDescr::<setMoveToTransform>b__113_0()
extern void LTDescr_U3CsetMoveToTransformU3Eb__113_0_m0F83E2B55A56B95C279D0CC6343BA52942480243 ();
// 0x00000122 System.Void LTDescr::<setMoveToTransform>b__113_1()
extern void LTDescr_U3CsetMoveToTransformU3Eb__113_1_m7262949DEFBF1639CD1D1242258BF4EC3A3A7A9E ();
// 0x00000123 System.Void LTDescr::<setRotate>b__114_0()
extern void LTDescr_U3CsetRotateU3Eb__114_0_mC0E62DAFDE435DD80B37A2ACD28E47FDF4B66970 ();
// 0x00000124 System.Void LTDescr::<setRotate>b__114_1()
extern void LTDescr_U3CsetRotateU3Eb__114_1_m35177AA532C9E2DD6733C88CE7AA7718A8004A8D ();
// 0x00000125 System.Void LTDescr::<setRotateLocal>b__115_0()
extern void LTDescr_U3CsetRotateLocalU3Eb__115_0_m2D6801CBC70BB13E4008CCAB57C51E9DFEE57A95 ();
// 0x00000126 System.Void LTDescr::<setRotateLocal>b__115_1()
extern void LTDescr_U3CsetRotateLocalU3Eb__115_1_mEB674A4DB216C49D2617A333C8AF906316829AC6 ();
// 0x00000127 System.Void LTDescr::<setScale>b__116_0()
extern void LTDescr_U3CsetScaleU3Eb__116_0_mC99B91FE5F4C96523771CE2CB6BB7C29FAD5BF21 ();
// 0x00000128 System.Void LTDescr::<setScale>b__116_1()
extern void LTDescr_U3CsetScaleU3Eb__116_1_m30BD9BE93B48898740FFA48AD38CBAB65D5F4DC1 ();
// 0x00000129 System.Void LTDescr::<setGUIMove>b__117_0()
extern void LTDescr_U3CsetGUIMoveU3Eb__117_0_mB6C97713486DC8EDB18DC0796D33AB993706BF2D ();
// 0x0000012A System.Void LTDescr::<setGUIMove>b__117_1()
extern void LTDescr_U3CsetGUIMoveU3Eb__117_1_m691614FA188E66D6DC7A156B227707CF9DA7A43D ();
// 0x0000012B System.Void LTDescr::<setGUIMoveMargin>b__118_0()
extern void LTDescr_U3CsetGUIMoveMarginU3Eb__118_0_m346800AFC0BC448295FF2A2F552C1F21806743C0 ();
// 0x0000012C System.Void LTDescr::<setGUIMoveMargin>b__118_1()
extern void LTDescr_U3CsetGUIMoveMarginU3Eb__118_1_m00B0D135E5CB1E605E840460A3F0AA6996F33C78 ();
// 0x0000012D System.Void LTDescr::<setGUIScale>b__119_0()
extern void LTDescr_U3CsetGUIScaleU3Eb__119_0_m69189FB900EF9EC1720F7A0D77860E4B35DAD939 ();
// 0x0000012E System.Void LTDescr::<setGUIScale>b__119_1()
extern void LTDescr_U3CsetGUIScaleU3Eb__119_1_mBAFE8179505F274590069960B98D974AFE988C20 ();
// 0x0000012F System.Void LTDescr::<setGUIAlpha>b__120_0()
extern void LTDescr_U3CsetGUIAlphaU3Eb__120_0_m482516D380329AB1053235283AE0648B398E4676 ();
// 0x00000130 System.Void LTDescr::<setGUIAlpha>b__120_1()
extern void LTDescr_U3CsetGUIAlphaU3Eb__120_1_mE11F1C9B75B5F44200BA7B818A4A3F17B3DAF9C3 ();
// 0x00000131 System.Void LTDescr::<setGUIRotate>b__121_0()
extern void LTDescr_U3CsetGUIRotateU3Eb__121_0_m426E1D47727A5690C69961121B4961F6E0C7354A ();
// 0x00000132 System.Void LTDescr::<setGUIRotate>b__121_1()
extern void LTDescr_U3CsetGUIRotateU3Eb__121_1_mF8357DDCFCE8ECB9B3D5610765B16AF0611666F5 ();
// 0x00000133 System.Void LTDescr::<setDelayedSound>b__122_0()
extern void LTDescr_U3CsetDelayedSoundU3Eb__122_0_m802E219D03874FB0147C4E5D28AB644519E6727D ();
// 0x00000134 UnityEngine.Transform LTDescrOptional::get_toTrans()
extern void LTDescrOptional_get_toTrans_m719D187173ACED93F6F03273F38B2499F96AAC77 ();
// 0x00000135 System.Void LTDescrOptional::set_toTrans(UnityEngine.Transform)
extern void LTDescrOptional_set_toTrans_m7E481DD43D79347C73999A8430769C0CE9434000 ();
// 0x00000136 UnityEngine.Vector3 LTDescrOptional::get_point()
extern void LTDescrOptional_get_point_mE9A79C3F3C2B2FCCFD77E63EB0E1F11138E0FB58 ();
// 0x00000137 System.Void LTDescrOptional::set_point(UnityEngine.Vector3)
extern void LTDescrOptional_set_point_m87344CAF5C411212DC7E14B8258AF7106008EF41 ();
// 0x00000138 UnityEngine.Vector3 LTDescrOptional::get_axis()
extern void LTDescrOptional_get_axis_mA44ADE549E460373050A42CE075327D57FCB2A6A ();
// 0x00000139 System.Void LTDescrOptional::set_axis(UnityEngine.Vector3)
extern void LTDescrOptional_set_axis_mBBD7056ADF137DE153FF5ACC7E4046AF54BFD876 ();
// 0x0000013A System.Single LTDescrOptional::get_lastVal()
extern void LTDescrOptional_get_lastVal_mE14C4A1953C7028559AF2C4C3CE95B251EDE148B ();
// 0x0000013B System.Void LTDescrOptional::set_lastVal(System.Single)
extern void LTDescrOptional_set_lastVal_mFBBB45BCE3AC57DF28B86DFC163F8F9EA025868D ();
// 0x0000013C UnityEngine.Quaternion LTDescrOptional::get_origRotation()
extern void LTDescrOptional_get_origRotation_mDE9B177F7E9F3646B00354F66ACB1ABDC4281C01 ();
// 0x0000013D System.Void LTDescrOptional::set_origRotation(UnityEngine.Quaternion)
extern void LTDescrOptional_set_origRotation_m7D8F2827074243FDE8E46EA78473CEF60AA9A09F ();
// 0x0000013E LTBezierPath LTDescrOptional::get_path()
extern void LTDescrOptional_get_path_mA1618E15721930967AD76373DC579895549967D6 ();
// 0x0000013F System.Void LTDescrOptional::set_path(LTBezierPath)
extern void LTDescrOptional_set_path_m84B919D4F4ACA4F5A9851EA4993FF273F5A78014 ();
// 0x00000140 LTSpline LTDescrOptional::get_spline()
extern void LTDescrOptional_get_spline_m93E9C9EC86E5B9D0865376D7805560468E60A409 ();
// 0x00000141 System.Void LTDescrOptional::set_spline(LTSpline)
extern void LTDescrOptional_set_spline_m969135BC7A93AE02A661F823996A23DEDE0E588E ();
// 0x00000142 LTRect LTDescrOptional::get_ltRect()
extern void LTDescrOptional_get_ltRect_mC25A94E7A1F24D5B961362A1F58EB9C68423C73C ();
// 0x00000143 System.Void LTDescrOptional::set_ltRect(LTRect)
extern void LTDescrOptional_set_ltRect_mC0E01A1BC6C8936B151A0AD9ECAF42C03CB31E6B ();
// 0x00000144 System.Action`1<System.Single> LTDescrOptional::get_onUpdateFloat()
extern void LTDescrOptional_get_onUpdateFloat_m351E8A10B1A6699D21501BC01CADD4313B91E772 ();
// 0x00000145 System.Void LTDescrOptional::set_onUpdateFloat(System.Action`1<System.Single>)
extern void LTDescrOptional_set_onUpdateFloat_mB78B0396D1060CA1608EA891202AE34E495D0343 ();
// 0x00000146 System.Action`2<System.Single,System.Single> LTDescrOptional::get_onUpdateFloatRatio()
extern void LTDescrOptional_get_onUpdateFloatRatio_mBB863BF8D49E74EC7B479C112ADFA1366FFD9B32 ();
// 0x00000147 System.Void LTDescrOptional::set_onUpdateFloatRatio(System.Action`2<System.Single,System.Single>)
extern void LTDescrOptional_set_onUpdateFloatRatio_mD198A9B69A19A9D88F55975EA68C7B917C79618F ();
// 0x00000148 System.Action`2<System.Single,System.Object> LTDescrOptional::get_onUpdateFloatObject()
extern void LTDescrOptional_get_onUpdateFloatObject_m4A6112959483417980F736BAE24AAA719DB2C724 ();
// 0x00000149 System.Void LTDescrOptional::set_onUpdateFloatObject(System.Action`2<System.Single,System.Object>)
extern void LTDescrOptional_set_onUpdateFloatObject_m72B8D5B86EFF9B99A11DB6F0C34379631E16C83D ();
// 0x0000014A System.Action`1<UnityEngine.Vector2> LTDescrOptional::get_onUpdateVector2()
extern void LTDescrOptional_get_onUpdateVector2_mAACB3752372B7838ACF31AAF4D66A73877E9E9D7 ();
// 0x0000014B System.Void LTDescrOptional::set_onUpdateVector2(System.Action`1<UnityEngine.Vector2>)
extern void LTDescrOptional_set_onUpdateVector2_mE699D0E783557FF6695C922DFAEB3716042F6637 ();
// 0x0000014C System.Action`1<UnityEngine.Vector3> LTDescrOptional::get_onUpdateVector3()
extern void LTDescrOptional_get_onUpdateVector3_mC0175F8101E456C43E292F646F99FE312E9C687F ();
// 0x0000014D System.Void LTDescrOptional::set_onUpdateVector3(System.Action`1<UnityEngine.Vector3>)
extern void LTDescrOptional_set_onUpdateVector3_m9FA6249737B9F1BE2EA5DCA335AB996E50698504 ();
// 0x0000014E System.Action`2<UnityEngine.Vector3,System.Object> LTDescrOptional::get_onUpdateVector3Object()
extern void LTDescrOptional_get_onUpdateVector3Object_mE6B6670B2913F713B096E828036EB6CD4DA60CE0 ();
// 0x0000014F System.Void LTDescrOptional::set_onUpdateVector3Object(System.Action`2<UnityEngine.Vector3,System.Object>)
extern void LTDescrOptional_set_onUpdateVector3Object_m3F8F905404058D4985E77545AB9A40F2FA25B611 ();
// 0x00000150 System.Action`1<UnityEngine.Color> LTDescrOptional::get_onUpdateColor()
extern void LTDescrOptional_get_onUpdateColor_mB519CEA2D59E7E89220416D6339B2A38A7638631 ();
// 0x00000151 System.Void LTDescrOptional::set_onUpdateColor(System.Action`1<UnityEngine.Color>)
extern void LTDescrOptional_set_onUpdateColor_m5DC714D8E11CA5FF02B5CC8CB06889642B85C0DF ();
// 0x00000152 System.Action`2<UnityEngine.Color,System.Object> LTDescrOptional::get_onUpdateColorObject()
extern void LTDescrOptional_get_onUpdateColorObject_m9EF2D50A913D43C253D70FE126B78C1F145B7B4D ();
// 0x00000153 System.Void LTDescrOptional::set_onUpdateColorObject(System.Action`2<UnityEngine.Color,System.Object>)
extern void LTDescrOptional_set_onUpdateColorObject_mCCC40115BBD9D83074948446A384195419684733 ();
// 0x00000154 System.Action LTDescrOptional::get_onComplete()
extern void LTDescrOptional_get_onComplete_mCE1EBB1934BEE25B8BE80AB1A187D7B8901E915D ();
// 0x00000155 System.Void LTDescrOptional::set_onComplete(System.Action)
extern void LTDescrOptional_set_onComplete_m59EE673BD2A62B75E152344EE4EC04A8A330AEE9 ();
// 0x00000156 System.Action`1<System.Object> LTDescrOptional::get_onCompleteObject()
extern void LTDescrOptional_get_onCompleteObject_m1BC88DEE83772EAF55BD7776A146B3CDE5B4B4A3 ();
// 0x00000157 System.Void LTDescrOptional::set_onCompleteObject(System.Action`1<System.Object>)
extern void LTDescrOptional_set_onCompleteObject_m7AF36A20467C6F0EC7A15E217CA658BC5931E2E5 ();
// 0x00000158 System.Object LTDescrOptional::get_onCompleteParam()
extern void LTDescrOptional_get_onCompleteParam_mE66FC1BACD1FA85AAFC8F95B33FCECAD44498177 ();
// 0x00000159 System.Void LTDescrOptional::set_onCompleteParam(System.Object)
extern void LTDescrOptional_set_onCompleteParam_mEAE8B0B7EEC7D592089145C89EF5529F29F76FF4 ();
// 0x0000015A System.Object LTDescrOptional::get_onUpdateParam()
extern void LTDescrOptional_get_onUpdateParam_m9314432EF4319CC8BF91AB498DFD28B6584F9CD0 ();
// 0x0000015B System.Void LTDescrOptional::set_onUpdateParam(System.Object)
extern void LTDescrOptional_set_onUpdateParam_m6DF63DF749384C397A6551409541DAAA1149F4CE ();
// 0x0000015C System.Action LTDescrOptional::get_onStart()
extern void LTDescrOptional_get_onStart_m71FE346812408A252C0832481C537B3BFE143032 ();
// 0x0000015D System.Void LTDescrOptional::set_onStart(System.Action)
extern void LTDescrOptional_set_onStart_mF2209FE068D659F0729D1DBEC443C9EE465792AA ();
// 0x0000015E System.Void LTDescrOptional::reset()
extern void LTDescrOptional_reset_m9843AB37FCFDE642330F1B47C3021106ED8DE1C1 ();
// 0x0000015F System.Void LTDescrOptional::callOnUpdate(System.Single,System.Single)
extern void LTDescrOptional_callOnUpdate_m46C77125973B23B14522452083EC375D4049DE3C ();
// 0x00000160 System.Void LTDescrOptional::.ctor()
extern void LTDescrOptional__ctor_mA02370B0829C1DAD68A23CA987ED68BDA298CA0C ();
// 0x00000161 System.Int32 LTSeq::get_id()
extern void LTSeq_get_id_m140EA14F1A75BACAC2C5DF3B18DF92D8FDE28BAB ();
// 0x00000162 System.Void LTSeq::reset()
extern void LTSeq_reset_mE8690AE26C8E0B5A06EC7EBCB24E2BC9B96C8575 ();
// 0x00000163 System.Void LTSeq::init(System.UInt32,System.UInt32)
extern void LTSeq_init_m93C5A0FF33AAB790CA3056ED86ECCAC59DDC4DE3 ();
// 0x00000164 LTSeq LTSeq::addOn()
extern void LTSeq_addOn_m2A1CE56E1C5347864944F315D503339A6B10FFC9 ();
// 0x00000165 System.Single LTSeq::addPreviousDelays()
extern void LTSeq_addPreviousDelays_mDC7303F45F3BAAB22211925F4D39A67057B3FDBD ();
// 0x00000166 LTSeq LTSeq::append(System.Single)
extern void LTSeq_append_mA2177BFD342C4C862F979E515730BE8D6D125094 ();
// 0x00000167 LTSeq LTSeq::append(System.Action)
extern void LTSeq_append_m573B4DEBE76713FAE8FC6B28460A14F915997BEE ();
// 0x00000168 LTSeq LTSeq::append(System.Action`1<System.Object>,System.Object)
extern void LTSeq_append_m7DC432502137830AC5BE66B2EB72D96B2B61CEBD ();
// 0x00000169 LTSeq LTSeq::append(UnityEngine.GameObject,System.Action)
extern void LTSeq_append_m6D13368207F65B56954A1E43530799A5D48D996A ();
// 0x0000016A LTSeq LTSeq::append(UnityEngine.GameObject,System.Action`1<System.Object>,System.Object)
extern void LTSeq_append_m3F851840D6F75DAEFC24B1C704F247AD23460887 ();
// 0x0000016B LTSeq LTSeq::append(LTDescr)
extern void LTSeq_append_mF8C90D98E084F9E92C5AE6A006DE8B51CCF7A738 ();
// 0x0000016C LTSeq LTSeq::insert(LTDescr)
extern void LTSeq_insert_mDC2A02C163B7A3E2C7915EF94C5A151614796489 ();
// 0x0000016D LTSeq LTSeq::setScale(System.Single)
extern void LTSeq_setScale_mD0B3126147CE96803D2DA368E5D37B212CA43B9D ();
// 0x0000016E System.Void LTSeq::setScaleRecursive(LTSeq,System.Single,System.Int32)
extern void LTSeq_setScaleRecursive_mB17F9AC4644C525CC4A98D42E3FDDD9A67908FF7 ();
// 0x0000016F LTSeq LTSeq::reverse()
extern void LTSeq_reverse_mAEAD5EC07B481C926FB441BF76A44351CC47A1DE ();
// 0x00000170 System.Void LTSeq::.ctor()
extern void LTSeq__ctor_m49349974D5B4AE164813F87E303ECAE74069EE1C ();
// 0x00000171 System.Void LeanAudioStream::.ctor(System.Single[])
extern void LeanAudioStream__ctor_mDF57FD09E2DD751476D57DEABB13A1D09B6EE7E7 ();
// 0x00000172 System.Void LeanAudioStream::OnAudioRead(System.Single[])
extern void LeanAudioStream_OnAudioRead_mB21A90E7586869074CE94B78314E2DA74B58A37B ();
// 0x00000173 System.Void LeanAudioStream::OnAudioSetPosition(System.Int32)
extern void LeanAudioStream_OnAudioSetPosition_m632422DDFBEF2A9A75B1A59345D9CEE507B2D900 ();
// 0x00000174 LeanAudioOptions LeanAudio::options()
extern void LeanAudio_options_mF00747206F18810EB9CC0E9B768F9F2B6DFFD49B ();
// 0x00000175 LeanAudioStream LeanAudio::createAudioStream(UnityEngine.AnimationCurve,UnityEngine.AnimationCurve,LeanAudioOptions)
extern void LeanAudio_createAudioStream_m503D5BDD4537E111B9A985A14C63B45E024BD9B9 ();
// 0x00000176 UnityEngine.AudioClip LeanAudio::createAudio(UnityEngine.AnimationCurve,UnityEngine.AnimationCurve,LeanAudioOptions)
extern void LeanAudio_createAudio_m8AF5FEC4BA10749A6A54AAAC10F99F91D1F859B1 ();
// 0x00000177 System.Int32 LeanAudio::createAudioWave(UnityEngine.AnimationCurve,UnityEngine.AnimationCurve,LeanAudioOptions)
extern void LeanAudio_createAudioWave_mEB124CD2B7592EC9B4D263DD33D38754D08C5623 ();
// 0x00000178 UnityEngine.AudioClip LeanAudio::createAudioFromWave(System.Int32,LeanAudioOptions)
extern void LeanAudio_createAudioFromWave_mEF3E94173FD41F29D4E1F17EEFB79410B462A7AB ();
// 0x00000179 System.Void LeanAudio::OnAudioSetPosition(System.Int32)
extern void LeanAudio_OnAudioSetPosition_m2D9BEAC1A8233E68114DDF122DEC0B60EBA6433F ();
// 0x0000017A UnityEngine.AudioClip LeanAudio::generateAudioFromCurve(UnityEngine.AnimationCurve,System.Int32)
extern void LeanAudio_generateAudioFromCurve_m15F8DAC6E15F0679018162991023320C21AE3C95 ();
// 0x0000017B UnityEngine.AudioSource LeanAudio::play(UnityEngine.AudioClip,System.Single)
extern void LeanAudio_play_mF85E29DC3CD2CCE6F8B9E3F2C68E544250E694EA ();
// 0x0000017C UnityEngine.AudioSource LeanAudio::play(UnityEngine.AudioClip)
extern void LeanAudio_play_mD774FC88168B4ED2F7949A34A45338E41E3FEB20 ();
// 0x0000017D UnityEngine.AudioSource LeanAudio::play(UnityEngine.AudioClip,UnityEngine.Vector3)
extern void LeanAudio_play_m9147E4BCFD423C76CBB32E74155C4FB10C49E780 ();
// 0x0000017E UnityEngine.AudioSource LeanAudio::play(UnityEngine.AudioClip,UnityEngine.Vector3,System.Single)
extern void LeanAudio_play_mF1F5C2D2304E6F15F1C7201DC15BA9451FE25551 ();
// 0x0000017F UnityEngine.AudioSource LeanAudio::playClipAt(UnityEngine.AudioClip,UnityEngine.Vector3)
extern void LeanAudio_playClipAt_mA785B6A0B9BFEB784B057F1792FA6B123AD48470 ();
// 0x00000180 System.Void LeanAudio::printOutAudioClip(UnityEngine.AudioClip,UnityEngine.AnimationCurve&,System.Single)
extern void LeanAudio_printOutAudioClip_m1BBEEF74E06E87EEB6CB40428B40F3ACF149B2E0 ();
// 0x00000181 System.Void LeanAudio::.ctor()
extern void LeanAudio__ctor_m5A6A66B881DF5CAB4B8075FF43EC94FFB09850B9 ();
// 0x00000182 System.Void LeanAudio::.cctor()
extern void LeanAudio__cctor_mFCF0B22A8ACB7C105BED2A99CF3CFDA5249F8AAF ();
// 0x00000183 System.Void LeanAudioOptions::.ctor()
extern void LeanAudioOptions__ctor_mEAA77FFB2BAFDC3CDD4F308A520A52460799EC90 ();
// 0x00000184 LeanAudioOptions LeanAudioOptions::setFrequency(System.Int32)
extern void LeanAudioOptions_setFrequency_mE2A475F0F7319F9684E097BCC7C44701EC3D8909 ();
// 0x00000185 LeanAudioOptions LeanAudioOptions::setVibrato(UnityEngine.Vector3[])
extern void LeanAudioOptions_setVibrato_mA266E90C3FE02CC21E4CF90ED88ED2C284E574E7 ();
// 0x00000186 LeanAudioOptions LeanAudioOptions::setWaveSine()
extern void LeanAudioOptions_setWaveSine_mEFC93B54DE788249388CF3B55038750339CDC7D2 ();
// 0x00000187 LeanAudioOptions LeanAudioOptions::setWaveSquare()
extern void LeanAudioOptions_setWaveSquare_mC82AD1D5AF7278330E0808DA9E3956A2C85F3357 ();
// 0x00000188 LeanAudioOptions LeanAudioOptions::setWaveSawtooth()
extern void LeanAudioOptions_setWaveSawtooth_m33F49A4AE4BB2F139D935F2D67768B8B938914C7 ();
// 0x00000189 LeanAudioOptions LeanAudioOptions::setWaveNoise()
extern void LeanAudioOptions_setWaveNoise_m3A0FC31501B4DF8FFF894E7EF00180AAFED760CE ();
// 0x0000018A LeanAudioOptions LeanAudioOptions::setWaveStyle(LeanAudioOptions_LeanAudioWaveStyle)
extern void LeanAudioOptions_setWaveStyle_m6826A4F3E7CC38810BDA8543CFB57C4914B66034 ();
// 0x0000018B LeanAudioOptions LeanAudioOptions::setWaveNoiseScale(System.Single)
extern void LeanAudioOptions_setWaveNoiseScale_m17A4FAEA45D3746211755E42072D363A0B423285 ();
// 0x0000018C LeanAudioOptions LeanAudioOptions::setWaveNoiseInfluence(System.Single)
extern void LeanAudioOptions_setWaveNoiseInfluence_m5E1DCC6E69DD4F8D6E6DC5E6B7F42C85F3D8DB3B ();
// 0x0000018D System.Void LeanTester::Start()
extern void LeanTester_Start_mAA0B8CCD08535865AC59436BDEAADA4B4ABF4015 ();
// 0x0000018E System.Collections.IEnumerator LeanTester::timeoutCheck()
extern void LeanTester_timeoutCheck_mA5EF6F05EC2DE5ECBBB0B7DD243120D8CBD75B81 ();
// 0x0000018F System.Void LeanTester::.ctor()
extern void LeanTester__ctor_m844173FA687FE335D642403866EA9BE276A49D9D ();
// 0x00000190 System.Void LeanTest::debug(System.String,System.Boolean,System.String)
extern void LeanTest_debug_mA720BBA18435CC6357DEBB4BC84EF3548472ABD2 ();
// 0x00000191 System.Void LeanTest::expect(System.Boolean,System.String,System.String)
extern void LeanTest_expect_m0D0B37EDF16B00E37B2A3FA1BF2D5120E0A39F51 ();
// 0x00000192 System.String LeanTest::padRight(System.Int32)
extern void LeanTest_padRight_m6B4C7481D1E623931A452A662E23AEDD55034286 ();
// 0x00000193 System.Single LeanTest::printOutLength(System.String)
extern void LeanTest_printOutLength_m07A82FD8C2EB0F3B0A0DFD965A0197F5A53A4F0A ();
// 0x00000194 System.String LeanTest::formatBC(System.String,System.String)
extern void LeanTest_formatBC_mFD611FB47EF427FC380DC1941CFEEE9875C62934 ();
// 0x00000195 System.String LeanTest::formatB(System.String)
extern void LeanTest_formatB_mF67C5B1EA0357634346BEFDBCCE47EF1C11921EA ();
// 0x00000196 System.String LeanTest::formatC(System.String,System.String)
extern void LeanTest_formatC_mA50AA389A5A1963A9D97F69F4ACD51EA36451B11 ();
// 0x00000197 System.Void LeanTest::overview()
extern void LeanTest_overview_mB5C2BB989BE6A6675763CF8694A84CA9A8CF79B1 ();
// 0x00000198 System.Void LeanTest::.ctor()
extern void LeanTest__ctor_mD8CF7A576BC7B11ECCE6BE389F5EE15C5D7DE0AE ();
// 0x00000199 System.Void LeanTest::.cctor()
extern void LeanTest__cctor_m54A725A957249EE68C559F2329B8AF06D1E308F4 ();
// 0x0000019A System.Void LeanTween::init()
extern void LeanTween_init_m3A14F34E8E6C0F4E7E8F04680036005A558AA597 ();
// 0x0000019B System.Int32 LeanTween::get_maxSearch()
extern void LeanTween_get_maxSearch_mDDF2CCBB34877BFA91E9D41AC1A37EEF9A17D3B7 ();
// 0x0000019C System.Int32 LeanTween::get_maxSimulataneousTweens()
extern void LeanTween_get_maxSimulataneousTweens_m2E4F01D132BF6E910B8C9382DB431CAC15166021 ();
// 0x0000019D System.Int32 LeanTween::get_tweensRunning()
extern void LeanTween_get_tweensRunning_m79147802B4C22258FE5D0E2C9163864922DB9E46 ();
// 0x0000019E System.Void LeanTween::init(System.Int32)
extern void LeanTween_init_m838A501BBC42BF87BC5D3CDB639292C03D091490 ();
// 0x0000019F System.Void LeanTween::init(System.Int32,System.Int32)
extern void LeanTween_init_mF52C50B297D7308D4B071CC158BFFAA2CE159433 ();
// 0x000001A0 System.Void LeanTween::reset()
extern void LeanTween_reset_mEFF3007C07A7A43DEC29917CD75A1FF371CD2B57 ();
// 0x000001A1 System.Void LeanTween::Update()
extern void LeanTween_Update_m9A2285BE57F974528E92EF460F7C67098D7F4083 ();
// 0x000001A2 System.Void LeanTween::onLevelWasLoaded54(UnityEngine.SceneManagement.Scene,UnityEngine.SceneManagement.LoadSceneMode)
extern void LeanTween_onLevelWasLoaded54_m403AA28603A3DC3AF0893A21D02FE44EF26CBA51 ();
// 0x000001A3 System.Void LeanTween::internalOnLevelWasLoaded(System.Int32)
extern void LeanTween_internalOnLevelWasLoaded_mBFA0941C93E05CDA4792B59148236D068CB61763 ();
// 0x000001A4 System.Void LeanTween::update()
extern void LeanTween_update_m9B4C7EA55BB5D2D243784C9EB801199A01AD6BA4 ();
// 0x000001A5 System.Void LeanTween::removeTween(System.Int32,System.Int32)
extern void LeanTween_removeTween_mE428B0E1AA50508AA75616B9464559BDF94BBDCE ();
// 0x000001A6 System.Void LeanTween::removeTween(System.Int32)
extern void LeanTween_removeTween_m70447ECFDB45871EDCF90970848D71857AF55633 ();
// 0x000001A7 UnityEngine.Vector3[] LeanTween::add(UnityEngine.Vector3[],UnityEngine.Vector3)
extern void LeanTween_add_m0B9277057BE935AF4A8506E8BBE9A9DBE2039951 ();
// 0x000001A8 System.Single LeanTween::closestRot(System.Single,System.Single)
extern void LeanTween_closestRot_m08BEAB0A619A0C293FB45B844090FE035E65EDAE ();
// 0x000001A9 System.Void LeanTween::cancelAll()
extern void LeanTween_cancelAll_mD9AE22570FCBD2A51B5AC9E6FABCEB51D1BA62A9 ();
// 0x000001AA System.Void LeanTween::cancelAll(System.Boolean)
extern void LeanTween_cancelAll_m825F03BCBB920E99E359C16C4E36FB35ABF39D6C ();
// 0x000001AB System.Void LeanTween::cancel(UnityEngine.GameObject)
extern void LeanTween_cancel_mEBA9A5015B481CAA3037FB106E24229FA08FE48F ();
// 0x000001AC System.Void LeanTween::cancel(UnityEngine.GameObject,System.Boolean)
extern void LeanTween_cancel_m40D735EDE70D0F8989F3320AF30B01756EA95508 ();
// 0x000001AD System.Void LeanTween::cancel(UnityEngine.RectTransform)
extern void LeanTween_cancel_m8FF6F04D27BAB5CE2384E5FF5F29150DD357A0E3 ();
// 0x000001AE System.Void LeanTween::cancel(UnityEngine.GameObject,System.Int32,System.Boolean)
extern void LeanTween_cancel_m67D040E83CE6EDFA61AB7FC5E3709F3F4555DF1F ();
// 0x000001AF System.Void LeanTween::cancel(LTRect,System.Int32)
extern void LeanTween_cancel_m699FDAF503852033D60D288A8F7D5AE37F2E89A1 ();
// 0x000001B0 System.Void LeanTween::cancel(System.Int32)
extern void LeanTween_cancel_mE6AD77CD68160DBCDE6E7AD3F47455CA93AF0485 ();
// 0x000001B1 System.Void LeanTween::cancel(System.Int32,System.Boolean)
extern void LeanTween_cancel_mAC6C9FA841627B25FA7A5667CEEBD8112C43D9D7 ();
// 0x000001B2 LTDescr LeanTween::descr(System.Int32)
extern void LeanTween_descr_mAA96FC2477393396F9EFF9BCB0F2457F8E1A5575 ();
// 0x000001B3 LTDescr LeanTween::description(System.Int32)
extern void LeanTween_description_m779BBCE6BFAAD443D61BF54728D5EAA2AC1F91F6 ();
// 0x000001B4 LTDescr[] LeanTween::descriptions(UnityEngine.GameObject)
extern void LeanTween_descriptions_m8A1EDD62B99DB1D195720BE8AFAD7D9C3EE06B03 ();
// 0x000001B5 System.Void LeanTween::pause(UnityEngine.GameObject,System.Int32)
extern void LeanTween_pause_m3E16CBA0457ACFA6DB6AF31420E3E076EB4C82ED ();
// 0x000001B6 System.Void LeanTween::pause(System.Int32)
extern void LeanTween_pause_m6877200DE8AA083953E2B74676D0CF1D3FF54A17 ();
// 0x000001B7 System.Void LeanTween::pause(UnityEngine.GameObject)
extern void LeanTween_pause_m8B121A136671F8C3DF1625213AF2E61F098F1BE3 ();
// 0x000001B8 System.Void LeanTween::pauseAll()
extern void LeanTween_pauseAll_m1FF8BAC2FC5A172E6FDB1701BB8D32E33F566CA1 ();
// 0x000001B9 System.Void LeanTween::resumeAll()
extern void LeanTween_resumeAll_mD0B25776C71F8AD78CC1728E4E2965423E0530FB ();
// 0x000001BA System.Void LeanTween::resume(UnityEngine.GameObject,System.Int32)
extern void LeanTween_resume_m0E3F52C06A4DBD4852AF4394CA06C78DD2C82D64 ();
// 0x000001BB System.Void LeanTween::resume(System.Int32)
extern void LeanTween_resume_m0E3FE2BA91498A9F7F2C0B7049D013DF63844C89 ();
// 0x000001BC System.Void LeanTween::resume(UnityEngine.GameObject)
extern void LeanTween_resume_m5E5125FA9897DD7077260EA02E9A3CDA05E72AD5 ();
// 0x000001BD System.Boolean LeanTween::isTweening(UnityEngine.GameObject)
extern void LeanTween_isTweening_m224C81EA776251E546E17E176D58FB13030C22CD ();
// 0x000001BE System.Boolean LeanTween::isTweening(UnityEngine.RectTransform)
extern void LeanTween_isTweening_m37C639AFC756F49B17EAFFE061FCF745A1CCEE4C ();
// 0x000001BF System.Boolean LeanTween::isTweening(System.Int32)
extern void LeanTween_isTweening_m87F758F1444484B33391D0A7B80311CADF96DA97 ();
// 0x000001C0 System.Boolean LeanTween::isTweening(LTRect)
extern void LeanTween_isTweening_m0FB1A948793C0D8696BC7EBDF46321F119C43107 ();
// 0x000001C1 System.Void LeanTween::drawBezierPath(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,UnityEngine.Transform)
extern void LeanTween_drawBezierPath_mBC5C62ABB0D5352564C32F5F865E8401E9D60349 ();
// 0x000001C2 System.Object LeanTween::logError(System.String)
extern void LeanTween_logError_m6F20E927A2B24271154486205006599F433D5421 ();
// 0x000001C3 LTDescr LeanTween::options(LTDescr)
extern void LeanTween_options_mB17CDBA626969DBC4FDE95FA2228F19439756E9E ();
// 0x000001C4 LTDescr LeanTween::options()
extern void LeanTween_options_mEF855D11F49DA432E24574EA3BDDA49B65493335 ();
// 0x000001C5 UnityEngine.GameObject LeanTween::get_tweenEmpty()
extern void LeanTween_get_tweenEmpty_m0B0429ACB0FB10F2460857934B1B3885315E0A86 ();
// 0x000001C6 LTDescr LeanTween::pushNewTween(UnityEngine.GameObject,UnityEngine.Vector3,System.Single,LTDescr)
extern void LeanTween_pushNewTween_m2D8100B7B9BA7080D51685021FCCD49DC6CC7D8C ();
// 0x000001C7 LTDescr LeanTween::play(UnityEngine.RectTransform,UnityEngine.Sprite[])
extern void LeanTween_play_mF2686814B4F270E9CC7D3870F1321493E2BC73E5 ();
// 0x000001C8 LTDescr LeanTween::alpha(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_alpha_m0B78DABD556A09E26A0F2D83DF60533BC83D9C24 ();
// 0x000001C9 LTSeq LeanTween::sequence(System.Boolean)
extern void LeanTween_sequence_m1C5CE0739250A4BD5D786028C7D210BFA2753A65 ();
// 0x000001CA LTDescr LeanTween::alpha(LTRect,System.Single,System.Single)
extern void LeanTween_alpha_mCB5CE4FA4C38721AA4404E7A8AC83BDC1D4CB092 ();
// 0x000001CB LTDescr LeanTween::textAlpha(UnityEngine.RectTransform,System.Single,System.Single)
extern void LeanTween_textAlpha_m5935920D7EF4D6B99B95F07228222344FF8E9508 ();
// 0x000001CC LTDescr LeanTween::alphaText(UnityEngine.RectTransform,System.Single,System.Single)
extern void LeanTween_alphaText_m7EC2C7D78F2CE215EBFE020B723178BC2E5A062B ();
// 0x000001CD LTDescr LeanTween::alphaCanvas(UnityEngine.CanvasGroup,System.Single,System.Single)
extern void LeanTween_alphaCanvas_m157681249512137B41CD125CADE584834D56D315 ();
// 0x000001CE LTDescr LeanTween::alphaVertex(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_alphaVertex_mA4F347B1367327EC7D719FB417150BD5C62BAF7C ();
// 0x000001CF LTDescr LeanTween::color(UnityEngine.GameObject,UnityEngine.Color,System.Single)
extern void LeanTween_color_mD0A3CBBAE2B1A587E788CF6F1AAEAA7F707DEBEE ();
// 0x000001D0 LTDescr LeanTween::textColor(UnityEngine.RectTransform,UnityEngine.Color,System.Single)
extern void LeanTween_textColor_m4A329212F28190FE384DF658578C20A00AE335F6 ();
// 0x000001D1 LTDescr LeanTween::colorText(UnityEngine.RectTransform,UnityEngine.Color,System.Single)
extern void LeanTween_colorText_mCF64FD914B2B009D4CE5AF7B5DC877959CCB8BE6 ();
// 0x000001D2 LTDescr LeanTween::delayedCall(System.Single,System.Action)
extern void LeanTween_delayedCall_mC7A4640FD2B48C590560EB50735D7D47C500F0B3 ();
// 0x000001D3 LTDescr LeanTween::delayedCall(System.Single,System.Action`1<System.Object>)
extern void LeanTween_delayedCall_m0793F63D6C1CD895009CE8D336D81D96B9895633 ();
// 0x000001D4 LTDescr LeanTween::delayedCall(UnityEngine.GameObject,System.Single,System.Action)
extern void LeanTween_delayedCall_mA94EA930FE8E58442F48B63B81DE071769049A65 ();
// 0x000001D5 LTDescr LeanTween::delayedCall(UnityEngine.GameObject,System.Single,System.Action`1<System.Object>)
extern void LeanTween_delayedCall_m0A5CF6D12E7558DDCD72AEF6FF9EDF56D3BFFEA6 ();
// 0x000001D6 LTDescr LeanTween::destroyAfter(LTRect,System.Single)
extern void LeanTween_destroyAfter_mE48606CFABF37E965A7536EDCBFD2954C08117AB ();
// 0x000001D7 LTDescr LeanTween::move(UnityEngine.GameObject,UnityEngine.Vector3,System.Single)
extern void LeanTween_move_mFEC103C0F170F5A6D9A0ABD5850132997FA0711A ();
// 0x000001D8 LTDescr LeanTween::move(UnityEngine.GameObject,UnityEngine.Vector2,System.Single)
extern void LeanTween_move_mB3CB4D07A30B261720A8BBC17D6889583529EEEB ();
// 0x000001D9 LTDescr LeanTween::move(UnityEngine.GameObject,UnityEngine.Vector3[],System.Single)
extern void LeanTween_move_m98A69BB2C5D052DA5511A3110B2D7AC334D16957 ();
// 0x000001DA LTDescr LeanTween::move(UnityEngine.GameObject,LTBezierPath,System.Single)
extern void LeanTween_move_mF1C537A5B1302574EEC7EF55AFFEBA39A0977986 ();
// 0x000001DB LTDescr LeanTween::move(UnityEngine.GameObject,LTSpline,System.Single)
extern void LeanTween_move_m923AC3AA478DBC29EB0EF2ACD2A9528A1F5ADDD2 ();
// 0x000001DC LTDescr LeanTween::moveSpline(UnityEngine.GameObject,UnityEngine.Vector3[],System.Single)
extern void LeanTween_moveSpline_m89E10B8AA1B74FDEECD33D400ECA17398DEA4170 ();
// 0x000001DD LTDescr LeanTween::moveSpline(UnityEngine.GameObject,LTSpline,System.Single)
extern void LeanTween_moveSpline_mF1B1B616A6F7877B6E4D9CDA3E2F2B94EAFEEDBC ();
// 0x000001DE LTDescr LeanTween::moveSplineLocal(UnityEngine.GameObject,UnityEngine.Vector3[],System.Single)
extern void LeanTween_moveSplineLocal_m5A87108FAA779C8A37A81C1F4EDD1167A5B4C998 ();
// 0x000001DF LTDescr LeanTween::move(LTRect,UnityEngine.Vector2,System.Single)
extern void LeanTween_move_mDC908E23A843784EB0FF709E0316E2C6EDE5069C ();
// 0x000001E0 LTDescr LeanTween::moveMargin(LTRect,UnityEngine.Vector2,System.Single)
extern void LeanTween_moveMargin_m908FD39664DE8397217F1E37A7F0243DDA209C03 ();
// 0x000001E1 LTDescr LeanTween::moveX(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_moveX_m823C48EFE89D05E8A6CC29C0E4CA924A694F7FC8 ();
// 0x000001E2 LTDescr LeanTween::moveY(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_moveY_mDB68508AA65AA60664BD88504C67E1C19280BF8F ();
// 0x000001E3 LTDescr LeanTween::moveZ(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_moveZ_mA88DB12D1B560DEBEF3822E66A7F430CDDAC5ADF ();
// 0x000001E4 LTDescr LeanTween::moveLocal(UnityEngine.GameObject,UnityEngine.Vector3,System.Single)
extern void LeanTween_moveLocal_m3E132ADE8326ABF739CDB038339FDB97D0303DA0 ();
// 0x000001E5 LTDescr LeanTween::moveLocal(UnityEngine.GameObject,UnityEngine.Vector3[],System.Single)
extern void LeanTween_moveLocal_m4327F0E883DE6249410B02ED3C54371CA0441F49 ();
// 0x000001E6 LTDescr LeanTween::moveLocalX(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_moveLocalX_m232E69D8A2E986B208E2526484CE913F394562C3 ();
// 0x000001E7 LTDescr LeanTween::moveLocalY(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_moveLocalY_m81984CF3A6A7916DF3A0B6927CFE4D6EF3412CB9 ();
// 0x000001E8 LTDescr LeanTween::moveLocalZ(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_moveLocalZ_m5554E85ABCFA94D7490FBB94C6CBAEB1FE8BFE78 ();
// 0x000001E9 LTDescr LeanTween::moveLocal(UnityEngine.GameObject,LTBezierPath,System.Single)
extern void LeanTween_moveLocal_m447BA213D7DAF630C34246A2FDE762D381C0717C ();
// 0x000001EA LTDescr LeanTween::moveLocal(UnityEngine.GameObject,LTSpline,System.Single)
extern void LeanTween_moveLocal_m7DD323A3A22C0A7A60D7A317070CC065FA1B8592 ();
// 0x000001EB LTDescr LeanTween::move(UnityEngine.GameObject,UnityEngine.Transform,System.Single)
extern void LeanTween_move_m2127590D6E19C76397E626EAE1B6782458680EA7 ();
// 0x000001EC LTDescr LeanTween::rotate(UnityEngine.GameObject,UnityEngine.Vector3,System.Single)
extern void LeanTween_rotate_m8579E373F5CF4C8D7CFBE21F589A01C136A622B9 ();
// 0x000001ED LTDescr LeanTween::rotate(LTRect,System.Single,System.Single)
extern void LeanTween_rotate_m59F38DEE77FA560A392486AF379B5336F3E1C43E ();
// 0x000001EE LTDescr LeanTween::rotateLocal(UnityEngine.GameObject,UnityEngine.Vector3,System.Single)
extern void LeanTween_rotateLocal_mA0372B9346E44B2E0A1D17D2208AEDA68FF89453 ();
// 0x000001EF LTDescr LeanTween::rotateX(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_rotateX_mD4A46C2F227DDD51833EE87737B2D152A748CA36 ();
// 0x000001F0 LTDescr LeanTween::rotateY(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_rotateY_m95B50929DB57158B55689A11EC7D2571AB082130 ();
// 0x000001F1 LTDescr LeanTween::rotateZ(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_rotateZ_mDE662A3F5EB65C2B92C59F1BBB19DCADE59EDCE5 ();
// 0x000001F2 LTDescr LeanTween::rotateAround(UnityEngine.GameObject,UnityEngine.Vector3,System.Single,System.Single)
extern void LeanTween_rotateAround_m075972BBDD28C5C9CE5F9E96B8A3781171907CE0 ();
// 0x000001F3 LTDescr LeanTween::rotateAroundLocal(UnityEngine.GameObject,UnityEngine.Vector3,System.Single,System.Single)
extern void LeanTween_rotateAroundLocal_m39E570A2902DF8EF81DDA92301068BC3D41C0FC6 ();
// 0x000001F4 LTDescr LeanTween::scale(UnityEngine.GameObject,UnityEngine.Vector3,System.Single)
extern void LeanTween_scale_m739EA30AF4AFA37BC3A004C6AB6D4C86F7D70D46 ();
// 0x000001F5 LTDescr LeanTween::scale(LTRect,UnityEngine.Vector2,System.Single)
extern void LeanTween_scale_mBC5AD5DAB9B312348CEDC26C70FD3A9260053BFB ();
// 0x000001F6 LTDescr LeanTween::scaleX(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_scaleX_m2A780B8533FBBA2E301770CFE263982CFF037E22 ();
// 0x000001F7 LTDescr LeanTween::scaleY(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_scaleY_m24D433E4DEDC75CACAD69DF2FD8E38121B5A94E6 ();
// 0x000001F8 LTDescr LeanTween::scaleZ(UnityEngine.GameObject,System.Single,System.Single)
extern void LeanTween_scaleZ_m98FD178C8100B06FD8AB5D179ADBFD36763DEF46 ();
// 0x000001F9 LTDescr LeanTween::value(UnityEngine.GameObject,System.Single,System.Single,System.Single)
extern void LeanTween_value_mD0197FA9C5DFAF3B3D051D779A8E34065F2542D5 ();
// 0x000001FA LTDescr LeanTween::value(System.Single,System.Single,System.Single)
extern void LeanTween_value_m543D884136BEDE2B5BF23A55D9FAD8A0843A335F ();
// 0x000001FB LTDescr LeanTween::value(UnityEngine.GameObject,UnityEngine.Vector2,UnityEngine.Vector2,System.Single)
extern void LeanTween_value_m8F117786FCC178168C85394998199CFAE7DFB4ED ();
// 0x000001FC LTDescr LeanTween::value(UnityEngine.GameObject,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void LeanTween_value_m68A54C69FA47C71E8521261C618ED157D571137D ();
// 0x000001FD LTDescr LeanTween::value(UnityEngine.GameObject,UnityEngine.Color,UnityEngine.Color,System.Single)
extern void LeanTween_value_m60DD684C801E4822E2D5620D89F0E8853BFA5923 ();
// 0x000001FE LTDescr LeanTween::value(UnityEngine.GameObject,System.Action`1<System.Single>,System.Single,System.Single,System.Single)
extern void LeanTween_value_m140AEB84C489042A3011D78E12AB63845807CBBE ();
// 0x000001FF LTDescr LeanTween::value(UnityEngine.GameObject,System.Action`2<System.Single,System.Single>,System.Single,System.Single,System.Single)
extern void LeanTween_value_mDE8B16907861A420025C6100630CCDBE82305CEE ();
// 0x00000200 LTDescr LeanTween::value(UnityEngine.GameObject,System.Action`1<UnityEngine.Color>,UnityEngine.Color,UnityEngine.Color,System.Single)
extern void LeanTween_value_m05610B233159B942C81B25E962680B7C438A8E29 ();
// 0x00000201 LTDescr LeanTween::value(UnityEngine.GameObject,System.Action`2<UnityEngine.Color,System.Object>,UnityEngine.Color,UnityEngine.Color,System.Single)
extern void LeanTween_value_m49C9E0FA5D72E29C8C0D28832A669C55C267726F ();
// 0x00000202 LTDescr LeanTween::value(UnityEngine.GameObject,System.Action`1<UnityEngine.Vector2>,UnityEngine.Vector2,UnityEngine.Vector2,System.Single)
extern void LeanTween_value_m4F5BAE774B4560F6993681D61B3250C8A7496E74 ();
// 0x00000203 LTDescr LeanTween::value(UnityEngine.GameObject,System.Action`1<UnityEngine.Vector3>,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void LeanTween_value_m4429FAF1696ACFC07E604159A2FAC9F5980871DB ();
// 0x00000204 LTDescr LeanTween::value(UnityEngine.GameObject,System.Action`2<System.Single,System.Object>,System.Single,System.Single,System.Single)
extern void LeanTween_value_mD6D20DA483B48ABD8E9E22BEC30A55AE10AC30E1 ();
// 0x00000205 LTDescr LeanTween::delayedSound(UnityEngine.AudioClip,UnityEngine.Vector3,System.Single)
extern void LeanTween_delayedSound_mBAF8BA749D1D0BEA04684EDE697644551C204DF1 ();
// 0x00000206 LTDescr LeanTween::delayedSound(UnityEngine.GameObject,UnityEngine.AudioClip,UnityEngine.Vector3,System.Single)
extern void LeanTween_delayedSound_mE638A9BC5F7E0861274946CA95966ED8F80E4D0D ();
// 0x00000207 LTDescr LeanTween::move(UnityEngine.RectTransform,UnityEngine.Vector3,System.Single)
extern void LeanTween_move_mE2791E0F813767A2F4CC46C57BD8D06BDE763D24 ();
// 0x00000208 LTDescr LeanTween::moveX(UnityEngine.RectTransform,System.Single,System.Single)
extern void LeanTween_moveX_m62C418E8EB73D6BDBE3C8E684D64E3CCB860EC9F ();
// 0x00000209 LTDescr LeanTween::moveY(UnityEngine.RectTransform,System.Single,System.Single)
extern void LeanTween_moveY_m9A245FE8A6072EA7383DCEE62970211B04AE1427 ();
// 0x0000020A LTDescr LeanTween::moveZ(UnityEngine.RectTransform,System.Single,System.Single)
extern void LeanTween_moveZ_mD0886ED74150075AA4231F9AE84A87F9ED53CE7B ();
// 0x0000020B LTDescr LeanTween::rotate(UnityEngine.RectTransform,System.Single,System.Single)
extern void LeanTween_rotate_mD96AE259C7FB374F9409994108FDC12A113F30C3 ();
// 0x0000020C LTDescr LeanTween::rotate(UnityEngine.RectTransform,UnityEngine.Vector3,System.Single)
extern void LeanTween_rotate_mE154DFD915B26150B1D77329AADF8F0260AD0408 ();
// 0x0000020D LTDescr LeanTween::rotateAround(UnityEngine.RectTransform,UnityEngine.Vector3,System.Single,System.Single)
extern void LeanTween_rotateAround_m5A922CC08D9228288F71F7E05D65F414DF285848 ();
// 0x0000020E LTDescr LeanTween::rotateAroundLocal(UnityEngine.RectTransform,UnityEngine.Vector3,System.Single,System.Single)
extern void LeanTween_rotateAroundLocal_m25AF19B0B02DF4489ED8940E4784D4B473CEB694 ();
// 0x0000020F LTDescr LeanTween::scale(UnityEngine.RectTransform,UnityEngine.Vector3,System.Single)
extern void LeanTween_scale_mA79AFFE211A8C69E7E1F515733EFFAB13C5B9497 ();
// 0x00000210 LTDescr LeanTween::size(UnityEngine.RectTransform,UnityEngine.Vector2,System.Single)
extern void LeanTween_size_mF755BD8B4C33948A9602064FD07B825ADE9AEDFA ();
// 0x00000211 LTDescr LeanTween::alpha(UnityEngine.RectTransform,System.Single,System.Single)
extern void LeanTween_alpha_m0E7667CE8AA06EF2FF9BDDD82D1682C0B19DABE4 ();
// 0x00000212 LTDescr LeanTween::color(UnityEngine.RectTransform,UnityEngine.Color,System.Single)
extern void LeanTween_color_m76E6D929746BB8A4993C6035FA752743E120DEA6 ();
// 0x00000213 System.Single LeanTween::tweenOnCurve(LTDescr,System.Single)
extern void LeanTween_tweenOnCurve_m776AD911BC063EA4759FA9E681200B39AEA3CDDF ();
// 0x00000214 UnityEngine.Vector3 LeanTween::tweenOnCurveVector(LTDescr,System.Single)
extern void LeanTween_tweenOnCurveVector_m8D3F80D7DE085480864A1CF28F46EF1D1B7AC5C9 ();
// 0x00000215 System.Single LeanTween::easeOutQuadOpt(System.Single,System.Single,System.Single)
extern void LeanTween_easeOutQuadOpt_m8E383A24ED2C57B96DD8B8B1C0CFA111FCB1E66A ();
// 0x00000216 System.Single LeanTween::easeInQuadOpt(System.Single,System.Single,System.Single)
extern void LeanTween_easeInQuadOpt_m4DB2CBF07DA62DF06320D2AE4D126A7D34307AB1 ();
// 0x00000217 System.Single LeanTween::easeInOutQuadOpt(System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutQuadOpt_mFE7A2D8E853E9B3CE34D4EDE9C4EEB2A4795AB3F ();
// 0x00000218 UnityEngine.Vector3 LeanTween::easeInOutQuadOpt(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void LeanTween_easeInOutQuadOpt_m401BAA3AF8856E0D688C9FDA0F8BEA5B9D21BC91 ();
// 0x00000219 System.Single LeanTween::linear(System.Single,System.Single,System.Single)
extern void LeanTween_linear_mBA6922D37F646B5776990E0CB83871AF4276729B ();
// 0x0000021A System.Single LeanTween::clerp(System.Single,System.Single,System.Single)
extern void LeanTween_clerp_mEA2E00AB23E44AA9A5D4B6B317C1862E13FFE5C4 ();
// 0x0000021B System.Single LeanTween::spring(System.Single,System.Single,System.Single)
extern void LeanTween_spring_m38AD603E3723B65EB126F7CA2CD94A4F196A9CDF ();
// 0x0000021C System.Single LeanTween::easeInQuad(System.Single,System.Single,System.Single)
extern void LeanTween_easeInQuad_m67F21D89F55668292BAAE34FFE6C12B58998B280 ();
// 0x0000021D System.Single LeanTween::easeOutQuad(System.Single,System.Single,System.Single)
extern void LeanTween_easeOutQuad_mA3C32215EB43C534EF7C5EE5284A831E60BEAE71 ();
// 0x0000021E System.Single LeanTween::easeInOutQuad(System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutQuad_m14632B3E09C2072566F37B8DFB26E7F510020A6D ();
// 0x0000021F System.Single LeanTween::easeInOutQuadOpt2(System.Single,System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutQuadOpt2_m3499560A61B028FDA940456BFAC3FA33BA168589 ();
// 0x00000220 System.Single LeanTween::easeInCubic(System.Single,System.Single,System.Single)
extern void LeanTween_easeInCubic_m1730FCFDCCD6522AA5EF75071FDBEFCA6BC38AA0 ();
// 0x00000221 System.Single LeanTween::easeOutCubic(System.Single,System.Single,System.Single)
extern void LeanTween_easeOutCubic_mA7478B119FECD286374C6BA2D7F90AFDDDD63286 ();
// 0x00000222 System.Single LeanTween::easeInOutCubic(System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutCubic_mCB8CAD056E95EC6DCEC23C2A34C8ED3DCFE78B98 ();
// 0x00000223 System.Single LeanTween::easeInQuart(System.Single,System.Single,System.Single)
extern void LeanTween_easeInQuart_mE08BC989150FFBDCDD918DD3D984C447956E2FD5 ();
// 0x00000224 System.Single LeanTween::easeOutQuart(System.Single,System.Single,System.Single)
extern void LeanTween_easeOutQuart_m025D63DFB1B1552FD16F28E8BDF89B06A8FA18E0 ();
// 0x00000225 System.Single LeanTween::easeInOutQuart(System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutQuart_mBF7B317CBB13C201D209C9B0A40C30EFC533B4CC ();
// 0x00000226 System.Single LeanTween::easeInQuint(System.Single,System.Single,System.Single)
extern void LeanTween_easeInQuint_m15438DA1E946FECD15032016C913685108C0029D ();
// 0x00000227 System.Single LeanTween::easeOutQuint(System.Single,System.Single,System.Single)
extern void LeanTween_easeOutQuint_mC0CEE37C8AF32D7030823C31BB1B191D39AECA0F ();
// 0x00000228 System.Single LeanTween::easeInOutQuint(System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutQuint_mDCC4325CD1564F24DE41D945892879CF51ABD098 ();
// 0x00000229 System.Single LeanTween::easeInSine(System.Single,System.Single,System.Single)
extern void LeanTween_easeInSine_mDFEF9079CDFF383174459C45749DBD8DDB528B51 ();
// 0x0000022A System.Single LeanTween::easeOutSine(System.Single,System.Single,System.Single)
extern void LeanTween_easeOutSine_mDC74EC7F0DF54586E2CBDD8DD22D78EF43E56A3D ();
// 0x0000022B System.Single LeanTween::easeInOutSine(System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutSine_mCC2C711E07ACA35228B944175B54BDC6A7DC4A62 ();
// 0x0000022C System.Single LeanTween::easeInExpo(System.Single,System.Single,System.Single)
extern void LeanTween_easeInExpo_m220BC432A261CA38493290ED9087A960D03034B3 ();
// 0x0000022D System.Single LeanTween::easeOutExpo(System.Single,System.Single,System.Single)
extern void LeanTween_easeOutExpo_mBD7964251D9A744887B37462F942A0698FDE97DA ();
// 0x0000022E System.Single LeanTween::easeInOutExpo(System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutExpo_mF89D29E1B383D0093637085A738C8D40A85BB63F ();
// 0x0000022F System.Single LeanTween::easeInCirc(System.Single,System.Single,System.Single)
extern void LeanTween_easeInCirc_m9F0D3D8619CBB5BD13267AD4AB5CFDCA4E9AA3DB ();
// 0x00000230 System.Single LeanTween::easeOutCirc(System.Single,System.Single,System.Single)
extern void LeanTween_easeOutCirc_m63747063777CC1CA68337F3A485412B6C4174991 ();
// 0x00000231 System.Single LeanTween::easeInOutCirc(System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutCirc_m563FCB27BEFFB2825792656D2BC9D0C12FE49C1B ();
// 0x00000232 System.Single LeanTween::easeInBounce(System.Single,System.Single,System.Single)
extern void LeanTween_easeInBounce_m78927E38CE9890042BF57410D62E16E47BF06B1F ();
// 0x00000233 System.Single LeanTween::easeOutBounce(System.Single,System.Single,System.Single)
extern void LeanTween_easeOutBounce_m4D65F9794140223F756CD3FE37F006F3194187B9 ();
// 0x00000234 System.Single LeanTween::easeInOutBounce(System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutBounce_m8BC95110D4ACB33CC1998C0CB6F0587AC4E928F8 ();
// 0x00000235 System.Single LeanTween::easeInBack(System.Single,System.Single,System.Single,System.Single)
extern void LeanTween_easeInBack_m688ED71D95DFBA782F78B75931519C4500646703 ();
// 0x00000236 System.Single LeanTween::easeOutBack(System.Single,System.Single,System.Single,System.Single)
extern void LeanTween_easeOutBack_m807628E8A23993D9D95FE4E7FB92F267B03584BF ();
// 0x00000237 System.Single LeanTween::easeInOutBack(System.Single,System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutBack_mA633B3918EEA109AC13372AE59A76CB539B546D8 ();
// 0x00000238 System.Single LeanTween::easeInElastic(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void LeanTween_easeInElastic_mB5BEF56CAA1CC94BFBE4A72175FF9D5EC932DEA0 ();
// 0x00000239 System.Single LeanTween::easeOutElastic(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void LeanTween_easeOutElastic_m5ED1AF8B7625181C7525220EBC3D1EE9878C0DCB ();
// 0x0000023A System.Single LeanTween::easeInOutElastic(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void LeanTween_easeInOutElastic_mFB4C482176FF749138593B83F9858DDBEE613C42 ();
// 0x0000023B System.Void LeanTween::addListener(System.Int32,System.Action`1<LTEvent>)
extern void LeanTween_addListener_m699F102351A06463B95E67B14E0498E7BC8EEDC6 ();
// 0x0000023C System.Void LeanTween::addListener(UnityEngine.GameObject,System.Int32,System.Action`1<LTEvent>)
extern void LeanTween_addListener_mC647F29B4179BCF81E60894F77C4C3EDBE7BC636 ();
// 0x0000023D System.Boolean LeanTween::removeListener(System.Int32,System.Action`1<LTEvent>)
extern void LeanTween_removeListener_mE71495E35003C6FDF3F3867CDD525F1104FA29F8 ();
// 0x0000023E System.Boolean LeanTween::removeListener(System.Int32)
extern void LeanTween_removeListener_m48C01A50155AD24E4D1B8C607CB40A4B2243189E ();
// 0x0000023F System.Boolean LeanTween::removeListener(UnityEngine.GameObject,System.Int32,System.Action`1<LTEvent>)
extern void LeanTween_removeListener_m6AA8FEDC14340D455B55977BEB795036F45DC724 ();
// 0x00000240 System.Void LeanTween::dispatchEvent(System.Int32)
extern void LeanTween_dispatchEvent_mA20EC065A68484D845BD5AAF214120E3F9A33AD2 ();
// 0x00000241 System.Void LeanTween::dispatchEvent(System.Int32,System.Object)
extern void LeanTween_dispatchEvent_m5A5DC1DAFEF4D0A1B1B8BFD7ED22137C00C9FE50 ();
// 0x00000242 System.Void LeanTween::.ctor()
extern void LeanTween__ctor_m91FB17B3114982A54E0BDAFB575DDEBC16D2A8C9 ();
// 0x00000243 System.Void LeanTween::.cctor()
extern void LeanTween__cctor_m10C7F7A5F90E383DCDECBA2B3E04770CF99B511B ();
// 0x00000244 UnityEngine.Vector3[] LTUtility::reverse(UnityEngine.Vector3[])
extern void LTUtility_reverse_m21336CE7601EAC2D252FD8B00B2DCD93CDAE575F ();
// 0x00000245 System.Void LTUtility::.ctor()
extern void LTUtility__ctor_m5A5020E9B63AAABC97BE9058B9D6D90570511804 ();
// 0x00000246 System.Void LTBezier::.ctor(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void LTBezier__ctor_m917F93EBEEF53FAB301E23523CC6CC7468091BCC ();
// 0x00000247 System.Single LTBezier::map(System.Single)
extern void LTBezier_map_m8B9A4E27E56006EC65CE568154945119539BEAE7 ();
// 0x00000248 UnityEngine.Vector3 LTBezier::bezierPoint(System.Single)
extern void LTBezier_bezierPoint_m6FC5494E00B9D5563BEF7207F8C05C6911799D12 ();
// 0x00000249 UnityEngine.Vector3 LTBezier::point(System.Single)
extern void LTBezier_point_m2F8178CB6443451464F12CC05080747D1E63265B ();
// 0x0000024A System.Void LTBezierPath::.ctor()
extern void LTBezierPath__ctor_m1BA2781962EF25988B97D9D998018CC1CD4F4C0D ();
// 0x0000024B System.Void LTBezierPath::.ctor(UnityEngine.Vector3[])
extern void LTBezierPath__ctor_m8D9B32285ADA3C785CF841C3D480C0EA17B6C98D ();
// 0x0000024C System.Void LTBezierPath::setPoints(UnityEngine.Vector3[])
extern void LTBezierPath_setPoints_m02CC21FE86E5CCE0E4BCC0DB0D018ACA9757329A ();
// 0x0000024D System.Single LTBezierPath::get_distance()
extern void LTBezierPath_get_distance_mFCD927E71FA246B477108A8D773A6CE82F7F9D2E ();
// 0x0000024E UnityEngine.Vector3 LTBezierPath::point(System.Single)
extern void LTBezierPath_point_m41590CE29A37A8DFC0B874C364254F57A46D2F09 ();
// 0x0000024F System.Void LTBezierPath::place2d(UnityEngine.Transform,System.Single)
extern void LTBezierPath_place2d_m0961B85CE36658D0AEB3F06BF4458773FA9DEEBF ();
// 0x00000250 System.Void LTBezierPath::placeLocal2d(UnityEngine.Transform,System.Single)
extern void LTBezierPath_placeLocal2d_m2AA2ABC9150443DE02DC921C84F71407A77E267B ();
// 0x00000251 System.Void LTBezierPath::place(UnityEngine.Transform,System.Single)
extern void LTBezierPath_place_mA3774BBDD387A39BD03C0F52C72B59A7130DBF79 ();
// 0x00000252 System.Void LTBezierPath::place(UnityEngine.Transform,System.Single,UnityEngine.Vector3)
extern void LTBezierPath_place_m5E58DFDE9FD3ED69AB3F81CA00D841D52EEB580D ();
// 0x00000253 System.Void LTBezierPath::placeLocal(UnityEngine.Transform,System.Single)
extern void LTBezierPath_placeLocal_mDF095DCC3DA2A678411E6762C814C4E43DD29EC4 ();
// 0x00000254 System.Void LTBezierPath::placeLocal(UnityEngine.Transform,System.Single,UnityEngine.Vector3)
extern void LTBezierPath_placeLocal_m2A89BD719A350ABACA3D881E7A35E23DCF7D94A8 ();
// 0x00000255 System.Void LTBezierPath::gizmoDraw(System.Single)
extern void LTBezierPath_gizmoDraw_m456CDA5CAEAE2F0CC869A1285E3ECF579BD328AE ();
// 0x00000256 System.Void LTSpline::.ctor(UnityEngine.Vector3[])
extern void LTSpline__ctor_m57C75A7B8A4DD275D39935B860C1E181B5CE9B83 ();
// 0x00000257 System.Void LTSpline::.ctor(UnityEngine.Vector3[],System.Boolean)
extern void LTSpline__ctor_m4D4F4871CFD23663418689B95A5FB8BC8C49AC28 ();
// 0x00000258 System.Void LTSpline::init(UnityEngine.Vector3[],System.Boolean)
extern void LTSpline_init_mE4FD1F1E23FA489692A0D9C97716A7E7DA21C742 ();
// 0x00000259 UnityEngine.Vector3 LTSpline::map(System.Single)
extern void LTSpline_map_m374A1DB30E3C325A376A4FA8B1BEA799C7E93C72 ();
// 0x0000025A UnityEngine.Vector3 LTSpline::interp(System.Single)
extern void LTSpline_interp_m6FCAD1CB86CB45F93419A7FF5C82191DF3C094E4 ();
// 0x0000025B System.Single LTSpline::ratioAtPoint(UnityEngine.Vector3)
extern void LTSpline_ratioAtPoint_m97359CDB153D0E9EF641DEA126089B19495EDC07 ();
// 0x0000025C UnityEngine.Vector3 LTSpline::point(System.Single)
extern void LTSpline_point_m7896374FB44B666DA3AA72CEC832D01BDD44AA5B ();
// 0x0000025D System.Void LTSpline::place2d(UnityEngine.Transform,System.Single)
extern void LTSpline_place2d_m410FE485D771784283F6F5F4576B7B1F332CB770 ();
// 0x0000025E System.Void LTSpline::placeLocal2d(UnityEngine.Transform,System.Single)
extern void LTSpline_placeLocal2d_m33577AAE988A28259886F5492DC86A7849D6690B ();
// 0x0000025F System.Void LTSpline::place(UnityEngine.Transform,System.Single)
extern void LTSpline_place_mA6D3930CB0B5968C41C1033F903962C27DE51F2F ();
// 0x00000260 System.Void LTSpline::place(UnityEngine.Transform,System.Single,UnityEngine.Vector3)
extern void LTSpline_place_mDB4D0DB4E883DFDF719A5AA6569B35C7A43A66FD ();
// 0x00000261 System.Void LTSpline::placeLocal(UnityEngine.Transform,System.Single)
extern void LTSpline_placeLocal_m5567A3535873B5A8F2486DD8F6BBA4E8ACC5C121 ();
// 0x00000262 System.Void LTSpline::placeLocal(UnityEngine.Transform,System.Single,UnityEngine.Vector3)
extern void LTSpline_placeLocal_m8DED20C2B16AA8498AA4577A5EA50A40EFAE8B34 ();
// 0x00000263 System.Void LTSpline::gizmoDraw(System.Single)
extern void LTSpline_gizmoDraw_mB244CD15DB748BB8E9BA3352C115EEA8D239B341 ();
// 0x00000264 System.Void LTSpline::drawGizmo(UnityEngine.Color)
extern void LTSpline_drawGizmo_m0678C5E327878D4B699C7C09D4978E5CE61AA792 ();
// 0x00000265 System.Void LTSpline::drawGizmo(UnityEngine.Transform[],UnityEngine.Color)
extern void LTSpline_drawGizmo_mF2B8532F54C8641D182E90AD79BBE9A79FD8224F ();
// 0x00000266 System.Void LTSpline::drawLine(UnityEngine.Transform[],System.Single,UnityEngine.Color)
extern void LTSpline_drawLine_mE5283611D4173190FB6AD7BE71C75DDB444C7BB8 ();
// 0x00000267 System.Void LTSpline::drawLinesGLLines(UnityEngine.Material,UnityEngine.Color,System.Single)
extern void LTSpline_drawLinesGLLines_m07A015A9E0E74A39E24595E58760EA53F4DAC4EB ();
// 0x00000268 UnityEngine.Vector3[] LTSpline::generateVectors()
extern void LTSpline_generateVectors_m731F7320C9D1709CBD87C4C4936EC7187EB6904B ();
// 0x00000269 System.Void LTSpline::.cctor()
extern void LTSpline__cctor_m4F7F089258AD535EDE163AEB30B22F5BF1891CD8 ();
// 0x0000026A System.Void LTRect::.ctor()
extern void LTRect__ctor_mCA1C09BE881F539C97297E17938568350DAE6ED9 ();
// 0x0000026B System.Void LTRect::.ctor(UnityEngine.Rect)
extern void LTRect__ctor_m095A13A871AD1EA6986CDAAAABA9C968CA14844E ();
// 0x0000026C System.Void LTRect::.ctor(System.Single,System.Single,System.Single,System.Single)
extern void LTRect__ctor_m195E97F5ED6A3CC825784C21D78CA3BF97BB6E57 ();
// 0x0000026D System.Void LTRect::.ctor(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void LTRect__ctor_m749D7BA32AF1BA250E0C21F16B6C94600CD63EFF ();
// 0x0000026E System.Void LTRect::.ctor(System.Single,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void LTRect__ctor_m73F6C1A371C27FACAA710BB8D2C0FB254B7CA813 ();
// 0x0000026F System.Boolean LTRect::get_hasInitiliazed()
extern void LTRect_get_hasInitiliazed_m9F06A8057DB0CA4E23C10C71D132FB5692A30A66 ();
// 0x00000270 System.Int32 LTRect::get_id()
extern void LTRect_get_id_m769D3243B7A2895AB1D71D4C7A242E848394D42F ();
// 0x00000271 System.Void LTRect::setId(System.Int32,System.Int32)
extern void LTRect_setId_mF3088916CC145F19794DB82B96C297CF6ABF6174 ();
// 0x00000272 System.Void LTRect::reset()
extern void LTRect_reset_m19E8588FBA4D5083CF8C36FBFA8E7E131461CCE7 ();
// 0x00000273 System.Void LTRect::resetForRotation()
extern void LTRect_resetForRotation_m650E57A9196E7F5BE429E92E062C0FD651D1F6E9 ();
// 0x00000274 System.Single LTRect::get_x()
extern void LTRect_get_x_mC40DC8BA4720E21417D3A7C53D0C239F49566560 ();
// 0x00000275 System.Void LTRect::set_x(System.Single)
extern void LTRect_set_x_m771C3069EB5D399D2D04B37E733F8D728B67830C ();
// 0x00000276 System.Single LTRect::get_y()
extern void LTRect_get_y_mAFDE9D2D7F9C092B71158501885F02451F6CF70D ();
// 0x00000277 System.Void LTRect::set_y(System.Single)
extern void LTRect_set_y_mF1F12B4ECC6E565A2FE3FDE6E3D7BB75BBEA64E6 ();
// 0x00000278 System.Single LTRect::get_width()
extern void LTRect_get_width_m03068CB4AFAE07FFEA9A119211DD957C9D262C54 ();
// 0x00000279 System.Void LTRect::set_width(System.Single)
extern void LTRect_set_width_mF83A197741856B6718D4ACBC15BEAA4B63BB6628 ();
// 0x0000027A System.Single LTRect::get_height()
extern void LTRect_get_height_mB37BB9F1BC71FFB3832BBF6A4FDB4A040661CC4F ();
// 0x0000027B System.Void LTRect::set_height(System.Single)
extern void LTRect_set_height_m6E3290369AD12E197D6CD4FDBF586F57DF2B0764 ();
// 0x0000027C UnityEngine.Rect LTRect::get_rect()
extern void LTRect_get_rect_m179868C83A6FCE9A3D55AAA8587C8DA9D55140EE ();
// 0x0000027D System.Void LTRect::set_rect(UnityEngine.Rect)
extern void LTRect_set_rect_mF0B36BB4EACABC706AA56D6F8111BBCCFDEFEF98 ();
// 0x0000027E LTRect LTRect::setStyle(UnityEngine.GUIStyle)
extern void LTRect_setStyle_m48AAA6B56520E43334D0686F33BD1DBA84F65083 ();
// 0x0000027F LTRect LTRect::setFontScaleToFit(System.Boolean)
extern void LTRect_setFontScaleToFit_m06F0A6C039B06293EC372E6E827AF284298B4017 ();
// 0x00000280 LTRect LTRect::setColor(UnityEngine.Color)
extern void LTRect_setColor_m52BD1DF2FD06021D28437530E5F5B533809D1778 ();
// 0x00000281 LTRect LTRect::setAlpha(System.Single)
extern void LTRect_setAlpha_mAD1DF3137FFA8A8C90D7A0E0D3E5F14556FAFB93 ();
// 0x00000282 LTRect LTRect::setLabel(System.String)
extern void LTRect_setLabel_m8A92CE82745515509BB490DB462FC24839DF1D8E ();
// 0x00000283 LTRect LTRect::setUseSimpleScale(System.Boolean,UnityEngine.Rect)
extern void LTRect_setUseSimpleScale_mF46837DE51C3C1C2683B41B09D73EA5825576893 ();
// 0x00000284 LTRect LTRect::setUseSimpleScale(System.Boolean)
extern void LTRect_setUseSimpleScale_m927734D2B166FF4FAD2C6B7F22588A1922BD8CEC ();
// 0x00000285 LTRect LTRect::setSizeByHeight(System.Boolean)
extern void LTRect_setSizeByHeight_mAB77E3AF24A68A8623798E36EA1D3F7C360A48DD ();
// 0x00000286 System.String LTRect::ToString()
extern void LTRect_ToString_m4CBED2414A03DE4BCA7CF7B07393C82FE9282868 ();
// 0x00000287 System.Void LTEvent::.ctor(System.Int32,System.Object)
extern void LTEvent__ctor_m2E02BCB485BA1431D084EE07A9CA62610077BC14 ();
// 0x00000288 System.Void LTGUI::init()
extern void LTGUI_init_m0B5EF6B79A1842DA9C5D159A3E5E465D9BB28FFB ();
// 0x00000289 System.Void LTGUI::initRectCheck()
extern void LTGUI_initRectCheck_m3367481975F938E51C6398EC581DAB5FC44E1B92 ();
// 0x0000028A System.Void LTGUI::reset()
extern void LTGUI_reset_m20BBE8C12F7FBD549796BDE6913CD5B8D3BC6383 ();
// 0x0000028B System.Void LTGUI::update(System.Int32)
extern void LTGUI_update_mA03FFD6F752B1A5200404A9CB9B73BA2D56947D7 ();
// 0x0000028C System.Boolean LTGUI::checkOnScreen(UnityEngine.Rect)
extern void LTGUI_checkOnScreen_m14046195B38A177908CDCD26A86E958C3CFEF056 ();
// 0x0000028D System.Void LTGUI::destroy(System.Int32)
extern void LTGUI_destroy_m2E32BE2936E5B392A089B897AE62E470436B9F4F ();
// 0x0000028E System.Void LTGUI::destroyAll(System.Int32)
extern void LTGUI_destroyAll_mBB9E21626996F00AB7E73992688F8C1E7DEAB613 ();
// 0x0000028F LTRect LTGUI::label(UnityEngine.Rect,System.String,System.Int32)
extern void LTGUI_label_m64095CBE3AFAD10188CC58BE9A9423FAB3605AC1 ();
// 0x00000290 LTRect LTGUI::label(LTRect,System.String,System.Int32)
extern void LTGUI_label_m8BCF8827B449C381BDAF391C894EE0AA8B1366F7 ();
// 0x00000291 LTRect LTGUI::texture(UnityEngine.Rect,UnityEngine.Texture,System.Int32)
extern void LTGUI_texture_m254ED9B2FC116C879D75744086CEB7F5FA34522B ();
// 0x00000292 LTRect LTGUI::texture(LTRect,UnityEngine.Texture,System.Int32)
extern void LTGUI_texture_m890C67AFDE6C64F26023F63193EC55829A251BB4 ();
// 0x00000293 LTRect LTGUI::element(LTRect,System.Int32)
extern void LTGUI_element_mC8808C9F9C3BAC63F8FF1C03A03E2493611F2674 ();
// 0x00000294 System.Boolean LTGUI::hasNoOverlap(UnityEngine.Rect,System.Int32)
extern void LTGUI_hasNoOverlap_m4830FB57717717CF0C10C541A695F3B067D3F42A ();
// 0x00000295 System.Boolean LTGUI::pressedWithinRect(UnityEngine.Rect)
extern void LTGUI_pressedWithinRect_m9F9A0E240544C9BBB9A11EE82BBA0A25B0881B2A ();
// 0x00000296 System.Boolean LTGUI::checkWithinRect(UnityEngine.Vector2,UnityEngine.Rect)
extern void LTGUI_checkWithinRect_mB143E5C8869DFF898A184E65776D362FF2395197 ();
// 0x00000297 UnityEngine.Vector2 LTGUI::firstTouch()
extern void LTGUI_firstTouch_m0AA3E8EBAA270A401668B25674B66DA99E567DEB ();
// 0x00000298 System.Void LTGUI::.ctor()
extern void LTGUI__ctor_mDBF1E3C5C648439CC5DDE8ED56549D4F28906BD4 ();
// 0x00000299 System.Void LTGUI::.cctor()
extern void LTGUI__cctor_mFB30DA4BE86B7C2152E31C811FB1A81137DE9AE6 ();
// 0x0000029A System.Void DentedPixel.LeanDummy::.ctor()
extern void LeanDummy__ctor_mBFC756324C348662E8922EEF9AD0C46BE185CB2F ();
// 0x0000029B System.Void LTDescr_EaseTypeDelegate::.ctor(System.Object,System.IntPtr)
extern void EaseTypeDelegate__ctor_mE676A6C632434B869CD2DB657EE7D6B8776390AA ();
// 0x0000029C UnityEngine.Vector3 LTDescr_EaseTypeDelegate::Invoke()
extern void EaseTypeDelegate_Invoke_mF24C392FE2626B09543053FDE917DCA4B6487903 ();
// 0x0000029D System.IAsyncResult LTDescr_EaseTypeDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern void EaseTypeDelegate_BeginInvoke_m425CAA3EC4FF94B7E1ECF5D81BB84E52E0EA86E2 ();
// 0x0000029E UnityEngine.Vector3 LTDescr_EaseTypeDelegate::EndInvoke(System.IAsyncResult)
extern void EaseTypeDelegate_EndInvoke_m806D2CF9D2EC19CDAE363AF0E8937CC0D7709E07 ();
// 0x0000029F System.Void LTDescr_ActionMethodDelegate::.ctor(System.Object,System.IntPtr)
extern void ActionMethodDelegate__ctor_m15A60FF6C9652868EA6EF57DD25D7F16F7D3FBB5 ();
// 0x000002A0 System.Void LTDescr_ActionMethodDelegate::Invoke()
extern void ActionMethodDelegate_Invoke_m7806FD0721D794AD557F9859638A9242E3C21724 ();
// 0x000002A1 System.IAsyncResult LTDescr_ActionMethodDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern void ActionMethodDelegate_BeginInvoke_m47193558577E25FEB144AC88B8554A9DC9C2CFA3 ();
// 0x000002A2 System.Void LTDescr_ActionMethodDelegate::EndInvoke(System.IAsyncResult)
extern void ActionMethodDelegate_EndInvoke_m86678D6FB2B4A5A5230C085B8EDB70A6AFA7E1CA ();
// 0x000002A3 System.Void LTDescr_<>c::.cctor()
extern void U3CU3Ec__cctor_m13D7CC7D84883311C3BE86ABE3C554AD1E2C02EC ();
// 0x000002A4 System.Void LTDescr_<>c::.ctor()
extern void U3CU3Ec__ctor_m33C92385E4A83C661AF4D3253F008607BC2AF1C5 ();
// 0x000002A5 System.Void LTDescr_<>c::<setCallback>b__109_0()
extern void U3CU3Ec_U3CsetCallbackU3Eb__109_0_m168E784261080CE918956C3AF5F56102DD4772CC ();
// 0x000002A6 System.Void LTDescr_<>c::<setValue3>b__110_0()
extern void U3CU3Ec_U3CsetValue3U3Eb__110_0_m176A22EF6A79CA8261764760342CD7D6AD89ED6B ();
// 0x000002A7 System.Void LeanTester_<timeoutCheck>d__2::.ctor(System.Int32)
extern void U3CtimeoutCheckU3Ed__2__ctor_mB019F9EDA6E194AFB39FF6942CA24D39A06C9227 ();
// 0x000002A8 System.Void LeanTester_<timeoutCheck>d__2::System.IDisposable.Dispose()
extern void U3CtimeoutCheckU3Ed__2_System_IDisposable_Dispose_m689218535F12CC1F504997D0D7F9CF7FABC846C1 ();
// 0x000002A9 System.Boolean LeanTester_<timeoutCheck>d__2::MoveNext()
extern void U3CtimeoutCheckU3Ed__2_MoveNext_m3D653D4CC2A259CE79DC552A5E2CFA197AD388DE ();
// 0x000002AA System.Object LeanTester_<timeoutCheck>d__2::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CtimeoutCheckU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC9DDE351DC515AD2B3C5A865FF801CD0DFFEF422 ();
// 0x000002AB System.Void LeanTester_<timeoutCheck>d__2::System.Collections.IEnumerator.Reset()
extern void U3CtimeoutCheckU3Ed__2_System_Collections_IEnumerator_Reset_m774CD18D28886DCC54246266FC762CB3F5E80166 ();
// 0x000002AC System.Object LeanTester_<timeoutCheck>d__2::System.Collections.IEnumerator.get_Current()
extern void U3CtimeoutCheckU3Ed__2_System_Collections_IEnumerator_get_Current_mDF742379BA045E868736EDA42B64272D5C6BDE72 ();
static Il2CppMethodPointer s_methodPointers[684] = 
{
	LTDescr_get_from_m78D35CDCC70785F5C6CE56BF6DACDF864A0E154A,
	LTDescr_set_from_mA2A3DE5FA1E580963BD8887FC1BB556C701BA046,
	LTDescr_get_to_m420D67414500804A7B0ED74340739934B1162945,
	LTDescr_set_to_m799273499065B010DE8C42C33364BDBA2B80525C,
	LTDescr_get_easeInternal_mBBB8833EF0EEC8AD819D0C80F54F4114C2DAE8BC,
	LTDescr_set_easeInternal_mBE53461DC3A689CF128A6F8C8AE7C4517EB43E5F,
	LTDescr_get_initInternal_m9E7F123BEB03ACB16022CD1BF964EE607F19098D,
	LTDescr_set_initInternal_mE56619A9765A443A38EB5D9B41C90BE8E87C3544,
	LTDescr_ToString_m4F679F79020EEF9EED34A8D005DFD7118B740835,
	LTDescr__ctor_m22626F3C47487479FC8598D285244D33D6DD4E5F,
	LTDescr_cancel_mFF8E0A22B2AC338E2DB1074CF983EF32D77044D4,
	LTDescr_get_uniqueId_mCBD2BDB9081F478DC8B369BD61F4FF868625A894,
	LTDescr_get_id_m81AB80E07C8FE161D19F3BE9ED44A9EB359648A4,
	LTDescr_get_optional_m910B64FCD676A5C1C509CD068B72C73F7D017380,
	LTDescr_set_optional_m0386812024A8548BFBFB30F422667703DC2435F3,
	LTDescr_reset_m3B0B1D4A1BECA8D5D7AFCC51A8B9225D972C7167,
	LTDescr_setMoveX_m402AA3712A5050D3ED582E76FD3BF9B63ECADC33,
	LTDescr_setMoveY_mE8954E83A49F417DA9584C3D55098C4BFB1630B2,
	LTDescr_setMoveZ_mFFB63BB6A29902C4FD5F712E3152AD9676218273,
	LTDescr_setMoveLocalX_m0D2FC50834F8E3ED915FACDBCB13548A7E6363FF,
	LTDescr_setMoveLocalY_mAFBAA07C6C9E2F72C28267FF4AC05B121A79C0BE,
	LTDescr_setMoveLocalZ_mB89DC3E0BD11B820A8E643538652F9041A03CE9E,
	LTDescr_initFromInternal_m8E46DBF940B0406074656914ADAAD979A9441713,
	LTDescr_setMoveCurved_mE8BFCF92727DC625340BB412A45B1A1E7A2849E0,
	LTDescr_setMoveCurvedLocal_mAABA442CDFE85B24C02EB264BBC656C5F094ED70,
	LTDescr_setMoveSpline_mB436AD3F5A8B5F84DF87C1170BEA6A729913FE98,
	LTDescr_setMoveSplineLocal_mF45E817D7530DE54BBE391036060A94C260B2966,
	LTDescr_setScaleX_m1140E5B67917A5A402323E15630554F53C78B0CB,
	LTDescr_setScaleY_mFB75FC6F70F2962C2B11A91839A6B98A0B3743F2,
	LTDescr_setScaleZ_m55CED6D5714FFD0FAD0A64DF8B95AB363F17A444,
	LTDescr_setRotateX_m6800D95A85D500D68A998188501A07FBB6B47235,
	LTDescr_setRotateY_m2197D5E026FBD6506F43A56F1D6BC402D30184C6,
	LTDescr_setRotateZ_m754F1C216FDB8D99E50A6ED80454A4EC73F9B08C,
	LTDescr_setRotateAround_m9448891C970D47337F40370292B2EA04C7D2D125,
	LTDescr_setRotateAroundLocal_mE70C4C427853F6AB25B7A737F440DFA402E5D04C,
	LTDescr_setAlpha_m829B4982F4B2063E01782BB3149D6C6DCEDBBE5E,
	LTDescr_setTextAlpha_mCE3CEA97A82696AA35409E96311A7ECEC05AB158,
	LTDescr_setAlphaVertex_m14D7B515A5120EC37CE0F227E10A29FFFE579906,
	LTDescr_setColor_mA286D6F2E820F2671E304CE8F67AE69CBCAD16AA,
	LTDescr_setCallbackColor_m881BE50E3F047FA60488E6F8A8B121FADAC1CEEB,
	LTDescr_setTextColor_m8C93C0044CD6E3AC6E500BBE2DDC066E2476ACD2,
	LTDescr_setCanvasAlpha_mDB6D99B1B524308F2890DD00600833A71FDBA425,
	LTDescr_setCanvasGroupAlpha_m6C90EEF2B6E424F6F05F79322F176B7594C5D6E1,
	LTDescr_setCanvasColor_mE0D299B6BB0ACDE16C22301FBFBC2B3E33A188E7,
	LTDescr_setCanvasMoveX_mAD9EF00E8AFAA4CB582CCFBC1542227CE2D9563F,
	LTDescr_setCanvasMoveY_mA66FEF0817CA8B95C7765D14EBEF9F14B6123DDA,
	LTDescr_setCanvasMoveZ_m023367C10AC010545D696532C76EF0F73842DEB0,
	LTDescr_initCanvasRotateAround_m47977E1F604279D9E8A71EF9F6E90CE12A6DE859,
	LTDescr_setCanvasRotateAround_m4722C180A00F677807C1F2F07CD2DF8972B9907C,
	LTDescr_setCanvasRotateAroundLocal_m05C440234EAD0B99F97C50CF64ACA6018E4F0972,
	LTDescr_setCanvasPlaySprite_m038BB423ADE0BA5BBA3D9B02C65C071947DE0359,
	LTDescr_setCanvasMove_mA7D212EE3C5E53EF5C524635B7BDB4CD3108CEE6,
	LTDescr_setCanvasScale_m3B3BFD433039C9E8D0FC6AF0F52724BF556A4BDA,
	LTDescr_setCanvasSizeDelta_m31D8FA820C50854450973EDEF4E445001C7AD28F,
	LTDescr_callback_m46ECDAC987FEFF56067D681A449D0330985FF184,
	LTDescr_setCallback_m463C7BDB21E12791E7F3E889E64E1E1051F66D49,
	LTDescr_setValue3_mA3FE29090505B900E5E6C9E698B56293E240B12E,
	LTDescr_setMove_m98F1C5B0C7C06F382A36E756F189E1BC94B1F95B,
	LTDescr_setMoveLocal_m7D80BDEE0E8BD25C55C798468075C5FF4B57EE07,
	LTDescr_setMoveToTransform_mAD20C37E6D479457C9BE547691BDDE1F9CA8AAF0,
	LTDescr_setRotate_mA209146FC88C0126CE850B881A87AD68DB3A7F3C,
	LTDescr_setRotateLocal_mAA715477CA9552F98306851AED9C58C31E9DA689,
	LTDescr_setScale_mEB70D47029BC79C6A0A5D33A98937CFC5ABC1E63,
	LTDescr_setGUIMove_m78172C786814BBBD344FE33104E90544164BBF0D,
	LTDescr_setGUIMoveMargin_mD5D3EEAF5C7B92694544E17744A04F49DED52454,
	LTDescr_setGUIScale_m8055CF760F5CFC4A374E8351EF4BB0510CA1D513,
	LTDescr_setGUIAlpha_m7E6CB2E4D723C524BC091534DAD4F001288F2DB0,
	LTDescr_setGUIRotate_m6D458F3704FEB5AA2E03A4339C567E5C0D99E31C,
	LTDescr_setDelayedSound_m08D11FD19D6344CCC54F9D7B33CF4DB9EB610D45,
	LTDescr_init_m81950E0D1693101E6609FD57477A95DDFFB8AEF2,
	LTDescr_initSpeed_m59165798AE9820491F8857C33893E5033E2E8A45,
	LTDescr_updateNow_m848259F413F180D1F59848D23B0F718B18227DB6,
	LTDescr_updateInternal_m7B9FB2E5DE2570A84047211EE3E5281B0801AA7D,
	LTDescr_callOnCompletes_mE439CCB47B45169210C537E36561CF64F4330736,
	LTDescr_setFromColor_m35481AA1A2866C74F7FA16BED58FA6A22B25D8D9,
	LTDescr_alphaRecursive_m986E47DD08566B89873BA8EB49B5779EF3A104F0,
	LTDescr_colorRecursive_m2DC4704B9D940297192C2F5372E85C3C9C4AD1E6,
	LTDescr_alphaRecursive_m4D75C97463DA1F1E3C045853F451FC102074E7E8,
	LTDescr_alphaRecursiveSprite_mC46FCB3AD0F777D8DBF0A7EA8DC4D17710EDD4A3,
	LTDescr_colorRecursiveSprite_m0A52BBFBB1FA0AB3844D5BBAD0F48BDC34231393,
	LTDescr_colorRecursive_m47C878C8399404D538E30939F1DDBC6AD76CE725,
	LTDescr_textAlphaChildrenRecursive_m16EF87F680E7AB2CC466F8507C26C4F0D73323E5,
	LTDescr_textAlphaRecursive_m26865107C9DEECA24A4D89CC111033A67B8A8D18,
	LTDescr_textColorRecursive_m8F3C7D2B0FE5AFEEE0E17E774887AAA8ACAE6C00,
	LTDescr_tweenColor_m5165F9B2E6EBADFDAA730B2B15188AC10A9B8BCD,
	LTDescr_pause_mE89497C343C0F4D95B265DE7262A25E836E0F4E2,
	LTDescr_resume_mC1535DDB45FBBEB15F31110F7398EBDB762D5EEF,
	LTDescr_setAxis_mBD4316513D9DEE6FED4F3FFC01AAB16C6D671C7B,
	LTDescr_setDelay_m17C575E82E7ECB6111AE6124BD177A2A5F97C6FB,
	LTDescr_setEase_m7B66587D7B2A0B4B65F2FB78BA2B5E26C688D301,
	LTDescr_setEaseLinear_m54F00A11167F1B04E0D1A2C1C7A438EEA31061B6,
	LTDescr_setEaseSpring_m813031BE3866C204428395FE7E4144540FA884EF,
	LTDescr_setEaseInQuad_mA097964ACE48F45F234C5F2ED1037A6F53AA6C27,
	LTDescr_setEaseOutQuad_m9EC32659C4A5DCE1A0B2F3217876E52DEC19B21B,
	LTDescr_setEaseInOutQuad_mC44A80958D233577C043C8E0FE57497C0D23123A,
	LTDescr_setEaseInCubic_m19A5750D6ACE144DFC2B11B26FA2AAE069B46262,
	LTDescr_setEaseOutCubic_mE4CFCA71B600BE22ADE6FF47ED415E762A348FBB,
	LTDescr_setEaseInOutCubic_mD01FBD63A0C967050CAD77057B209CF9F6191134,
	LTDescr_setEaseInQuart_m6056CCCFB1813FEBC597DA15A53EA2FCAE7FE2AF,
	LTDescr_setEaseOutQuart_mFC521D3DE137DCAB7F1CE063F7540DF360E1D999,
	LTDescr_setEaseInOutQuart_mDC47FB39F8E6ED5CA7CD9055BE38F8522D2AF948,
	LTDescr_setEaseInQuint_mB05AE487A295E2488C79B4AD74F8D0ED52DDE241,
	LTDescr_setEaseOutQuint_m9CEE0F934808B802AABE6AB8CAF09B6DAE958F8E,
	LTDescr_setEaseInOutQuint_m41949483F235FE3F4A73C43E80CA5EF0977DE7DC,
	LTDescr_setEaseInSine_mD85621F8246B6A61D79CA27A226B5FE7166CF4C3,
	LTDescr_setEaseOutSine_m45532255622E889E6AB63FF652C3FF342588C46A,
	LTDescr_setEaseInOutSine_m9AB3C9E802D35012D708D71787A4659C7FA61C78,
	LTDescr_setEaseInExpo_mCA94F6EBDCD664F85721E529016FFE2207DF4D56,
	LTDescr_setEaseOutExpo_m42DAB1DF8CD2DE65D23F9B4CBF5BECF84D993338,
	LTDescr_setEaseInOutExpo_m0655C5D6536F4E4D8133AC773FB855FD69CE8601,
	LTDescr_setEaseInCirc_m270A3181AF137B8C844EE3E1D19D9976D75147A7,
	LTDescr_setEaseOutCirc_m37ADA9FAB0D04C3A02D0984EA19243302FADB8B9,
	LTDescr_setEaseInOutCirc_mC577B629AB997F700B3471D6C0AA6B475D786490,
	LTDescr_setEaseInBounce_m3CDAC77964FC337FE22D6F6B6AB59A2D9F4D2861,
	LTDescr_setEaseOutBounce_m9159FC0EC260819215E356BE03BD28B4D12E65D3,
	LTDescr_setEaseInOutBounce_m74F9B21439AFB4A6739AAC9EE85EACA8A0E36056,
	LTDescr_setEaseInBack_m96C8AB183C1EFA6BF49476E617863F0DE05CF2C8,
	LTDescr_setEaseOutBack_mDD43652F56DF575D17928B384373D105384EF0C2,
	LTDescr_setEaseInOutBack_m246AB15A49AF3C62EA9F9587867FDEABE45A0D52,
	LTDescr_setEaseInElastic_m90B4ECA35E49E37787DF96800FD855CA4E7ECE76,
	LTDescr_setEaseOutElastic_m24CC0CF30EE6D3A083B37A9AC206A66A7485F8AB,
	LTDescr_setEaseInOutElastic_m6F8CE494EFAC887A2B794E3A0E27AD0E7AADA726,
	LTDescr_setEasePunch_m79DB407F1E11BAEA43ACF288F8E7586B2A7D5B00,
	LTDescr_setEaseShake_m333BFD09A98BD76134E18DDCDE914E72843F58B9,
	LTDescr_tweenOnCurve_mCD59533C5731F409AC279B1811EED54E49411A67,
	LTDescr_easeInOutQuad_m6915DDAD37762681D5AD14BA399C455B5C11BD7A,
	LTDescr_easeInQuad_m60D0ED9140AB90832338F7E2062F3E0760509048,
	LTDescr_easeOutQuad_mCF7D63D6090F492162F9B5C17D56FE36DDD83A24,
	LTDescr_easeLinear_m22F31F2A8634CD3FB1D6E238E6F6DB33BA98B866,
	LTDescr_easeSpring_m5F2EBD9FFC333CFC978A49FE77D81BFF643396B4,
	LTDescr_easeInCubic_m0B740991790EAF32CD91DE076C4CBF0297512608,
	LTDescr_easeOutCubic_m0AD929484DB35F292F299C0DF8DA4282A60FE333,
	LTDescr_easeInOutCubic_mAB1FAACFBE99695FB0119C8B44B4F66E0E66CF6E,
	LTDescr_easeInQuart_m6B35D5660B4A98E968E60355F56BF216DAF343AB,
	LTDescr_easeOutQuart_mC97B6E5DB20D3464395A40A83CA344C3A89A54E0,
	LTDescr_easeInOutQuart_m996E4A8C5B440A365092702098D1B407FAD12FF0,
	LTDescr_easeInQuint_m65CAACB87841DC6A3201ABB58FAA2D292C551047,
	LTDescr_easeOutQuint_mDA4580526D49B9A10AB75415F531CF8790AE3290,
	LTDescr_easeInOutQuint_m2F45C6D073399C6171076FB42B99A558D9A86F43,
	LTDescr_easeInSine_m882A92BAC86E20686430D3770867E0B88BD8C2E0,
	LTDescr_easeOutSine_m3C01F288C50CB37FBA90308D63554C3A7783E1FB,
	LTDescr_easeInOutSine_m76B06B8A875131BAB7D62957A201B5B0B0587112,
	LTDescr_easeInExpo_mB5CC53F9BAAF2965E1821C435F253CD4A557430C,
	LTDescr_easeOutExpo_m14C739205653FEDD99DEC5BED4128CFA16DD56E7,
	LTDescr_easeInOutExpo_mC49A98ED2F7A9AAAFAA440D49D9B053ED07943F1,
	LTDescr_easeInCirc_mA145A08F12DF33F8C2B47D587CB7187F545E5450,
	LTDescr_easeOutCirc_m33DF496165252D0DF90C23DDBC115A9F4652925A,
	LTDescr_easeInOutCirc_mC78C97B3570955DD6905542172ADA750C8AB6595,
	LTDescr_easeInBounce_m2AE600AA25490CE419B699F36BDB0C42BE631905,
	LTDescr_easeOutBounce_m3DF1745F1CB4C447195CFB9BB6B89FF343F0CD15,
	LTDescr_easeInOutBounce_mA95D061538FACCE8B9580B132A67782F49367927,
	LTDescr_easeInBack_m108ABEB0A39FF07E3AEC96D6B48B49811D9C7B67,
	LTDescr_easeOutBack_m9AD5A6FCDB0ED16836B0B3F57218C26E0AA35540,
	LTDescr_easeInOutBack_m4704847A8B6231D28D509347F4C204A5BABCD0F1,
	LTDescr_easeInElastic_mDBFEBBF8886813E812F4C1E6951CD6ADB1F0637E,
	LTDescr_easeOutElastic_mFC227E235F6FF91CC1F1C0CB0FEF5DF699E3B9C6,
	LTDescr_easeInOutElastic_mD2B6C86443DD08280120CD1FCE24CA8A4653D3AE,
	LTDescr_setOvershoot_m525737132ABCF1F06AE299DAC8341821CBB54F85,
	LTDescr_setPeriod_m5DAEA4417D899D633A921AE75F46C08D4E97D6D1,
	LTDescr_setScale_m0D8B00C154BD5E1F9B6D5B3751E268F200BF1E1E,
	LTDescr_setEase_mA13966EB89C908BA73460AD6C2980665FF95FDEB,
	LTDescr_setTo_m433F36B84399D346E2A40E690AA2470F39198C74,
	LTDescr_setTo_mE356E82135AC20DFAE86DED349E09552BF1CDC3D,
	LTDescr_setFrom_m0DE294DF15BCF3D81F0716A0BEA8C5D7267AA398,
	LTDescr_setFrom_m97150B1C1A1FB7B52FDD4F536CED64487B766FE9,
	LTDescr_setDiff_m66354480512FEE628959E9D1A07B680E3D7A3168,
	LTDescr_setHasInitialized_mF24ED2AB3F981B9CF3102C9E85D94547B461A066,
	LTDescr_setId_m71293A9DB7751FDD4F4149E4A5D0ABF3E1FAE22A,
	LTDescr_setPassed_m2E6EEE58EBE05E1E7A49A100AC6FC28094F2233A,
	LTDescr_setTime_mFA06A0D5CC2F72B8D647693B65F91BE6A9F7CAC9,
	LTDescr_setSpeed_mCFABDDF7947D3A8987BB3A73B3F92A126EB0EC21,
	LTDescr_setRepeat_m6F11E6A632B830938240EEE78D85570289050025,
	LTDescr_setLoopType_mA482E7E3DCF74FB08432C8A5E3D52FB52453DA9B,
	LTDescr_setUseEstimatedTime_mA51B6D8A0C1425D4D05C4E4CE7CF27759B70E753,
	LTDescr_setIgnoreTimeScale_mB7978E3F0EB37FB5E2B49E2618F1917EB576BA28,
	LTDescr_setUseFrames_mCF0E71BA4203563896DCDB058C731D216AF04F9E,
	LTDescr_setUseManualTime_mAE5B2628CA1FEE9E546BBF0E8D69B88598071BD3,
	LTDescr_setLoopCount_m0F81199444BDBE9D6FEF24CB5874F33C5AA8A3E5,
	LTDescr_setLoopOnce_m5B7B9509895ECDBDB6447E5C5429887E46CD146D,
	LTDescr_setLoopClamp_m265DE6025C2B4B2A2E9405CBD795CAB41640EE99,
	LTDescr_setLoopClamp_m170890F9038A9350A78DE676B6C210ED8D6C4552,
	LTDescr_setLoopPingPong_mA960C0FC617354580B8AD52D96E7630F693B91E5,
	LTDescr_setLoopPingPong_m500A08D4CC2FCACBF82463C72196849CC180DDDB,
	LTDescr_setOnComplete_m8CCAE85BD9176574E1688DF1817703FE826ADEA7,
	LTDescr_setOnComplete_m913F7B4D1C1478C120B985F6A4F628C13B514ECE,
	LTDescr_setOnComplete_m2D04A5093C8EC0942F23FDA55B3958DA9FFA4A27,
	LTDescr_setOnCompleteParam_mF03EC9B6BCCE1A13DF1435286E6B84A3CD24F2A2,
	LTDescr_setOnUpdate_mD514424805DE6AA444AAFFB2A78849DC2ED24F83,
	LTDescr_setOnUpdateRatio_m9C63BD592F642592526BCF414DF9CA394C7D8D77,
	LTDescr_setOnUpdateObject_mC12BB1EB2ED48C4BC3762BB5D6346B7D4317FDD4,
	LTDescr_setOnUpdateVector2_m5032D644DDD7E79878C37EE96433C4A7F0993F46,
	LTDescr_setOnUpdateVector3_mFDDE049C7826037515B167E499C57C6E54320944,
	LTDescr_setOnUpdateColor_m866743E527099E21D0C5DBF5784BE36533C87D90,
	LTDescr_setOnUpdateColor_m38AA50CE34255E6E4693B8053BF96DF7159AC593,
	LTDescr_setOnUpdate_m26FD3B633FD2FF9942B260148B862AB1C04286BF,
	LTDescr_setOnUpdate_m1BD910E3D340D0AF60000EAF245DACF1AAF26BE0,
	LTDescr_setOnUpdate_m4B784572E92AC1F3CA32AB49F2B8C2097D38B911,
	LTDescr_setOnUpdate_mFB6DF3C34A17C6FAA89280381A932046675CAC97,
	LTDescr_setOnUpdate_mE4F309BB9AE4DD798DDDB74C46A62346B8D11F41,
	LTDescr_setOnUpdate_mF5476AC35CEA5E4A91B716221D72EE04F4F5ECD1,
	LTDescr_setOnUpdateParam_mAADE496BF612EC4AEA8BB56EC878EB3769C6EEC4,
	LTDescr_setOrientToPath_mFD37EA5A564665BF6BD9AC5C2D8A3405ADAC784D,
	LTDescr_setOrientToPath2d_m908CDD2CBF70CCF0D0AA49FD6848A5C7D77DB7AF,
	LTDescr_setRect_mB36958D5E6ABEA6C05543F3C6752567BA3603B32,
	LTDescr_setRect_mA2191EFB70E1C5308150D780D7450D85C7CE15A3,
	LTDescr_setPath_m889A9ADA196043CB42E95A9A936F548EAE9430E7,
	LTDescr_setPoint_m4473549864A9D2376DCC8D97395918A2B69BEC4C,
	LTDescr_setDestroyOnComplete_mFBD0151333DF8D264FC48CF071254C32A3BDAE2C,
	LTDescr_setAudio_mC30B114290D0874D38424A5A1DA0BDB411EC9214,
	LTDescr_setOnCompleteOnRepeat_mDCF46E8952AC831263CCC7850D4A0498914A090D,
	LTDescr_setOnCompleteOnStart_m111620D91E0BE6A1C1009C57884083EF75B9CE65,
	LTDescr_setRect_m428F8D578582E8C44D09350725F8B4718D04206B,
	LTDescr_setSprites_m69FF53F8CFDFBC25B5940404DD6E75F2626DB349,
	LTDescr_setFrameRate_mCF4AF5480041DFFC23EC4D3C7329AF8C317A64C0,
	LTDescr_setOnStart_m2E090D8059E042E0834ED71BEFA3556EE4CD6B42,
	LTDescr_setDirection_m2D6D65172541E380FAB24CEB37FF8DCABFF7A4AA,
	LTDescr_setRecursive_m3A95FC34AE2FE034F0072826A89A6C23E6DC2322,
	LTDescr_U3CsetMoveXU3Eb__70_0_m85C392B96D7E1B178B73802FB0D7C4B439ABA9E6,
	LTDescr_U3CsetMoveXU3Eb__70_1_m972223FF7D3A9C131D84F9E5AC4B63CBA2F570B0,
	LTDescr_U3CsetMoveYU3Eb__71_0_m17335CB64369BAA75406D8E4272CF3BBB224D5D7,
	LTDescr_U3CsetMoveYU3Eb__71_1_m4C43AAF6D5B100847A8B3800367145225981F5C1,
	LTDescr_U3CsetMoveZU3Eb__72_0_m23D516C7A444B95FC5B0008F99733F63BC9D9B17,
	LTDescr_U3CsetMoveZU3Eb__72_1_m3C02F77150F08A01F24FBFEBAE443F8C64BD0327,
	LTDescr_U3CsetMoveLocalXU3Eb__73_0_mA38CD11B83777D4C8CFEF57539F16437861DE022,
	LTDescr_U3CsetMoveLocalXU3Eb__73_1_m14B32D48CE791E7CD1BF892EDB9B351BEE6AFB76,
	LTDescr_U3CsetMoveLocalYU3Eb__74_0_m82FC4978CE3DEFA7F0B403EA8E9A2D7A5F35F365,
	LTDescr_U3CsetMoveLocalYU3Eb__74_1_m693EBBBC819D71F5DC98BD390143D077B2DA3BAD,
	LTDescr_U3CsetMoveLocalZU3Eb__75_0_m5370A512055F9E14A4CE8A2D8143C6EA77550043,
	LTDescr_U3CsetMoveLocalZU3Eb__75_1_m8057F793A4A29FC64C63A5A3D5FC4783EDDA7D34,
	LTDescr_U3CsetMoveCurvedU3Eb__77_0_m90B4D2CA5DE78923748639A144A0F9BC949305E7,
	LTDescr_U3CsetMoveCurvedLocalU3Eb__78_0_m90A308A70E3A100F47AD90544DDA979ED75A5560,
	LTDescr_U3CsetMoveSplineU3Eb__79_0_m8B9A7880D890F5C39AA2071877727F57145D442A,
	LTDescr_U3CsetMoveSplineLocalU3Eb__80_0_m2FC95069246D8E725D0C63C744DF2479DA0BB82B,
	LTDescr_U3CsetScaleXU3Eb__81_0_m043E36F6F194FCB4507FE0ED0B8EE88E46A06253,
	LTDescr_U3CsetScaleXU3Eb__81_1_m03D45F62F977B9C1904A77191CAC9EF71C620AC9,
	LTDescr_U3CsetScaleYU3Eb__82_0_m9A55E680C128B917D929321FEBA977E2EE25AF7C,
	LTDescr_U3CsetScaleYU3Eb__82_1_m16C789DF8D3793E2723781CBA4A52E02A3F818D6,
	LTDescr_U3CsetScaleZU3Eb__83_0_mAD2EF57DC478929F5740862578A9059C640CDEA5,
	LTDescr_U3CsetScaleZU3Eb__83_1_mFC67C018AD21FAE36DE72A2B809675773BE55390,
	LTDescr_U3CsetRotateXU3Eb__84_0_m2A72481DC6A981F272B63370F720013FD1AEA4D7,
	LTDescr_U3CsetRotateXU3Eb__84_1_mDD7D0C94A5C4DC51FE97F8CC2AD0E19898BB72A6,
	LTDescr_U3CsetRotateYU3Eb__85_0_m80D532A7476E5C2FE77BD9388ED98D18651FD7C3,
	LTDescr_U3CsetRotateYU3Eb__85_1_m16AE0DD429ECDACEA0F05E0C4C719E78620929E0,
	LTDescr_U3CsetRotateZU3Eb__86_0_mC5D90C9A709FAA3C801872D3BCD19E58F6D77699,
	LTDescr_U3CsetRotateZU3Eb__86_1_m08A2A6B1F54D29139A76BB166A2C7EBB52B5CEAA,
	LTDescr_U3CsetRotateAroundU3Eb__87_0_m3C73F52643C6F22139A755A4D3DEC628D2F9EE30,
	LTDescr_U3CsetRotateAroundU3Eb__87_1_m89879D2C93C6860C239434F38F9BC6FC6726E9C8,
	LTDescr_U3CsetRotateAroundLocalU3Eb__88_0_m21352E2B36657F92D8E9E0F95DA74649F656EF76,
	LTDescr_U3CsetRotateAroundLocalU3Eb__88_1_mB058FB46E81DDB20592AA23C6EA0B78B4B1B2DB0,
	LTDescr_U3CsetAlphaU3Eb__89_0_m1AFAB1D9A1AA7560DA67FBB7D35EA17B44751500,
	LTDescr_U3CsetAlphaU3Eb__89_2_m4376BFAB661538E87C47CB0AF7CE333A20AB4F11,
	LTDescr_U3CsetAlphaU3Eb__89_1_mE03506955EE1A8F1C0FAF37B3BBFAF88CCCECC1B,
	LTDescr_U3CsetTextAlphaU3Eb__90_0_m309DB4C30BCF61C26C69A42722CBADD2E7921CA0,
	LTDescr_U3CsetTextAlphaU3Eb__90_1_m1681C4B1A2C76AE1340B4A1C8499AB98AE46E909,
	LTDescr_U3CsetAlphaVertexU3Eb__91_0_m91E4C42B4E39A4A9E40282D677F53F7276F7D47B,
	LTDescr_U3CsetAlphaVertexU3Eb__91_1_m07B356D53DBA361CE94D0D50617F8D01A8ED12A8,
	LTDescr_U3CsetColorU3Eb__92_0_m13B9F7EE151ACB78A4A0B052047E65801D67DB2A,
	LTDescr_U3CsetColorU3Eb__92_1_m2A67B21B1EB3E3E2B36B641BC62F6B46B07BB062,
	LTDescr_U3CsetCallbackColorU3Eb__93_0_m8E71B55AD8C5B0E24E5691710725D3C4B69F7106,
	LTDescr_U3CsetCallbackColorU3Eb__93_1_m3C00ABAE6C15F8059D555365356C5CBEBFD829F1,
	LTDescr_U3CsetTextColorU3Eb__94_0_m963E0A1CECE51B444757CD9808374E2801D84980,
	LTDescr_U3CsetTextColorU3Eb__94_1_mE779CCC9D0DC6595CEB2283118B667EF12CB949D,
	LTDescr_U3CsetCanvasAlphaU3Eb__95_0_mF27594F3B7BA34A42F6D7B24DC2F33EAD67CB976,
	LTDescr_U3CsetCanvasAlphaU3Eb__95_1_m5889FAA1B69DBDFAC9D33EF49E49B0E62F689855,
	LTDescr_U3CsetCanvasGroupAlphaU3Eb__96_0_m87C46256B9E6190F7E4BC525C04B14E2979CF160,
	LTDescr_U3CsetCanvasGroupAlphaU3Eb__96_1_mFB41FC0F66EE73C30F8EA4927B10F4A5CCD86FB9,
	LTDescr_U3CsetCanvasColorU3Eb__97_0_m4507F381646E5A941FB2544951C8E826AEA4F120,
	LTDescr_U3CsetCanvasColorU3Eb__97_1_m3CC39DAE832A8AABF0D26A4239CF77D15161B165,
	LTDescr_U3CsetCanvasMoveXU3Eb__98_0_mA74762AB885AD3F0003EA4B6C6AE43F0F0124CCA,
	LTDescr_U3CsetCanvasMoveXU3Eb__98_1_m185BD3882C677C38269B56933DDA8514D5CC60EB,
	LTDescr_U3CsetCanvasMoveYU3Eb__99_0_mCCC0ABF4892F03FE11A3B3A14040D623E64C50C4,
	LTDescr_U3CsetCanvasMoveYU3Eb__99_1_mA24E002DA1057CCDA5A33AF69EB4227DC5800A20,
	LTDescr_U3CsetCanvasMoveZU3Eb__100_0_mC6D2803E76FAFDA1CF205C0B1D497AFE685F1334,
	LTDescr_U3CsetCanvasMoveZU3Eb__100_1_m3CADCFA948FB541AA770AA79AF1CCAB9B7F265BD,
	LTDescr_U3CsetCanvasRotateAroundU3Eb__102_0_mB8F259A34776B45637CB105B97A1D2641188DEAF,
	LTDescr_U3CsetCanvasRotateAroundLocalU3Eb__103_0_m7506F0CAF5A219B0282BEC06F8BF74D67285E684,
	LTDescr_U3CsetCanvasPlaySpriteU3Eb__104_0_m383DE758F44CD402E33B9A069E3995C6800F8CFB,
	LTDescr_U3CsetCanvasPlaySpriteU3Eb__104_1_m23D3E058DFB47A63703782EC55102E374FE18F83,
	LTDescr_U3CsetCanvasMoveU3Eb__105_0_mEE7B7CAD9EEFF0B864544EFC0C15D85D1B9EFEF1,
	LTDescr_U3CsetCanvasMoveU3Eb__105_1_mC3174EB13AF8FED68DBF81D48A97142863A85C96,
	LTDescr_U3CsetCanvasScaleU3Eb__106_0_mA5DC0EE7A92E9F28D0A76CCC5693B3092A059CC4,
	LTDescr_U3CsetCanvasScaleU3Eb__106_1_m8E5B88D595B2E4963842E1DFCBBB6D48133B9BAF,
	LTDescr_U3CsetCanvasSizeDeltaU3Eb__107_0_mB6798ED46BD45A579D1399667998DD416D1140B8,
	LTDescr_U3CsetCanvasSizeDeltaU3Eb__107_1_mDE41C32201F0EAA33B232F059E8BAEB2F2E641F1,
	LTDescr_U3CsetMoveU3Eb__111_0_m354F8AC13CED797EFEA001B7E872B08369638340,
	LTDescr_U3CsetMoveU3Eb__111_1_m12658E361011304F02ED2D6CDC219B54A003E277,
	LTDescr_U3CsetMoveLocalU3Eb__112_0_m7D1ABFFF1EEEEE02AEFAA918C17A98E98B00D710,
	LTDescr_U3CsetMoveLocalU3Eb__112_1_m28C40D6427D961B7F00DF41E2FD6A654914EBE7B,
	LTDescr_U3CsetMoveToTransformU3Eb__113_0_m0F83E2B55A56B95C279D0CC6343BA52942480243,
	LTDescr_U3CsetMoveToTransformU3Eb__113_1_m7262949DEFBF1639CD1D1242258BF4EC3A3A7A9E,
	LTDescr_U3CsetRotateU3Eb__114_0_mC0E62DAFDE435DD80B37A2ACD28E47FDF4B66970,
	LTDescr_U3CsetRotateU3Eb__114_1_m35177AA532C9E2DD6733C88CE7AA7718A8004A8D,
	LTDescr_U3CsetRotateLocalU3Eb__115_0_m2D6801CBC70BB13E4008CCAB57C51E9DFEE57A95,
	LTDescr_U3CsetRotateLocalU3Eb__115_1_mEB674A4DB216C49D2617A333C8AF906316829AC6,
	LTDescr_U3CsetScaleU3Eb__116_0_mC99B91FE5F4C96523771CE2CB6BB7C29FAD5BF21,
	LTDescr_U3CsetScaleU3Eb__116_1_m30BD9BE93B48898740FFA48AD38CBAB65D5F4DC1,
	LTDescr_U3CsetGUIMoveU3Eb__117_0_mB6C97713486DC8EDB18DC0796D33AB993706BF2D,
	LTDescr_U3CsetGUIMoveU3Eb__117_1_m691614FA188E66D6DC7A156B227707CF9DA7A43D,
	LTDescr_U3CsetGUIMoveMarginU3Eb__118_0_m346800AFC0BC448295FF2A2F552C1F21806743C0,
	LTDescr_U3CsetGUIMoveMarginU3Eb__118_1_m00B0D135E5CB1E605E840460A3F0AA6996F33C78,
	LTDescr_U3CsetGUIScaleU3Eb__119_0_m69189FB900EF9EC1720F7A0D77860E4B35DAD939,
	LTDescr_U3CsetGUIScaleU3Eb__119_1_mBAFE8179505F274590069960B98D974AFE988C20,
	LTDescr_U3CsetGUIAlphaU3Eb__120_0_m482516D380329AB1053235283AE0648B398E4676,
	LTDescr_U3CsetGUIAlphaU3Eb__120_1_mE11F1C9B75B5F44200BA7B818A4A3F17B3DAF9C3,
	LTDescr_U3CsetGUIRotateU3Eb__121_0_m426E1D47727A5690C69961121B4961F6E0C7354A,
	LTDescr_U3CsetGUIRotateU3Eb__121_1_mF8357DDCFCE8ECB9B3D5610765B16AF0611666F5,
	LTDescr_U3CsetDelayedSoundU3Eb__122_0_m802E219D03874FB0147C4E5D28AB644519E6727D,
	LTDescrOptional_get_toTrans_m719D187173ACED93F6F03273F38B2499F96AAC77,
	LTDescrOptional_set_toTrans_m7E481DD43D79347C73999A8430769C0CE9434000,
	LTDescrOptional_get_point_mE9A79C3F3C2B2FCCFD77E63EB0E1F11138E0FB58,
	LTDescrOptional_set_point_m87344CAF5C411212DC7E14B8258AF7106008EF41,
	LTDescrOptional_get_axis_mA44ADE549E460373050A42CE075327D57FCB2A6A,
	LTDescrOptional_set_axis_mBBD7056ADF137DE153FF5ACC7E4046AF54BFD876,
	LTDescrOptional_get_lastVal_mE14C4A1953C7028559AF2C4C3CE95B251EDE148B,
	LTDescrOptional_set_lastVal_mFBBB45BCE3AC57DF28B86DFC163F8F9EA025868D,
	LTDescrOptional_get_origRotation_mDE9B177F7E9F3646B00354F66ACB1ABDC4281C01,
	LTDescrOptional_set_origRotation_m7D8F2827074243FDE8E46EA78473CEF60AA9A09F,
	LTDescrOptional_get_path_mA1618E15721930967AD76373DC579895549967D6,
	LTDescrOptional_set_path_m84B919D4F4ACA4F5A9851EA4993FF273F5A78014,
	LTDescrOptional_get_spline_m93E9C9EC86E5B9D0865376D7805560468E60A409,
	LTDescrOptional_set_spline_m969135BC7A93AE02A661F823996A23DEDE0E588E,
	LTDescrOptional_get_ltRect_mC25A94E7A1F24D5B961362A1F58EB9C68423C73C,
	LTDescrOptional_set_ltRect_mC0E01A1BC6C8936B151A0AD9ECAF42C03CB31E6B,
	LTDescrOptional_get_onUpdateFloat_m351E8A10B1A6699D21501BC01CADD4313B91E772,
	LTDescrOptional_set_onUpdateFloat_mB78B0396D1060CA1608EA891202AE34E495D0343,
	LTDescrOptional_get_onUpdateFloatRatio_mBB863BF8D49E74EC7B479C112ADFA1366FFD9B32,
	LTDescrOptional_set_onUpdateFloatRatio_mD198A9B69A19A9D88F55975EA68C7B917C79618F,
	LTDescrOptional_get_onUpdateFloatObject_m4A6112959483417980F736BAE24AAA719DB2C724,
	LTDescrOptional_set_onUpdateFloatObject_m72B8D5B86EFF9B99A11DB6F0C34379631E16C83D,
	LTDescrOptional_get_onUpdateVector2_mAACB3752372B7838ACF31AAF4D66A73877E9E9D7,
	LTDescrOptional_set_onUpdateVector2_mE699D0E783557FF6695C922DFAEB3716042F6637,
	LTDescrOptional_get_onUpdateVector3_mC0175F8101E456C43E292F646F99FE312E9C687F,
	LTDescrOptional_set_onUpdateVector3_m9FA6249737B9F1BE2EA5DCA335AB996E50698504,
	LTDescrOptional_get_onUpdateVector3Object_mE6B6670B2913F713B096E828036EB6CD4DA60CE0,
	LTDescrOptional_set_onUpdateVector3Object_m3F8F905404058D4985E77545AB9A40F2FA25B611,
	LTDescrOptional_get_onUpdateColor_mB519CEA2D59E7E89220416D6339B2A38A7638631,
	LTDescrOptional_set_onUpdateColor_m5DC714D8E11CA5FF02B5CC8CB06889642B85C0DF,
	LTDescrOptional_get_onUpdateColorObject_m9EF2D50A913D43C253D70FE126B78C1F145B7B4D,
	LTDescrOptional_set_onUpdateColorObject_mCCC40115BBD9D83074948446A384195419684733,
	LTDescrOptional_get_onComplete_mCE1EBB1934BEE25B8BE80AB1A187D7B8901E915D,
	LTDescrOptional_set_onComplete_m59EE673BD2A62B75E152344EE4EC04A8A330AEE9,
	LTDescrOptional_get_onCompleteObject_m1BC88DEE83772EAF55BD7776A146B3CDE5B4B4A3,
	LTDescrOptional_set_onCompleteObject_m7AF36A20467C6F0EC7A15E217CA658BC5931E2E5,
	LTDescrOptional_get_onCompleteParam_mE66FC1BACD1FA85AAFC8F95B33FCECAD44498177,
	LTDescrOptional_set_onCompleteParam_mEAE8B0B7EEC7D592089145C89EF5529F29F76FF4,
	LTDescrOptional_get_onUpdateParam_m9314432EF4319CC8BF91AB498DFD28B6584F9CD0,
	LTDescrOptional_set_onUpdateParam_m6DF63DF749384C397A6551409541DAAA1149F4CE,
	LTDescrOptional_get_onStart_m71FE346812408A252C0832481C537B3BFE143032,
	LTDescrOptional_set_onStart_mF2209FE068D659F0729D1DBEC443C9EE465792AA,
	LTDescrOptional_reset_m9843AB37FCFDE642330F1B47C3021106ED8DE1C1,
	LTDescrOptional_callOnUpdate_m46C77125973B23B14522452083EC375D4049DE3C,
	LTDescrOptional__ctor_mA02370B0829C1DAD68A23CA987ED68BDA298CA0C,
	LTSeq_get_id_m140EA14F1A75BACAC2C5DF3B18DF92D8FDE28BAB,
	LTSeq_reset_mE8690AE26C8E0B5A06EC7EBCB24E2BC9B96C8575,
	LTSeq_init_m93C5A0FF33AAB790CA3056ED86ECCAC59DDC4DE3,
	LTSeq_addOn_m2A1CE56E1C5347864944F315D503339A6B10FFC9,
	LTSeq_addPreviousDelays_mDC7303F45F3BAAB22211925F4D39A67057B3FDBD,
	LTSeq_append_mA2177BFD342C4C862F979E515730BE8D6D125094,
	LTSeq_append_m573B4DEBE76713FAE8FC6B28460A14F915997BEE,
	LTSeq_append_m7DC432502137830AC5BE66B2EB72D96B2B61CEBD,
	LTSeq_append_m6D13368207F65B56954A1E43530799A5D48D996A,
	LTSeq_append_m3F851840D6F75DAEFC24B1C704F247AD23460887,
	LTSeq_append_mF8C90D98E084F9E92C5AE6A006DE8B51CCF7A738,
	LTSeq_insert_mDC2A02C163B7A3E2C7915EF94C5A151614796489,
	LTSeq_setScale_mD0B3126147CE96803D2DA368E5D37B212CA43B9D,
	LTSeq_setScaleRecursive_mB17F9AC4644C525CC4A98D42E3FDDD9A67908FF7,
	LTSeq_reverse_mAEAD5EC07B481C926FB441BF76A44351CC47A1DE,
	LTSeq__ctor_m49349974D5B4AE164813F87E303ECAE74069EE1C,
	LeanAudioStream__ctor_mDF57FD09E2DD751476D57DEABB13A1D09B6EE7E7,
	LeanAudioStream_OnAudioRead_mB21A90E7586869074CE94B78314E2DA74B58A37B,
	LeanAudioStream_OnAudioSetPosition_m632422DDFBEF2A9A75B1A59345D9CEE507B2D900,
	LeanAudio_options_mF00747206F18810EB9CC0E9B768F9F2B6DFFD49B,
	LeanAudio_createAudioStream_m503D5BDD4537E111B9A985A14C63B45E024BD9B9,
	LeanAudio_createAudio_m8AF5FEC4BA10749A6A54AAAC10F99F91D1F859B1,
	LeanAudio_createAudioWave_mEB124CD2B7592EC9B4D263DD33D38754D08C5623,
	LeanAudio_createAudioFromWave_mEF3E94173FD41F29D4E1F17EEFB79410B462A7AB,
	LeanAudio_OnAudioSetPosition_m2D9BEAC1A8233E68114DDF122DEC0B60EBA6433F,
	LeanAudio_generateAudioFromCurve_m15F8DAC6E15F0679018162991023320C21AE3C95,
	LeanAudio_play_mF85E29DC3CD2CCE6F8B9E3F2C68E544250E694EA,
	LeanAudio_play_mD774FC88168B4ED2F7949A34A45338E41E3FEB20,
	LeanAudio_play_m9147E4BCFD423C76CBB32E74155C4FB10C49E780,
	LeanAudio_play_mF1F5C2D2304E6F15F1C7201DC15BA9451FE25551,
	LeanAudio_playClipAt_mA785B6A0B9BFEB784B057F1792FA6B123AD48470,
	LeanAudio_printOutAudioClip_m1BBEEF74E06E87EEB6CB40428B40F3ACF149B2E0,
	LeanAudio__ctor_m5A6A66B881DF5CAB4B8075FF43EC94FFB09850B9,
	LeanAudio__cctor_mFCF0B22A8ACB7C105BED2A99CF3CFDA5249F8AAF,
	LeanAudioOptions__ctor_mEAA77FFB2BAFDC3CDD4F308A520A52460799EC90,
	LeanAudioOptions_setFrequency_mE2A475F0F7319F9684E097BCC7C44701EC3D8909,
	LeanAudioOptions_setVibrato_mA266E90C3FE02CC21E4CF90ED88ED2C284E574E7,
	LeanAudioOptions_setWaveSine_mEFC93B54DE788249388CF3B55038750339CDC7D2,
	LeanAudioOptions_setWaveSquare_mC82AD1D5AF7278330E0808DA9E3956A2C85F3357,
	LeanAudioOptions_setWaveSawtooth_m33F49A4AE4BB2F139D935F2D67768B8B938914C7,
	LeanAudioOptions_setWaveNoise_m3A0FC31501B4DF8FFF894E7EF00180AAFED760CE,
	LeanAudioOptions_setWaveStyle_m6826A4F3E7CC38810BDA8543CFB57C4914B66034,
	LeanAudioOptions_setWaveNoiseScale_m17A4FAEA45D3746211755E42072D363A0B423285,
	LeanAudioOptions_setWaveNoiseInfluence_m5E1DCC6E69DD4F8D6E6DC5E6B7F42C85F3D8DB3B,
	LeanTester_Start_mAA0B8CCD08535865AC59436BDEAADA4B4ABF4015,
	LeanTester_timeoutCheck_mA5EF6F05EC2DE5ECBBB0B7DD243120D8CBD75B81,
	LeanTester__ctor_m844173FA687FE335D642403866EA9BE276A49D9D,
	LeanTest_debug_mA720BBA18435CC6357DEBB4BC84EF3548472ABD2,
	LeanTest_expect_m0D0B37EDF16B00E37B2A3FA1BF2D5120E0A39F51,
	LeanTest_padRight_m6B4C7481D1E623931A452A662E23AEDD55034286,
	LeanTest_printOutLength_m07A82FD8C2EB0F3B0A0DFD965A0197F5A53A4F0A,
	LeanTest_formatBC_mFD611FB47EF427FC380DC1941CFEEE9875C62934,
	LeanTest_formatB_mF67C5B1EA0357634346BEFDBCCE47EF1C11921EA,
	LeanTest_formatC_mA50AA389A5A1963A9D97F69F4ACD51EA36451B11,
	LeanTest_overview_mB5C2BB989BE6A6675763CF8694A84CA9A8CF79B1,
	LeanTest__ctor_mD8CF7A576BC7B11ECCE6BE389F5EE15C5D7DE0AE,
	LeanTest__cctor_m54A725A957249EE68C559F2329B8AF06D1E308F4,
	LeanTween_init_m3A14F34E8E6C0F4E7E8F04680036005A558AA597,
	LeanTween_get_maxSearch_mDDF2CCBB34877BFA91E9D41AC1A37EEF9A17D3B7,
	LeanTween_get_maxSimulataneousTweens_m2E4F01D132BF6E910B8C9382DB431CAC15166021,
	LeanTween_get_tweensRunning_m79147802B4C22258FE5D0E2C9163864922DB9E46,
	LeanTween_init_m838A501BBC42BF87BC5D3CDB639292C03D091490,
	LeanTween_init_mF52C50B297D7308D4B071CC158BFFAA2CE159433,
	LeanTween_reset_mEFF3007C07A7A43DEC29917CD75A1FF371CD2B57,
	LeanTween_Update_m9A2285BE57F974528E92EF460F7C67098D7F4083,
	LeanTween_onLevelWasLoaded54_m403AA28603A3DC3AF0893A21D02FE44EF26CBA51,
	LeanTween_internalOnLevelWasLoaded_mBFA0941C93E05CDA4792B59148236D068CB61763,
	LeanTween_update_m9B4C7EA55BB5D2D243784C9EB801199A01AD6BA4,
	LeanTween_removeTween_mE428B0E1AA50508AA75616B9464559BDF94BBDCE,
	LeanTween_removeTween_m70447ECFDB45871EDCF90970848D71857AF55633,
	LeanTween_add_m0B9277057BE935AF4A8506E8BBE9A9DBE2039951,
	LeanTween_closestRot_m08BEAB0A619A0C293FB45B844090FE035E65EDAE,
	LeanTween_cancelAll_mD9AE22570FCBD2A51B5AC9E6FABCEB51D1BA62A9,
	LeanTween_cancelAll_m825F03BCBB920E99E359C16C4E36FB35ABF39D6C,
	LeanTween_cancel_mEBA9A5015B481CAA3037FB106E24229FA08FE48F,
	LeanTween_cancel_m40D735EDE70D0F8989F3320AF30B01756EA95508,
	LeanTween_cancel_m8FF6F04D27BAB5CE2384E5FF5F29150DD357A0E3,
	LeanTween_cancel_m67D040E83CE6EDFA61AB7FC5E3709F3F4555DF1F,
	LeanTween_cancel_m699FDAF503852033D60D288A8F7D5AE37F2E89A1,
	LeanTween_cancel_mE6AD77CD68160DBCDE6E7AD3F47455CA93AF0485,
	LeanTween_cancel_mAC6C9FA841627B25FA7A5667CEEBD8112C43D9D7,
	LeanTween_descr_mAA96FC2477393396F9EFF9BCB0F2457F8E1A5575,
	LeanTween_description_m779BBCE6BFAAD443D61BF54728D5EAA2AC1F91F6,
	LeanTween_descriptions_m8A1EDD62B99DB1D195720BE8AFAD7D9C3EE06B03,
	LeanTween_pause_m3E16CBA0457ACFA6DB6AF31420E3E076EB4C82ED,
	LeanTween_pause_m6877200DE8AA083953E2B74676D0CF1D3FF54A17,
	LeanTween_pause_m8B121A136671F8C3DF1625213AF2E61F098F1BE3,
	LeanTween_pauseAll_m1FF8BAC2FC5A172E6FDB1701BB8D32E33F566CA1,
	LeanTween_resumeAll_mD0B25776C71F8AD78CC1728E4E2965423E0530FB,
	LeanTween_resume_m0E3F52C06A4DBD4852AF4394CA06C78DD2C82D64,
	LeanTween_resume_m0E3FE2BA91498A9F7F2C0B7049D013DF63844C89,
	LeanTween_resume_m5E5125FA9897DD7077260EA02E9A3CDA05E72AD5,
	LeanTween_isTweening_m224C81EA776251E546E17E176D58FB13030C22CD,
	LeanTween_isTweening_m37C639AFC756F49B17EAFFE061FCF745A1CCEE4C,
	LeanTween_isTweening_m87F758F1444484B33391D0A7B80311CADF96DA97,
	LeanTween_isTweening_m0FB1A948793C0D8696BC7EBDF46321F119C43107,
	LeanTween_drawBezierPath_mBC5C62ABB0D5352564C32F5F865E8401E9D60349,
	LeanTween_logError_m6F20E927A2B24271154486205006599F433D5421,
	LeanTween_options_mB17CDBA626969DBC4FDE95FA2228F19439756E9E,
	LeanTween_options_mEF855D11F49DA432E24574EA3BDDA49B65493335,
	LeanTween_get_tweenEmpty_m0B0429ACB0FB10F2460857934B1B3885315E0A86,
	LeanTween_pushNewTween_m2D8100B7B9BA7080D51685021FCCD49DC6CC7D8C,
	LeanTween_play_mF2686814B4F270E9CC7D3870F1321493E2BC73E5,
	LeanTween_alpha_m0B78DABD556A09E26A0F2D83DF60533BC83D9C24,
	LeanTween_sequence_m1C5CE0739250A4BD5D786028C7D210BFA2753A65,
	LeanTween_alpha_mCB5CE4FA4C38721AA4404E7A8AC83BDC1D4CB092,
	LeanTween_textAlpha_m5935920D7EF4D6B99B95F07228222344FF8E9508,
	LeanTween_alphaText_m7EC2C7D78F2CE215EBFE020B723178BC2E5A062B,
	LeanTween_alphaCanvas_m157681249512137B41CD125CADE584834D56D315,
	LeanTween_alphaVertex_mA4F347B1367327EC7D719FB417150BD5C62BAF7C,
	LeanTween_color_mD0A3CBBAE2B1A587E788CF6F1AAEAA7F707DEBEE,
	LeanTween_textColor_m4A329212F28190FE384DF658578C20A00AE335F6,
	LeanTween_colorText_mCF64FD914B2B009D4CE5AF7B5DC877959CCB8BE6,
	LeanTween_delayedCall_mC7A4640FD2B48C590560EB50735D7D47C500F0B3,
	LeanTween_delayedCall_m0793F63D6C1CD895009CE8D336D81D96B9895633,
	LeanTween_delayedCall_mA94EA930FE8E58442F48B63B81DE071769049A65,
	LeanTween_delayedCall_m0A5CF6D12E7558DDCD72AEF6FF9EDF56D3BFFEA6,
	LeanTween_destroyAfter_mE48606CFABF37E965A7536EDCBFD2954C08117AB,
	LeanTween_move_mFEC103C0F170F5A6D9A0ABD5850132997FA0711A,
	LeanTween_move_mB3CB4D07A30B261720A8BBC17D6889583529EEEB,
	LeanTween_move_m98A69BB2C5D052DA5511A3110B2D7AC334D16957,
	LeanTween_move_mF1C537A5B1302574EEC7EF55AFFEBA39A0977986,
	LeanTween_move_m923AC3AA478DBC29EB0EF2ACD2A9528A1F5ADDD2,
	LeanTween_moveSpline_m89E10B8AA1B74FDEECD33D400ECA17398DEA4170,
	LeanTween_moveSpline_mF1B1B616A6F7877B6E4D9CDA3E2F2B94EAFEEDBC,
	LeanTween_moveSplineLocal_m5A87108FAA779C8A37A81C1F4EDD1167A5B4C998,
	LeanTween_move_mDC908E23A843784EB0FF709E0316E2C6EDE5069C,
	LeanTween_moveMargin_m908FD39664DE8397217F1E37A7F0243DDA209C03,
	LeanTween_moveX_m823C48EFE89D05E8A6CC29C0E4CA924A694F7FC8,
	LeanTween_moveY_mDB68508AA65AA60664BD88504C67E1C19280BF8F,
	LeanTween_moveZ_mA88DB12D1B560DEBEF3822E66A7F430CDDAC5ADF,
	LeanTween_moveLocal_m3E132ADE8326ABF739CDB038339FDB97D0303DA0,
	LeanTween_moveLocal_m4327F0E883DE6249410B02ED3C54371CA0441F49,
	LeanTween_moveLocalX_m232E69D8A2E986B208E2526484CE913F394562C3,
	LeanTween_moveLocalY_m81984CF3A6A7916DF3A0B6927CFE4D6EF3412CB9,
	LeanTween_moveLocalZ_m5554E85ABCFA94D7490FBB94C6CBAEB1FE8BFE78,
	LeanTween_moveLocal_m447BA213D7DAF630C34246A2FDE762D381C0717C,
	LeanTween_moveLocal_m7DD323A3A22C0A7A60D7A317070CC065FA1B8592,
	LeanTween_move_m2127590D6E19C76397E626EAE1B6782458680EA7,
	LeanTween_rotate_m8579E373F5CF4C8D7CFBE21F589A01C136A622B9,
	LeanTween_rotate_m59F38DEE77FA560A392486AF379B5336F3E1C43E,
	LeanTween_rotateLocal_mA0372B9346E44B2E0A1D17D2208AEDA68FF89453,
	LeanTween_rotateX_mD4A46C2F227DDD51833EE87737B2D152A748CA36,
	LeanTween_rotateY_m95B50929DB57158B55689A11EC7D2571AB082130,
	LeanTween_rotateZ_mDE662A3F5EB65C2B92C59F1BBB19DCADE59EDCE5,
	LeanTween_rotateAround_m075972BBDD28C5C9CE5F9E96B8A3781171907CE0,
	LeanTween_rotateAroundLocal_m39E570A2902DF8EF81DDA92301068BC3D41C0FC6,
	LeanTween_scale_m739EA30AF4AFA37BC3A004C6AB6D4C86F7D70D46,
	LeanTween_scale_mBC5AD5DAB9B312348CEDC26C70FD3A9260053BFB,
	LeanTween_scaleX_m2A780B8533FBBA2E301770CFE263982CFF037E22,
	LeanTween_scaleY_m24D433E4DEDC75CACAD69DF2FD8E38121B5A94E6,
	LeanTween_scaleZ_m98FD178C8100B06FD8AB5D179ADBFD36763DEF46,
	LeanTween_value_mD0197FA9C5DFAF3B3D051D779A8E34065F2542D5,
	LeanTween_value_m543D884136BEDE2B5BF23A55D9FAD8A0843A335F,
	LeanTween_value_m8F117786FCC178168C85394998199CFAE7DFB4ED,
	LeanTween_value_m68A54C69FA47C71E8521261C618ED157D571137D,
	LeanTween_value_m60DD684C801E4822E2D5620D89F0E8853BFA5923,
	LeanTween_value_m140AEB84C489042A3011D78E12AB63845807CBBE,
	LeanTween_value_mDE8B16907861A420025C6100630CCDBE82305CEE,
	LeanTween_value_m05610B233159B942C81B25E962680B7C438A8E29,
	LeanTween_value_m49C9E0FA5D72E29C8C0D28832A669C55C267726F,
	LeanTween_value_m4F5BAE774B4560F6993681D61B3250C8A7496E74,
	LeanTween_value_m4429FAF1696ACFC07E604159A2FAC9F5980871DB,
	LeanTween_value_mD6D20DA483B48ABD8E9E22BEC30A55AE10AC30E1,
	LeanTween_delayedSound_mBAF8BA749D1D0BEA04684EDE697644551C204DF1,
	LeanTween_delayedSound_mE638A9BC5F7E0861274946CA95966ED8F80E4D0D,
	LeanTween_move_mE2791E0F813767A2F4CC46C57BD8D06BDE763D24,
	LeanTween_moveX_m62C418E8EB73D6BDBE3C8E684D64E3CCB860EC9F,
	LeanTween_moveY_m9A245FE8A6072EA7383DCEE62970211B04AE1427,
	LeanTween_moveZ_mD0886ED74150075AA4231F9AE84A87F9ED53CE7B,
	LeanTween_rotate_mD96AE259C7FB374F9409994108FDC12A113F30C3,
	LeanTween_rotate_mE154DFD915B26150B1D77329AADF8F0260AD0408,
	LeanTween_rotateAround_m5A922CC08D9228288F71F7E05D65F414DF285848,
	LeanTween_rotateAroundLocal_m25AF19B0B02DF4489ED8940E4784D4B473CEB694,
	LeanTween_scale_mA79AFFE211A8C69E7E1F515733EFFAB13C5B9497,
	LeanTween_size_mF755BD8B4C33948A9602064FD07B825ADE9AEDFA,
	LeanTween_alpha_m0E7667CE8AA06EF2FF9BDDD82D1682C0B19DABE4,
	LeanTween_color_m76E6D929746BB8A4993C6035FA752743E120DEA6,
	LeanTween_tweenOnCurve_m776AD911BC063EA4759FA9E681200B39AEA3CDDF,
	LeanTween_tweenOnCurveVector_m8D3F80D7DE085480864A1CF28F46EF1D1B7AC5C9,
	LeanTween_easeOutQuadOpt_m8E383A24ED2C57B96DD8B8B1C0CFA111FCB1E66A,
	LeanTween_easeInQuadOpt_m4DB2CBF07DA62DF06320D2AE4D126A7D34307AB1,
	LeanTween_easeInOutQuadOpt_mFE7A2D8E853E9B3CE34D4EDE9C4EEB2A4795AB3F,
	LeanTween_easeInOutQuadOpt_m401BAA3AF8856E0D688C9FDA0F8BEA5B9D21BC91,
	LeanTween_linear_mBA6922D37F646B5776990E0CB83871AF4276729B,
	LeanTween_clerp_mEA2E00AB23E44AA9A5D4B6B317C1862E13FFE5C4,
	LeanTween_spring_m38AD603E3723B65EB126F7CA2CD94A4F196A9CDF,
	LeanTween_easeInQuad_m67F21D89F55668292BAAE34FFE6C12B58998B280,
	LeanTween_easeOutQuad_mA3C32215EB43C534EF7C5EE5284A831E60BEAE71,
	LeanTween_easeInOutQuad_m14632B3E09C2072566F37B8DFB26E7F510020A6D,
	LeanTween_easeInOutQuadOpt2_m3499560A61B028FDA940456BFAC3FA33BA168589,
	LeanTween_easeInCubic_m1730FCFDCCD6522AA5EF75071FDBEFCA6BC38AA0,
	LeanTween_easeOutCubic_mA7478B119FECD286374C6BA2D7F90AFDDDD63286,
	LeanTween_easeInOutCubic_mCB8CAD056E95EC6DCEC23C2A34C8ED3DCFE78B98,
	LeanTween_easeInQuart_mE08BC989150FFBDCDD918DD3D984C447956E2FD5,
	LeanTween_easeOutQuart_m025D63DFB1B1552FD16F28E8BDF89B06A8FA18E0,
	LeanTween_easeInOutQuart_mBF7B317CBB13C201D209C9B0A40C30EFC533B4CC,
	LeanTween_easeInQuint_m15438DA1E946FECD15032016C913685108C0029D,
	LeanTween_easeOutQuint_mC0CEE37C8AF32D7030823C31BB1B191D39AECA0F,
	LeanTween_easeInOutQuint_mDCC4325CD1564F24DE41D945892879CF51ABD098,
	LeanTween_easeInSine_mDFEF9079CDFF383174459C45749DBD8DDB528B51,
	LeanTween_easeOutSine_mDC74EC7F0DF54586E2CBDD8DD22D78EF43E56A3D,
	LeanTween_easeInOutSine_mCC2C711E07ACA35228B944175B54BDC6A7DC4A62,
	LeanTween_easeInExpo_m220BC432A261CA38493290ED9087A960D03034B3,
	LeanTween_easeOutExpo_mBD7964251D9A744887B37462F942A0698FDE97DA,
	LeanTween_easeInOutExpo_mF89D29E1B383D0093637085A738C8D40A85BB63F,
	LeanTween_easeInCirc_m9F0D3D8619CBB5BD13267AD4AB5CFDCA4E9AA3DB,
	LeanTween_easeOutCirc_m63747063777CC1CA68337F3A485412B6C4174991,
	LeanTween_easeInOutCirc_m563FCB27BEFFB2825792656D2BC9D0C12FE49C1B,
	LeanTween_easeInBounce_m78927E38CE9890042BF57410D62E16E47BF06B1F,
	LeanTween_easeOutBounce_m4D65F9794140223F756CD3FE37F006F3194187B9,
	LeanTween_easeInOutBounce_m8BC95110D4ACB33CC1998C0CB6F0587AC4E928F8,
	LeanTween_easeInBack_m688ED71D95DFBA782F78B75931519C4500646703,
	LeanTween_easeOutBack_m807628E8A23993D9D95FE4E7FB92F267B03584BF,
	LeanTween_easeInOutBack_mA633B3918EEA109AC13372AE59A76CB539B546D8,
	LeanTween_easeInElastic_mB5BEF56CAA1CC94BFBE4A72175FF9D5EC932DEA0,
	LeanTween_easeOutElastic_m5ED1AF8B7625181C7525220EBC3D1EE9878C0DCB,
	LeanTween_easeInOutElastic_mFB4C482176FF749138593B83F9858DDBEE613C42,
	LeanTween_addListener_m699F102351A06463B95E67B14E0498E7BC8EEDC6,
	LeanTween_addListener_mC647F29B4179BCF81E60894F77C4C3EDBE7BC636,
	LeanTween_removeListener_mE71495E35003C6FDF3F3867CDD525F1104FA29F8,
	LeanTween_removeListener_m48C01A50155AD24E4D1B8C607CB40A4B2243189E,
	LeanTween_removeListener_m6AA8FEDC14340D455B55977BEB795036F45DC724,
	LeanTween_dispatchEvent_mA20EC065A68484D845BD5AAF214120E3F9A33AD2,
	LeanTween_dispatchEvent_m5A5DC1DAFEF4D0A1B1B8BFD7ED22137C00C9FE50,
	LeanTween__ctor_m91FB17B3114982A54E0BDAFB575DDEBC16D2A8C9,
	LeanTween__cctor_m10C7F7A5F90E383DCDECBA2B3E04770CF99B511B,
	LTUtility_reverse_m21336CE7601EAC2D252FD8B00B2DCD93CDAE575F,
	LTUtility__ctor_m5A5020E9B63AAABC97BE9058B9D6D90570511804,
	LTBezier__ctor_m917F93EBEEF53FAB301E23523CC6CC7468091BCC,
	LTBezier_map_m8B9A4E27E56006EC65CE568154945119539BEAE7,
	LTBezier_bezierPoint_m6FC5494E00B9D5563BEF7207F8C05C6911799D12,
	LTBezier_point_m2F8178CB6443451464F12CC05080747D1E63265B,
	LTBezierPath__ctor_m1BA2781962EF25988B97D9D998018CC1CD4F4C0D,
	LTBezierPath__ctor_m8D9B32285ADA3C785CF841C3D480C0EA17B6C98D,
	LTBezierPath_setPoints_m02CC21FE86E5CCE0E4BCC0DB0D018ACA9757329A,
	LTBezierPath_get_distance_mFCD927E71FA246B477108A8D773A6CE82F7F9D2E,
	LTBezierPath_point_m41590CE29A37A8DFC0B874C364254F57A46D2F09,
	LTBezierPath_place2d_m0961B85CE36658D0AEB3F06BF4458773FA9DEEBF,
	LTBezierPath_placeLocal2d_m2AA2ABC9150443DE02DC921C84F71407A77E267B,
	LTBezierPath_place_mA3774BBDD387A39BD03C0F52C72B59A7130DBF79,
	LTBezierPath_place_m5E58DFDE9FD3ED69AB3F81CA00D841D52EEB580D,
	LTBezierPath_placeLocal_mDF095DCC3DA2A678411E6762C814C4E43DD29EC4,
	LTBezierPath_placeLocal_m2A89BD719A350ABACA3D881E7A35E23DCF7D94A8,
	LTBezierPath_gizmoDraw_m456CDA5CAEAE2F0CC869A1285E3ECF579BD328AE,
	LTSpline__ctor_m57C75A7B8A4DD275D39935B860C1E181B5CE9B83,
	LTSpline__ctor_m4D4F4871CFD23663418689B95A5FB8BC8C49AC28,
	LTSpline_init_mE4FD1F1E23FA489692A0D9C97716A7E7DA21C742,
	LTSpline_map_m374A1DB30E3C325A376A4FA8B1BEA799C7E93C72,
	LTSpline_interp_m6FCAD1CB86CB45F93419A7FF5C82191DF3C094E4,
	LTSpline_ratioAtPoint_m97359CDB153D0E9EF641DEA126089B19495EDC07,
	LTSpline_point_m7896374FB44B666DA3AA72CEC832D01BDD44AA5B,
	LTSpline_place2d_m410FE485D771784283F6F5F4576B7B1F332CB770,
	LTSpline_placeLocal2d_m33577AAE988A28259886F5492DC86A7849D6690B,
	LTSpline_place_mA6D3930CB0B5968C41C1033F903962C27DE51F2F,
	LTSpline_place_mDB4D0DB4E883DFDF719A5AA6569B35C7A43A66FD,
	LTSpline_placeLocal_m5567A3535873B5A8F2486DD8F6BBA4E8ACC5C121,
	LTSpline_placeLocal_m8DED20C2B16AA8498AA4577A5EA50A40EFAE8B34,
	LTSpline_gizmoDraw_mB244CD15DB748BB8E9BA3352C115EEA8D239B341,
	LTSpline_drawGizmo_m0678C5E327878D4B699C7C09D4978E5CE61AA792,
	LTSpline_drawGizmo_mF2B8532F54C8641D182E90AD79BBE9A79FD8224F,
	LTSpline_drawLine_mE5283611D4173190FB6AD7BE71C75DDB444C7BB8,
	LTSpline_drawLinesGLLines_m07A015A9E0E74A39E24595E58760EA53F4DAC4EB,
	LTSpline_generateVectors_m731F7320C9D1709CBD87C4C4936EC7187EB6904B,
	LTSpline__cctor_m4F7F089258AD535EDE163AEB30B22F5BF1891CD8,
	LTRect__ctor_mCA1C09BE881F539C97297E17938568350DAE6ED9,
	LTRect__ctor_m095A13A871AD1EA6986CDAAAABA9C968CA14844E,
	LTRect__ctor_m195E97F5ED6A3CC825784C21D78CA3BF97BB6E57,
	LTRect__ctor_m749D7BA32AF1BA250E0C21F16B6C94600CD63EFF,
	LTRect__ctor_m73F6C1A371C27FACAA710BB8D2C0FB254B7CA813,
	LTRect_get_hasInitiliazed_m9F06A8057DB0CA4E23C10C71D132FB5692A30A66,
	LTRect_get_id_m769D3243B7A2895AB1D71D4C7A242E848394D42F,
	LTRect_setId_mF3088916CC145F19794DB82B96C297CF6ABF6174,
	LTRect_reset_m19E8588FBA4D5083CF8C36FBFA8E7E131461CCE7,
	LTRect_resetForRotation_m650E57A9196E7F5BE429E92E062C0FD651D1F6E9,
	LTRect_get_x_mC40DC8BA4720E21417D3A7C53D0C239F49566560,
	LTRect_set_x_m771C3069EB5D399D2D04B37E733F8D728B67830C,
	LTRect_get_y_mAFDE9D2D7F9C092B71158501885F02451F6CF70D,
	LTRect_set_y_mF1F12B4ECC6E565A2FE3FDE6E3D7BB75BBEA64E6,
	LTRect_get_width_m03068CB4AFAE07FFEA9A119211DD957C9D262C54,
	LTRect_set_width_mF83A197741856B6718D4ACBC15BEAA4B63BB6628,
	LTRect_get_height_mB37BB9F1BC71FFB3832BBF6A4FDB4A040661CC4F,
	LTRect_set_height_m6E3290369AD12E197D6CD4FDBF586F57DF2B0764,
	LTRect_get_rect_m179868C83A6FCE9A3D55AAA8587C8DA9D55140EE,
	LTRect_set_rect_mF0B36BB4EACABC706AA56D6F8111BBCCFDEFEF98,
	LTRect_setStyle_m48AAA6B56520E43334D0686F33BD1DBA84F65083,
	LTRect_setFontScaleToFit_m06F0A6C039B06293EC372E6E827AF284298B4017,
	LTRect_setColor_m52BD1DF2FD06021D28437530E5F5B533809D1778,
	LTRect_setAlpha_mAD1DF3137FFA8A8C90D7A0E0D3E5F14556FAFB93,
	LTRect_setLabel_m8A92CE82745515509BB490DB462FC24839DF1D8E,
	LTRect_setUseSimpleScale_mF46837DE51C3C1C2683B41B09D73EA5825576893,
	LTRect_setUseSimpleScale_m927734D2B166FF4FAD2C6B7F22588A1922BD8CEC,
	LTRect_setSizeByHeight_mAB77E3AF24A68A8623798E36EA1D3F7C360A48DD,
	LTRect_ToString_m4CBED2414A03DE4BCA7CF7B07393C82FE9282868,
	LTEvent__ctor_m2E02BCB485BA1431D084EE07A9CA62610077BC14,
	LTGUI_init_m0B5EF6B79A1842DA9C5D159A3E5E465D9BB28FFB,
	LTGUI_initRectCheck_m3367481975F938E51C6398EC581DAB5FC44E1B92,
	LTGUI_reset_m20BBE8C12F7FBD549796BDE6913CD5B8D3BC6383,
	LTGUI_update_mA03FFD6F752B1A5200404A9CB9B73BA2D56947D7,
	LTGUI_checkOnScreen_m14046195B38A177908CDCD26A86E958C3CFEF056,
	LTGUI_destroy_m2E32BE2936E5B392A089B897AE62E470436B9F4F,
	LTGUI_destroyAll_mBB9E21626996F00AB7E73992688F8C1E7DEAB613,
	LTGUI_label_m64095CBE3AFAD10188CC58BE9A9423FAB3605AC1,
	LTGUI_label_m8BCF8827B449C381BDAF391C894EE0AA8B1366F7,
	LTGUI_texture_m254ED9B2FC116C879D75744086CEB7F5FA34522B,
	LTGUI_texture_m890C67AFDE6C64F26023F63193EC55829A251BB4,
	LTGUI_element_mC8808C9F9C3BAC63F8FF1C03A03E2493611F2674,
	LTGUI_hasNoOverlap_m4830FB57717717CF0C10C541A695F3B067D3F42A,
	LTGUI_pressedWithinRect_m9F9A0E240544C9BBB9A11EE82BBA0A25B0881B2A,
	LTGUI_checkWithinRect_mB143E5C8869DFF898A184E65776D362FF2395197,
	LTGUI_firstTouch_m0AA3E8EBAA270A401668B25674B66DA99E567DEB,
	LTGUI__ctor_mDBF1E3C5C648439CC5DDE8ED56549D4F28906BD4,
	LTGUI__cctor_mFB30DA4BE86B7C2152E31C811FB1A81137DE9AE6,
	LeanDummy__ctor_mBFC756324C348662E8922EEF9AD0C46BE185CB2F,
	EaseTypeDelegate__ctor_mE676A6C632434B869CD2DB657EE7D6B8776390AA,
	EaseTypeDelegate_Invoke_mF24C392FE2626B09543053FDE917DCA4B6487903,
	EaseTypeDelegate_BeginInvoke_m425CAA3EC4FF94B7E1ECF5D81BB84E52E0EA86E2,
	EaseTypeDelegate_EndInvoke_m806D2CF9D2EC19CDAE363AF0E8937CC0D7709E07,
	ActionMethodDelegate__ctor_m15A60FF6C9652868EA6EF57DD25D7F16F7D3FBB5,
	ActionMethodDelegate_Invoke_m7806FD0721D794AD557F9859638A9242E3C21724,
	ActionMethodDelegate_BeginInvoke_m47193558577E25FEB144AC88B8554A9DC9C2CFA3,
	ActionMethodDelegate_EndInvoke_m86678D6FB2B4A5A5230C085B8EDB70A6AFA7E1CA,
	U3CU3Ec__cctor_m13D7CC7D84883311C3BE86ABE3C554AD1E2C02EC,
	U3CU3Ec__ctor_m33C92385E4A83C661AF4D3253F008607BC2AF1C5,
	U3CU3Ec_U3CsetCallbackU3Eb__109_0_m168E784261080CE918956C3AF5F56102DD4772CC,
	U3CU3Ec_U3CsetValue3U3Eb__110_0_m176A22EF6A79CA8261764760342CD7D6AD89ED6B,
	U3CtimeoutCheckU3Ed__2__ctor_mB019F9EDA6E194AFB39FF6942CA24D39A06C9227,
	U3CtimeoutCheckU3Ed__2_System_IDisposable_Dispose_m689218535F12CC1F504997D0D7F9CF7FABC846C1,
	U3CtimeoutCheckU3Ed__2_MoveNext_m3D653D4CC2A259CE79DC552A5E2CFA197AD388DE,
	U3CtimeoutCheckU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC9DDE351DC515AD2B3C5A865FF801CD0DFFEF422,
	U3CtimeoutCheckU3Ed__2_System_Collections_IEnumerator_Reset_m774CD18D28886DCC54246266FC762CB3F5E80166,
	U3CtimeoutCheckU3Ed__2_System_Collections_IEnumerator_get_Current_mDF742379BA045E868736EDA42B64272D5C6BDE72,
};
static const int32_t s_InvokerIndices[684] = 
{
	1108,
	1109,
	1108,
	1109,
	14,
	26,
	14,
	26,
	14,
	23,
	28,
	10,
	10,
	14,
	26,
	23,
	14,
	14,
	14,
	14,
	14,
	14,
	23,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	23,
	14,
	14,
	14,
	14,
	14,
	14,
	23,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	23,
	23,
	14,
	114,
	23,
	1816,
	1817,
	1818,
	1819,
	1252,
	1820,
	1820,
	1817,
	1817,
	1820,
	1821,
	14,
	14,
	1573,
	1529,
	34,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1108,
	1529,
	1529,
	1529,
	28,
	1573,
	28,
	1573,
	1529,
	1573,
	320,
	160,
	1529,
	1529,
	1529,
	34,
	34,
	320,
	320,
	320,
	320,
	34,
	14,
	14,
	34,
	14,
	34,
	28,
	28,
	113,
	28,
	28,
	28,
	28,
	28,
	28,
	28,
	28,
	28,
	28,
	113,
	113,
	113,
	113,
	28,
	320,
	320,
	28,
	1822,
	28,
	1573,
	320,
	28,
	320,
	320,
	28,
	28,
	1529,
	28,
	1529,
	320,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	26,
	1108,
	1109,
	1108,
	1109,
	679,
	290,
	1258,
	1259,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	1089,
	23,
	10,
	23,
	169,
	14,
	679,
	1529,
	28,
	113,
	113,
	177,
	28,
	28,
	1529,
	1824,
	14,
	23,
	26,
	26,
	32,
	4,
	2,
	2,
	148,
	260,
	133,
	164,
	1825,
	0,
	1826,
	1827,
	1826,
	1828,
	23,
	3,
	23,
	34,
	28,
	14,
	14,
	14,
	14,
	34,
	1529,
	1529,
	23,
	14,
	23,
	1829,
	1830,
	43,
	1335,
	1,
	0,
	1,
	3,
	23,
	3,
	3,
	131,
	131,
	131,
	133,
	135,
	3,
	23,
	1292,
	133,
	3,
	135,
	133,
	1826,
	387,
	3,
	794,
	122,
	563,
	122,
	1831,
	324,
	133,
	1832,
	43,
	43,
	0,
	324,
	133,
	122,
	3,
	3,
	324,
	133,
	122,
	94,
	94,
	46,
	94,
	1833,
	0,
	0,
	4,
	4,
	1834,
	1,
	1835,
	759,
	1835,
	1835,
	1835,
	1835,
	1835,
	1836,
	1836,
	1836,
	1837,
	1837,
	557,
	557,
	1825,
	1827,
	1838,
	1839,
	1839,
	1839,
	1839,
	1839,
	1839,
	1838,
	1838,
	1835,
	1835,
	1835,
	1827,
	1839,
	1835,
	1835,
	1835,
	1839,
	1839,
	1839,
	1827,
	1835,
	1827,
	1835,
	1835,
	1835,
	1840,
	1840,
	1827,
	1838,
	1835,
	1835,
	1835,
	1841,
	1842,
	1843,
	1844,
	1845,
	1846,
	1846,
	1847,
	1847,
	1848,
	1849,
	1846,
	1827,
	1850,
	1827,
	1835,
	1835,
	1835,
	1835,
	1827,
	1840,
	1840,
	1827,
	1838,
	1835,
	1836,
	1851,
	1852,
	1220,
	1220,
	1220,
	1199,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1853,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1220,
	1853,
	1853,
	1853,
	1854,
	1854,
	1854,
	528,
	443,
	1855,
	46,
	201,
	133,
	528,
	23,
	3,
	0,
	23,
	1856,
	1091,
	1112,
	1112,
	23,
	26,
	26,
	679,
	1112,
	857,
	857,
	857,
	1857,
	857,
	1857,
	290,
	26,
	401,
	401,
	1112,
	1112,
	1858,
	1112,
	857,
	857,
	857,
	1857,
	857,
	1857,
	290,
	1138,
	1820,
	1859,
	1860,
	14,
	3,
	23,
	1095,
	1113,
	1501,
	1861,
	114,
	10,
	169,
	23,
	23,
	679,
	290,
	679,
	290,
	679,
	290,
	679,
	290,
	1094,
	1095,
	28,
	320,
	1816,
	1529,
	28,
	1862,
	320,
	320,
	14,
	62,
	3,
	3,
	3,
	133,
	1863,
	133,
	133,
	1864,
	502,
	1864,
	502,
	164,
	1865,
	1863,
	1866,
	1230,
	23,
	3,
	23,
	102,
	1108,
	113,
	1823,
	102,
	23,
	113,
	26,
	3,
	23,
	23,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpU2DfirstpassCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpU2DfirstpassCodeGenModule = 
{
	"Assembly-CSharp-firstpass.dll",
	684,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
