﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void AudioManager::PlaySound(AudioManager_SoundsBank,System.Boolean)
extern void AudioManager_PlaySound_m36B23BAC5E5A5A2671E9157B352A6400908A34F9 ();
// 0x00000002 System.Void AudioManager::StopSound()
extern void AudioManager_StopSound_m564B8B951F14E84B84D1C9F01A82861408CF4B7C ();
// 0x00000003 System.Void AudioManager::PlayMusic()
extern void AudioManager_PlayMusic_mAA147D259ECFF426B4C57085ED16F2E439D2E922 ();
// 0x00000004 System.Void AudioManager::.ctor()
extern void AudioManager__ctor_m9FC47B3998693846C091FB4C3731ACEF0359AC48 ();
// 0x00000005 System.Void Inventory::Start()
extern void Inventory_Start_mF9115FBB18A7772CAD4ED60B31A2F128DA55DF83 ();
// 0x00000006 System.Void Inventory::UI_ShowInventory()
extern void Inventory_UI_ShowInventory_m14E3051640B679BAC61BA3E2DBDBB5D7D3687942 ();
// 0x00000007 System.Void Inventory::UI_ShowQuestions()
extern void Inventory_UI_ShowQuestions_m730D061C35845AB44030E09E8ED12316B7C8848D ();
// 0x00000008 System.Void Inventory::UI_HideQuestions()
extern void Inventory_UI_HideQuestions_mFAD436F3DF04C224268A5C0A3274FCFC01225EE6 ();
// 0x00000009 System.Void Inventory::UI_HideInventory()
extern void Inventory_UI_HideInventory_m4E6CB6B72B1258F859327663E98914DB874FCB34 ();
// 0x0000000A System.Void Inventory::.ctor()
extern void Inventory__ctor_mB946DCD27224D66DDEE96C7EE8355A7E3FE91CC7 ();
// 0x0000000B System.Void Inventory::<Start>b__8_0()
extern void Inventory_U3CStartU3Eb__8_0_mDB42A7EF00F5F2BA16572DCD37A703C0C685A701 ();
// 0x0000000C System.Void Inventory::<Start>b__8_1()
extern void Inventory_U3CStartU3Eb__8_1_m517941B2DEBCC07899B222FBD088456FEBF96413 ();
// 0x0000000D System.Void Inventory::<UI_ShowInventory>b__9_0()
extern void Inventory_U3CUI_ShowInventoryU3Eb__9_0_mAE8CF90C14C3045830D66B12F2AF095252E7B2BD ();
// 0x0000000E System.Void Inventory::<UI_ShowQuestions>b__10_0()
extern void Inventory_U3CUI_ShowQuestionsU3Eb__10_0_m03BF8BC2AEBB7BB1A847168C8E79D625EFBF79BA ();
// 0x0000000F System.Void Inventory::<UI_HideQuestions>b__11_0()
extern void Inventory_U3CUI_HideQuestionsU3Eb__11_0_m78886BAB1C7A74DCA023C0455743B6D6A6F1E069 ();
// 0x00000010 System.Void Inventory::<UI_HideInventory>b__12_0()
extern void Inventory_U3CUI_HideInventoryU3Eb__12_0_mE5578E2216F31B280DD8844B8CABBF51C503F11C ();
// 0x00000011 System.Void Billboard::Start()
extern void Billboard_Start_m1AC12D68A41309EF5F07DBFD941B5AC1722FF3C3 ();
// 0x00000012 System.Void Billboard::LateUpdate()
extern void Billboard_LateUpdate_mFAC2B55D6823DDFE7A9FEDE8A6F76807CEBCE849 ();
// 0x00000013 System.Void Billboard::.ctor()
extern void Billboard__ctor_mE9B96D9746332E7B0C6FC0D2CB9610AA32DF5621 ();
// 0x00000014 System.Void BrainData::.ctor(Word)
extern void BrainData__ctor_mA5D7787A65E4529976F3742CE802023E4F0AC3A7 ();
// 0x00000015 System.Void BrainData::Swap(BrainData)
extern void BrainData_Swap_m357BBA4288C852DB75D3B7AF414531E9BD4A8008 ();
// 0x00000016 System.String BrainData::ToString()
extern void BrainData_ToString_m1FA7731A7C8B04ACB6C317424023129BB13ACBA5 ();
// 0x00000017 System.Void Brain::Awake()
extern void Brain_Awake_m67E7FA9A40D77A58B7F9E524CB964A1F6472DD5B ();
// 0x00000018 System.Void Brain::Start()
extern void Brain_Start_m3EBEACFA06EEA39DB275B65EC04B70B5D5E9EB9D ();
// 0x00000019 System.Void Brain::Reset()
extern void Brain_Reset_m6CEC3D2DB695244F92D8211DC809BAEB878C895B ();
// 0x0000001A System.Void Brain::Setup(LevelDefinition)
extern void Brain_Setup_m4A7682D4C51DEA0CE562824B65CDB8ED6B7A60BA ();
// 0x0000001B System.Void Brain::GatherBrainNodes(UnityEngine.Transform)
extern void Brain_GatherBrainNodes_m56C8C494E6A3302FC5576E327CC23AD8C2A2C8A1 ();
// 0x0000001C System.Void Brain::Update()
extern void Brain_Update_m82EF8196BFA77ACB4B62B214231D088AC22197C7 ();
// 0x0000001D System.Void Brain::OnNodeClick(BrainNode)
extern void Brain_OnNodeClick_mD70110CAE5913A5828C039A7C008DFEA10255CE5 ();
// 0x0000001E System.Void Brain::Show(System.Boolean)
extern void Brain_Show_m477198BBD8D571AF9AE4E18B73A9F1379A0F4611 ();
// 0x0000001F System.Void Brain::OnGUI()
extern void Brain_OnGUI_m856BE03F72378BB24596B7543E54D514FAD211CE ();
// 0x00000020 System.Void Brain::RefreshCursor()
extern void Brain_RefreshCursor_m31C49860F8079FBF3CE9484848AAE3BF7571E3B6 ();
// 0x00000021 System.Boolean Brain::ValidateBrain(System.Collections.Generic.List`1<LevelSolution>)
extern void Brain_ValidateBrain_mABE1E5D2D0ACD1120A7CF5D71A27C1333D9D7EF1 ();
// 0x00000022 BrainNode Brain::GetFromLabel(System.String)
extern void Brain_GetFromLabel_mC2C190E70EC9ED0F4DC0EC8B3458504978321E3C ();
// 0x00000023 System.Void Brain::RefreshFromLabel(System.String,Word&)
extern void Brain_RefreshFromLabel_mDBD567275EEF808F765566B47F7A7E838631EF36 ();
// 0x00000024 System.Void Brain::ShowInfoBox(System.Boolean,System.Boolean,System.Boolean)
extern void Brain_ShowInfoBox_m35E61EFB77C89BDAF67AB768019D96098DE62592 ();
// 0x00000025 System.Void Brain::ShowRotateInfo()
extern void Brain_ShowRotateInfo_m902D5DBBE677060A3ACB2FE7DA381BE227CC9BFA ();
// 0x00000026 System.Void Brain::.ctor()
extern void Brain__ctor_mC4EBB52ACB4919E67EFEE9D557E62CAF9FE335FE ();
// 0x00000027 System.Void BrainNode::Start()
extern void BrainNode_Start_m958FBB01AAD9824AF67BE5923F1862600CA4B94A ();
// 0x00000028 System.Void BrainNode::Init(UnityEngine.Camera)
extern void BrainNode_Init_m3E33A45397AF196726B74D6FB95E2FDA8CB17CE3 ();
// 0x00000029 System.Void BrainNode::OnMouseDown()
extern void BrainNode_OnMouseDown_mEA987A92BCCF0581B7A53A099403EA5E703C8944 ();
// 0x0000002A System.Void BrainNode::OnMouseEnter()
extern void BrainNode_OnMouseEnter_mFD58BE242A4A8FE55A17076F4660151DDF71F50D ();
// 0x0000002B System.Void BrainNode::RightClickReleased()
extern void BrainNode_RightClickReleased_mC5A868B9C6E3538A08E554086064A33245DF3248 ();
// 0x0000002C System.Void BrainNode::OnMouseExit()
extern void BrainNode_OnMouseExit_m41D7D8052D1CCFFDE8283ABC0FC576998467EDDA ();
// 0x0000002D System.Void BrainNode::SetEnabled(System.Boolean)
extern void BrainNode_SetEnabled_m9258639CF244ACE898F5F15B53CF551408E107D0 ();
// 0x0000002E System.Void BrainNode::SetReadyToSwap(System.Boolean)
extern void BrainNode_SetReadyToSwap_m941A3791170E0850CF2B484CA22CB1A9F57B190E ();
// 0x0000002F System.Void BrainNode::Swap(BrainNode)
extern void BrainNode_Swap_m4A9B215E5DE0C6B7488D4B350996088D0DA9F373 ();
// 0x00000030 System.Void BrainNode::Ping()
extern void BrainNode_Ping_m671D184B70F08752A6FF8FC0E4673DA2155762C8 ();
// 0x00000031 System.Collections.IEnumerator BrainNode::DoStopPingAfterSeconds()
extern void BrainNode_DoStopPingAfterSeconds_mA75ACA677CA857E79ADB14B2F73B091614D15903 ();
// 0x00000032 System.Void BrainNode::.ctor()
extern void BrainNode__ctor_m4317AFD1ED4C9321DBD1E29E463C123BFBF3C646 ();
// 0x00000033 System.Void BrainPart::Awake()
extern void BrainPart_Awake_mF2BDA675856A7197EEEA797B0137F8C479146BAF ();
// 0x00000034 System.Void BrainPart::OnMouseOver()
extern void BrainPart_OnMouseOver_m12436667D25700188B00A5C8826B2BEB2CF71D49 ();
// 0x00000035 System.Void BrainPart::.ctor()
extern void BrainPart__ctor_mEF9B87B2C7F5025F0243C9B1A08C02DB56ACBCF4 ();
// 0x00000036 System.Void LevelQuestion::.ctor()
extern void LevelQuestion__ctor_m2CFE5C11AEFF1DB164D13177184C3EB1DF746278 ();
// 0x00000037 System.Void LevelBrainNode::.ctor()
extern void LevelBrainNode__ctor_m8E82565EDD3F650AB6959B9AB3FD8E6160B048CB ();
// 0x00000038 System.Void LevelProblem::.ctor()
extern void LevelProblem__ctor_m424BDF761C9D63A60921FE913F8F8D642C2E93F0 ();
// 0x00000039 System.Boolean LevelSolution::ValidateBrain(System.Collections.Generic.List`1<BrainNode>)
extern void LevelSolution_ValidateBrain_m8C62AEC006E7087578B1C9CA3DBFD3B15E7696C1 ();
// 0x0000003A System.Boolean LevelSolution::ValidateSolution(BrainNode)
extern void LevelSolution_ValidateSolution_m5D0ECA7F0CED5442BE9A0C9994042D9780BE317A ();
// 0x0000003B System.Void LevelSolution::.ctor()
extern void LevelSolution__ctor_m18B2715214BC0EBF6D0619D7F1A7CCDE344D0665 ();
// 0x0000003C System.Collections.Generic.List`1<BrainData> LevelDefinition::GenerateBrainDataList()
extern void LevelDefinition_GenerateBrainDataList_mA8AD8340ACBE723E4518F8D97840A5F2AFF8D3E4 ();
// 0x0000003D System.Void LevelDefinition::FuckUp(Brain)
extern void LevelDefinition_FuckUp_m00C45F69C5F1403A753E2D862C3C4373297FE6C4 ();
// 0x0000003E System.Void LevelDefinition::.ctor()
extern void LevelDefinition__ctor_mBF4C9901FBF5805DFA42D9BC9694FF2C6223F18F ();
// 0x0000003F System.Void OrbitCamera::Start()
extern void OrbitCamera_Start_m235E2D4C13DA3B3E9B581596012462CE08075B09 ();
// 0x00000040 System.Void OrbitCamera::Update()
extern void OrbitCamera_Update_m170BA9D94A3A8FCF69078EAF9A0E99859742B3D6 ();
// 0x00000041 System.Void OrbitCamera::RefresPosition()
extern void OrbitCamera_RefresPosition_m52519777DDC9338ADEA86317400C7C38901FDF12 ();
// 0x00000042 System.Void OrbitCamera::.ctor()
extern void OrbitCamera__ctor_mB47F990A2C47EE712316916E1B22D37EAFF5281F ();
// 0x00000043 System.Void QuestionButton::Awake()
extern void QuestionButton_Awake_m63D03FEF74E190021DA752C55D40BCAA37D658B0 ();
// 0x00000044 System.Void QuestionButton::Initialized(LevelDefinition)
extern void QuestionButton_Initialized_mF885417DEB9AF51FC23EECB6C5131E15931B10E5 ();
// 0x00000045 System.Void QuestionButton::ScaleUp()
extern void QuestionButton_ScaleUp_m59D94C260AEF5D5B3D9D2DEEFC513F6704B877E7 ();
// 0x00000046 System.Void QuestionButton::.ctor()
extern void QuestionButton__ctor_mAE80962AD92D39892A892D82B57118B9C651A7BB ();
// 0x00000047 System.Void QuestionButton::<ScaleUp>b__12_0()
extern void QuestionButton_U3CScaleUpU3Eb__12_0_m55B2C5610D6C34B78442E25B5C3969895B8BE5C5 ();
// 0x00000048 System.Void TextDiagnostic::BuildWordList()
extern void TextDiagnostic_BuildWordList_m2929E4E6917D71A141F59D864280A9E875426B0E ();
// 0x00000049 System.Collections.Generic.List`1<BrainData> TextDiagnostic::GatherBrainData()
extern void TextDiagnostic_GatherBrainData_m25CF469AA26E2F0A5918BAB03CF0C17CF11D80E4 ();
// 0x0000004A System.Void TextDiagnostic::.ctor()
extern void TextDiagnostic__ctor_mA10957397DF9343BB0E5410B533FA6AF76598344 ();
// 0x0000004B System.Void TextSpeachAnimation::Awake()
extern void TextSpeachAnimation_Awake_mDE028C66F82A1B02BE7497E3B4EE6092EFA16A3E ();
// 0x0000004C System.Void TextSpeachAnimation::Start()
extern void TextSpeachAnimation_Start_m55E7755DBEB4BFC8906E7352AE2EB2EF8662BAC5 ();
// 0x0000004D System.Void TextSpeachAnimation::ClearLine()
extern void TextSpeachAnimation_ClearLine_mA0E2736647E116C2208AED54CAB939C0857C1878 ();
// 0x0000004E System.Void TextSpeachAnimation::SetupLine(TextDiagnostic)
extern void TextSpeachAnimation_SetupLine_m6611A535BFD50FC3C711F17F98B42CE681C2E74A ();
// 0x0000004F System.Void TextSpeachAnimation::Update()
extern void TextSpeachAnimation_Update_mD976A2308F1902D01DD7CE3F28EA141F9C1BD341 ();
// 0x00000050 System.Void TextSpeachAnimation::AnimateText()
extern void TextSpeachAnimation_AnimateText_mC9D92E9E4FBFDCF1043770D5B9677B7BB612A6B5 ();
// 0x00000051 System.Void TextSpeachAnimation::.ctor()
extern void TextSpeachAnimation__ctor_mE0D57FD0CBB39F349B34295D3109992DA8B617C0 ();
// 0x00000052 System.Void Animate::Awake()
extern void Animate_Awake_m6F54AFC516F73A6168AC5CAFCDABB4B48269F6F1 ();
// 0x00000053 System.Void Animate::Play()
extern void Animate_Play_m5E9E38F7F77BC5642589137EA8D57D99E4B422D3 ();
// 0x00000054 System.Void Animate::SpeedUp(System.Single)
extern void Animate_SpeedUp_m7F6E45A5DA94BCC62B2F3CE4BFA5E05D0912C884 ();
// 0x00000055 System.Void Animate::Stop()
extern void Animate_Stop_m11FED75393F017DF0546F578B824BEF827ABD0A0 ();
// 0x00000056 System.Collections.IEnumerator Animate::AnimateSprite()
extern void Animate_AnimateSprite_mF00398BF40AABF3D684E8DB51DED52BF3E0B73AC ();
// 0x00000057 System.Void Animate::.ctor()
extern void Animate__ctor_m6B80057CA37ACCDE76F37CACC24126FA1E75A01E ();
// 0x00000058 System.Void BootLoader::Start()
extern void BootLoader_Start_m5A7CC47839F69FD029B29DAB8E81B9CE7159CE39 ();
// 0x00000059 System.Void BootLoader::OnSceneLoaded(UnityEngine.SceneManagement.Scene,UnityEngine.SceneManagement.LoadSceneMode)
extern void BootLoader_OnSceneLoaded_m0DCD6FEFB4BEDF43E69B150A1B63E67759E2C640 ();
// 0x0000005A System.Void BootLoader::NextLevel(System.Boolean)
extern void BootLoader_NextLevel_m844FDF74EE2C4CD84293825F37996DDDDF26AFF3 ();
// 0x0000005B System.Void BootLoader::EndOfGame()
extern void BootLoader_EndOfGame_mDF2CF81EE6BC2C31379DDCBCD7D4E77958CC8A7E ();
// 0x0000005C System.Void BootLoader::InstantiateLevelObjects()
extern void BootLoader_InstantiateLevelObjects_m9E838FBC05AF4310B200C4F252D930A141FC10A5 ();
// 0x0000005D System.Void BootLoader::UI_StartGame()
extern void BootLoader_UI_StartGame_m2C8E372FD6F0EBB03E9C12F9A7399EB897EE1C5A ();
// 0x0000005E System.Collections.IEnumerator BootLoader::ShowBubbleAfterAFewSeconds(System.Single)
extern void BootLoader_ShowBubbleAfterAFewSeconds_m7967BF066B22A88D44510EC48B53DA518AFC23EF ();
// 0x0000005F System.Collections.IEnumerator BootLoader::NextLevelAfterAFewSeconds(System.Single)
extern void BootLoader_NextLevelAfterAFewSeconds_m2D25553FB9CB245ADFEAAC871590AF482A3138ED ();
// 0x00000060 System.Void BootLoader::ShowSpeech()
extern void BootLoader_ShowSpeech_m42AAB4B82628E2563C09058759FFFB9C7AEDCCF5 ();
// 0x00000061 System.Void BootLoader::HideSpeech()
extern void BootLoader_HideSpeech_mB830D7254ECEED9FC1C16AE02DD36917C8A1849E ();
// 0x00000062 System.Void BootLoader::OnTextComplete()
extern void BootLoader_OnTextComplete_m95EF3798CEF043A8E4916624FC810156059FC07D ();
// 0x00000063 System.Void BootLoader::UI_ShowMenu()
extern void BootLoader_UI_ShowMenu_mD331D79A4808095F03CEC73F91C22096B4BAB456 ();
// 0x00000064 System.Void BootLoader::UI_AskQuestion(System.Int32)
extern void BootLoader_UI_AskQuestion_m06553E3DA41C8068A63B171FF80A8C893A3427B3 ();
// 0x00000065 System.Void BootLoader::UI_TestSolution()
extern void BootLoader_UI_TestSolution_m9CBEE76F9EDA12B72564FF563EC7DE91EDD1BF65 ();
// 0x00000066 System.Void BootLoader::UI_CloseScreen()
extern void BootLoader_UI_CloseScreen_m4BDCC045829184900AB823B40131CD577A2301F8 ();
// 0x00000067 System.Void BootLoader::Update()
extern void BootLoader_Update_m4D5CE00F24B31FB8AC6827BC3CBE89C64542AF20 ();
// 0x00000068 System.Void BootLoader::StartGame(System.Boolean)
extern void BootLoader_StartGame_m98AC1B88F27E8FF25C2A9B47DE19E0E33E8D5BA8 ();
// 0x00000069 System.Void BootLoader::.ctor()
extern void BootLoader__ctor_mF3EC10EA4D8830389CE1A9B976963E689E778EEF ();
// 0x0000006A System.Void BootLoader::<UI_StartGame>b__40_0()
extern void BootLoader_U3CUI_StartGameU3Eb__40_0_m3E351451115DC2DDF6D08C23A48D8481801AC763 ();
// 0x0000006B System.Void BootLoader::<UI_StartGame>b__40_1()
extern void BootLoader_U3CUI_StartGameU3Eb__40_1_m192F75931FF6F07854C8AC04D88B8E37CD83A32D ();
// 0x0000006C System.Void BootLoader::<ShowSpeech>b__43_0()
extern void BootLoader_U3CShowSpeechU3Eb__43_0_m57FC470F94FB2909176225934B3489CD97017957 ();
// 0x0000006D System.Void BootLoader::<HideSpeech>b__44_0()
extern void BootLoader_U3CHideSpeechU3Eb__44_0_m84EC88C700D7EDCDD14F13E44662831467C74D9C ();
// 0x0000006E System.Void BootLoader::<UI_ShowMenu>b__46_1()
extern void BootLoader_U3CUI_ShowMenuU3Eb__46_1_m140D3238269922659322C9005DBE0A3BB79D7AA9 ();
// 0x0000006F System.Void Client::Start()
extern void Client_Start_mE6BA86C48F3D3C40438044A472C3565A1A6A85D5 ();
// 0x00000070 System.Void Client::Init(LevelDefinition,TextSpeachAnimation)
extern void Client_Init_m0BA36703D6CCFD8C7BFC50F79D95F8D8CF31BDEB ();
// 0x00000071 System.Void Client::Talk()
extern void Client_Talk_m0A70DD78A9DA6DE6F4D7464C8D0B01DDCEB3A250 ();
// 0x00000072 System.Void Client::Shutup()
extern void Client_Shutup_m5CDBA5667A99D21BE82506FEB4A0502AA15111E1 ();
// 0x00000073 System.Void Client::AskQuestion(System.Int32)
extern void Client_AskQuestion_m3B9FA1333D4C5729FFEEE1C92CD33B34B8A7309A ();
// 0x00000074 System.Void Client::.ctor()
extern void Client__ctor_m3ECF301B53E250235D807DA842698ADC0B7AAE4E ();
// 0x00000075 System.Void Downscale::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Downscale_OnRenderImage_m47623695F461FA94C453DFF541828F64BD217007 ();
// 0x00000076 System.Void Downscale::.ctor()
extern void Downscale__ctor_m9E3D40E03F58753C8B81190185B36EC9A5766CB8 ();
// 0x00000077 System.Void Downscale::.cctor()
extern void Downscale__cctor_m509BAF794616E0E7C963F1EC5919B457F917A6AB ();
// 0x00000078 System.Void FadeInOut::FadeOut()
extern void FadeInOut_FadeOut_mA8281FDA135801735B68B8D9A08BC7827766CEC5 ();
// 0x00000079 System.Void FadeInOut::FadeIn()
extern void FadeInOut_FadeIn_m3B5206CA5EFD76FB306DCCF5FAEAC99CD2AE8252 ();
// 0x0000007A System.Void FadeInOut::Update()
extern void FadeInOut_Update_m6A4A77E26E6C118589BF3FB10029BF378C0C2F8A ();
// 0x0000007B System.Void FadeInOut::.ctor()
extern void FadeInOut__ctor_mD4DACAA2F245971E56842C5141AB3E7CF8AC52E2 ();
// 0x0000007C System.Void FadeInOut::.cctor()
extern void FadeInOut__cctor_m3E8E31753AF656A9DEB33F3E801BDC359138440A ();
// 0x0000007D System.Void InputManager::Awake()
extern void InputManager_Awake_m44B8E66D7CD2B21235B19CDEE94A41DE98F27A57 ();
// 0x0000007E System.Void InputManager::RegisterHovering()
extern void InputManager_RegisterHovering_mE14837E1CA3EF23CA911222114E4FCF7A9A0185D ();
// 0x0000007F System.Void InputManager::UnregisterHovering()
extern void InputManager_UnregisterHovering_mF1E1452AA09E7EA8DB40B56FA7967403665C4597 ();
// 0x00000080 System.Void InputManager::RegisterOrUnregisterForHovering(System.Boolean)
extern void InputManager_RegisterOrUnregisterForHovering_m544B7CC240392A4528AAF7CE70167E9718CD0F5F ();
// 0x00000081 System.Void InputManager::Update()
extern void InputManager_Update_mE33DE68FFB22D0E8C2B866E4B3122F1D645F421A ();
// 0x00000082 System.Void InputManager::.ctor()
extern void InputManager__ctor_m737855D101985541227BC2D1077149CB836C0360 ();
// 0x00000083 System.Void LoadingScreen::Awake()
extern void LoadingScreen_Awake_mDE29F3E53E77F10C94EBFDCFFE3AF1481C0F95D5 ();
// 0x00000084 System.Void LoadingScreen::Update()
extern void LoadingScreen_Update_m202E092715604392C9D4DE8884259A2B41B09E76 ();
// 0x00000085 System.Void LoadingScreen::StartSequences()
extern void LoadingScreen_StartSequences_m00CCC4247D902EE00DD97D40AA87CF52C05B3E19 ();
// 0x00000086 System.Collections.IEnumerator LoadingScreen::ScaleLogo()
extern void LoadingScreen_ScaleLogo_m106F4C29FB600B46EF332584EBCDDFDB98696D71 ();
// 0x00000087 System.Collections.IEnumerator LoadingScreen::LoadingScreenSequence()
extern void LoadingScreen_LoadingScreenSequence_mD362D088405D61E74CB8BBD74EE95B1E4C19DB45 ();
// 0x00000088 System.Void LoadingScreen::FadeOutThisScene(UnityEngine.AsyncOperation)
extern void LoadingScreen_FadeOutThisScene_mF3413F956031CC02A6ECDE82DEC98B8708848D98 ();
// 0x00000089 System.Void LoadingScreen::FadeOutInSeconds()
extern void LoadingScreen_FadeOutInSeconds_m4C517ED72DC9E00423687842108FDEC066E5F03A ();
// 0x0000008A System.Void LoadingScreen::.ctor()
extern void LoadingScreen__ctor_m3C1C0C2B4E0FD72B27554A19863037EE28C3F0F6 ();
// 0x0000008B System.Void LoadingScreen::.cctor()
extern void LoadingScreen__cctor_m24227D62786888EDF2F209FCD66A5571BA1A35DD ();
// 0x0000008C System.Boolean LoadingScreen::<LoadingScreenSequence>b__34_0()
extern void LoadingScreen_U3CLoadingScreenSequenceU3Eb__34_0_m4D7DCF684A9D98BC371D6271403489981350474C ();
// 0x0000008D System.Boolean LoadingScreen::<LoadingScreenSequence>b__34_1()
extern void LoadingScreen_U3CLoadingScreenSequenceU3Eb__34_1_mC5E08DBE998C657ED587D83A0F91257547A0C0B4 ();
// 0x0000008E System.Void Menu::UI_MainMenu()
extern void Menu_UI_MainMenu_m0B1303C3560397BE8DDC9BE58CCCDD10E4543338 ();
// 0x0000008F System.Void Menu::UI_StartGame()
extern void Menu_UI_StartGame_m8C186A4FC0F787209E99277273620963996C2047 ();
// 0x00000090 System.Void Menu::UI_EndofGame()
extern void Menu_UI_EndofGame_m0472EEBD626E257A4019C74CF7D48EA553D3FDBB ();
// 0x00000091 System.Void Menu::UI_Credits()
extern void Menu_UI_Credits_m639D93DF115AAB966C39661365A49D6834D51C97 ();
// 0x00000092 System.Void Menu::UI_Controls()
extern void Menu_UI_Controls_mF289C9AA6EC81FEFE6AB72CE01057103CC58F781 ();
// 0x00000093 System.Void Menu::.ctor()
extern void Menu__ctor_mD372D109F6554E1F9A25291964C852C9F6BFC463 ();
// 0x00000094 System.Void Menu::<UI_StartGame>b__11_0()
extern void Menu_U3CUI_StartGameU3Eb__11_0_m5EC38BFEB5B97D637CE585136AFDBB193EC222FB ();
// 0x00000095 System.Void Menu::<UI_Credits>b__13_0()
extern void Menu_U3CUI_CreditsU3Eb__13_0_m5E215482A8491B365C1EE9BC5F0D99D2A84F62F2 ();
// 0x00000096 System.Void OnClickOutside::Awake()
extern void OnClickOutside_Awake_m708865BB3F060DFF411792133A324736635931F2 ();
// 0x00000097 System.Void OnClickOutside::Update()
extern void OnClickOutside_Update_mD188F2CE672051B3619A8799AFC15DD384A0B4BA ();
// 0x00000098 System.Void OnClickOutside::.ctor()
extern void OnClickOutside__ctor_m13E20D9702B9F5B6141E8B4EAD5AA85E3B380151 ();
// 0x00000099 System.Void SetCameraViewport::Awake()
extern void SetCameraViewport_Awake_m7DD5D2D4BE3C127E95B941F343C98A4BED2F24A0 ();
// 0x0000009A System.Void SetCameraViewport::.ctor()
extern void SetCameraViewport__ctor_mD54CD23F0BBA492E47F2F5F8EE6BD52725EA68CA ();
// 0x0000009B System.Boolean TextAnimate::get_IsAnimated()
extern void TextAnimate_get_IsAnimated_m9414B669F37591247B8BB34571DEA3AF117BF47E ();
// 0x0000009C System.Void TextAnimate::set_IsAnimated(System.Boolean)
extern void TextAnimate_set_IsAnimated_mAAEDDF94783AAF9593DE7149C281D4683205F31F ();
// 0x0000009D System.Void TextAnimate::Awake()
extern void TextAnimate_Awake_m40BA367DFA20C965A662AC6C17A6A0A71506FC2E ();
// 0x0000009E System.Void TextAnimate::ClearText()
extern void TextAnimate_ClearText_mDCE8248EE96F21EE93C0E26BB59A0EDEC6F647F7 ();
// 0x0000009F System.Void TextAnimate::Update()
extern void TextAnimate_Update_m4F3473AA14E8FCDB622F1A379746165436B95191 ();
// 0x000000A0 System.Void TextAnimate::.ctor()
extern void TextAnimate__ctor_m145BB57E6C2EAF9F042A8621575D4D5888D07B2A ();
// 0x000000A1 System.Void Upscale::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Upscale_OnRenderImage_m7451FB94B319B6A3D5385A6D2A2736FB04ADA376 ();
// 0x000000A2 System.Void Upscale::.ctor()
extern void Upscale__ctor_mFF5C1C9C2DD39EB1C45960711F496EC4FB705081 ();
// 0x000000A3 System.Void Upscale::.cctor()
extern void Upscale__cctor_m2260479F630BD03821A4DEA8589C1777E9593009 ();
// 0x000000A4 System.Boolean WorldButton::get_HoverEnabled()
extern void WorldButton_get_HoverEnabled_mC346EA6E632BACC0272992740EFCEA6D53B23928 ();
// 0x000000A5 System.Void WorldButton::GetInputManager()
extern void WorldButton_GetInputManager_mE32338F8ACDD364AE5FF0C8F0AB9ED369494D8CB ();
// 0x000000A6 System.Void WorldButton::Awake()
extern void WorldButton_Awake_m912CF3C5A3B95CA49D0CC037C6F9673A3584738A ();
// 0x000000A7 System.Void WorldButton::OnEnable()
extern void WorldButton_OnEnable_m85A02BE32814508CCB14A05581DFE956757FCFB5 ();
// 0x000000A8 System.Void WorldButton::OnDisable()
extern void WorldButton_OnDisable_m9689600680827D31C11BFDF40D7576795D009F68 ();
// 0x000000A9 System.Boolean WorldButton::Click()
extern void WorldButton_Click_m673DE527EC56F558B23632460218B1ADAB75DD63 ();
// 0x000000AA System.Void WorldButton::IsHovering(System.Boolean)
extern void WorldButton_IsHovering_m3FC642F477189C0066BD60D348C01A5B9FC5E553 ();
// 0x000000AB System.Void WorldButton::.ctor()
extern void WorldButton__ctor_m80BC75B16A25C4B60C0B6FA53ECAA7967DF1D36A ();
// 0x000000AC System.Void Word::.ctor(System.String)
extern void Word__ctor_mA2B34A8AB70451C4840D42321A61BE0B56BA24DB ();
// 0x000000AD System.Void Word::.ctor(Word)
extern void Word__ctor_m1EAB275A01983E759CE2D0540E8BEF25D03CE0D3 ();
// 0x000000AE System.Void Word::ExtractLabel()
extern void Word_ExtractLabel_mC15FCEDFFA286AB455926C5D5EF1DB57BC503F55 ();
// 0x000000AF System.String Word::ToString()
extern void Word_ToString_m096F89ADC63EE4C516E7A620CC3C8C1EF0C072BB ();
// 0x000000B0 System.Void WordDisplayText::.ctor(Word,System.Int32,BootLoader)
extern void WordDisplayText__ctor_mCD293C76EB2CB0FFFD3BF010FEFF5514ADA303F2 ();
// 0x000000B1 System.Boolean WordDisplayText::IsFullyDisplayed()
extern void WordDisplayText_IsFullyDisplayed_m0ABAF83AC80EE62F980787535861FA53B7557364 ();
// 0x000000B2 System.String WordDisplayText::ColorFromPrefix()
extern void WordDisplayText_ColorFromPrefix_mDB370728617E07B3DBFEE99FE90B07F05E8A3EEA ();
// 0x000000B3 System.String WordDisplayText::Animate()
extern void WordDisplayText_Animate_mAA823A66B14F39272566F1447ECADB7B92028B3A ();
// 0x000000B4 System.String WordDisplayText::ShowLastLetter()
extern void WordDisplayText_ShowLastLetter_mACFE94DDAFB351745BBDF7C00DEAD0E29F6638EF ();
// 0x000000B5 System.String WordDisplayText::ShowCharacters()
extern void WordDisplayText_ShowCharacters_m065899D17E3EF3AD7A18AC3BB2FBD43455014E56 ();
// 0x000000B6 System.Void WordDisplayText::Refresh()
extern void WordDisplayText_Refresh_m3A7E250DF38C38E3DF552FCFB449D6388F08B748 ();
// 0x000000B7 System.Void BrainNode_<DoStopPingAfterSeconds>d__26::.ctor(System.Int32)
extern void U3CDoStopPingAfterSecondsU3Ed__26__ctor_m06128F1E46E7AEF2F074A9FAA1FB3CB9695D51C5 ();
// 0x000000B8 System.Void BrainNode_<DoStopPingAfterSeconds>d__26::System.IDisposable.Dispose()
extern void U3CDoStopPingAfterSecondsU3Ed__26_System_IDisposable_Dispose_m6B7BDC7F98DF704A292AD4278793D0AED5B6C4FF ();
// 0x000000B9 System.Boolean BrainNode_<DoStopPingAfterSeconds>d__26::MoveNext()
extern void U3CDoStopPingAfterSecondsU3Ed__26_MoveNext_mD62CE0C65EF748AD176808FC26AEF382BC571DA7 ();
// 0x000000BA System.Object BrainNode_<DoStopPingAfterSeconds>d__26::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDoStopPingAfterSecondsU3Ed__26_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mAAE6064EE2453A6A28BCB066E3AEA041D179D805 ();
// 0x000000BB System.Void BrainNode_<DoStopPingAfterSeconds>d__26::System.Collections.IEnumerator.Reset()
extern void U3CDoStopPingAfterSecondsU3Ed__26_System_Collections_IEnumerator_Reset_m5F84A55D959BC4E441DC3A0799118DD8275E1B08 ();
// 0x000000BC System.Object BrainNode_<DoStopPingAfterSeconds>d__26::System.Collections.IEnumerator.get_Current()
extern void U3CDoStopPingAfterSecondsU3Ed__26_System_Collections_IEnumerator_get_Current_mF9D48A9955EEC6CEF6959245C0BC89DB985312D7 ();
// 0x000000BD System.Void Animate_<AnimateSprite>d__15::.ctor(System.Int32)
extern void U3CAnimateSpriteU3Ed__15__ctor_m879500AFD4E4E9D791F1BADBFB7E1667E66CBD43 ();
// 0x000000BE System.Void Animate_<AnimateSprite>d__15::System.IDisposable.Dispose()
extern void U3CAnimateSpriteU3Ed__15_System_IDisposable_Dispose_m750CC30682602F2B7C6EF037E84BBCCE406EA59E ();
// 0x000000BF System.Boolean Animate_<AnimateSprite>d__15::MoveNext()
extern void U3CAnimateSpriteU3Ed__15_MoveNext_mA9E3297C2E0D8F368295FE6B2E98CFE24DCB1D1C ();
// 0x000000C0 System.Object Animate_<AnimateSprite>d__15::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateSpriteU3Ed__15_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8373DFDD65DCFDA2865050D9BDCDE260731EE21C ();
// 0x000000C1 System.Void Animate_<AnimateSprite>d__15::System.Collections.IEnumerator.Reset()
extern void U3CAnimateSpriteU3Ed__15_System_Collections_IEnumerator_Reset_m528F213AD3FA98DD6775CB7365880C09E3FC6533 ();
// 0x000000C2 System.Object Animate_<AnimateSprite>d__15::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateSpriteU3Ed__15_System_Collections_IEnumerator_get_Current_mEE4CBF87C9521AF0A12BD5B75822866E5BDC3F12 ();
// 0x000000C3 System.Void BootLoader_<ShowBubbleAfterAFewSeconds>d__41::.ctor(System.Int32)
extern void U3CShowBubbleAfterAFewSecondsU3Ed__41__ctor_mC92B4DC11DF2C637E1D6526E5E7F5F89867510A9 ();
// 0x000000C4 System.Void BootLoader_<ShowBubbleAfterAFewSeconds>d__41::System.IDisposable.Dispose()
extern void U3CShowBubbleAfterAFewSecondsU3Ed__41_System_IDisposable_Dispose_m3D652CADFC1B52B6ECCEF28A5DFAE23176AC95E9 ();
// 0x000000C5 System.Boolean BootLoader_<ShowBubbleAfterAFewSeconds>d__41::MoveNext()
extern void U3CShowBubbleAfterAFewSecondsU3Ed__41_MoveNext_mFF2DA34337B6ADC4ED2EF395FE3D227CC8BF9D7C ();
// 0x000000C6 System.Object BootLoader_<ShowBubbleAfterAFewSeconds>d__41::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CShowBubbleAfterAFewSecondsU3Ed__41_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC15030673C7A6E0DB40AFF28D7F35AC40929B7AC ();
// 0x000000C7 System.Void BootLoader_<ShowBubbleAfterAFewSeconds>d__41::System.Collections.IEnumerator.Reset()
extern void U3CShowBubbleAfterAFewSecondsU3Ed__41_System_Collections_IEnumerator_Reset_mC0923D767368CFADB163AE119494093EE5D90551 ();
// 0x000000C8 System.Object BootLoader_<ShowBubbleAfterAFewSeconds>d__41::System.Collections.IEnumerator.get_Current()
extern void U3CShowBubbleAfterAFewSecondsU3Ed__41_System_Collections_IEnumerator_get_Current_mB01BA0439E6D7BDEF334BA95C81388E02521B2E5 ();
// 0x000000C9 System.Void BootLoader_<NextLevelAfterAFewSeconds>d__42::.ctor(System.Int32)
extern void U3CNextLevelAfterAFewSecondsU3Ed__42__ctor_m9DFE3155B80A81DC0ADACDC397ABBE23767EAE94 ();
// 0x000000CA System.Void BootLoader_<NextLevelAfterAFewSeconds>d__42::System.IDisposable.Dispose()
extern void U3CNextLevelAfterAFewSecondsU3Ed__42_System_IDisposable_Dispose_mE0C6A193102C0D2A094BD5BAA8824E4CDEA96214 ();
// 0x000000CB System.Boolean BootLoader_<NextLevelAfterAFewSeconds>d__42::MoveNext()
extern void U3CNextLevelAfterAFewSecondsU3Ed__42_MoveNext_mD8601CC12AB3C4EADBA3EA9CA106F4A50F3C7C55 ();
// 0x000000CC System.Object BootLoader_<NextLevelAfterAFewSeconds>d__42::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CNextLevelAfterAFewSecondsU3Ed__42_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5CCBEFBFB319109BDAAF0167681BB3259AB40564 ();
// 0x000000CD System.Void BootLoader_<NextLevelAfterAFewSeconds>d__42::System.Collections.IEnumerator.Reset()
extern void U3CNextLevelAfterAFewSecondsU3Ed__42_System_Collections_IEnumerator_Reset_mD934BEEC265453647D7E8542B970B807F2BA18DF ();
// 0x000000CE System.Object BootLoader_<NextLevelAfterAFewSeconds>d__42::System.Collections.IEnumerator.get_Current()
extern void U3CNextLevelAfterAFewSecondsU3Ed__42_System_Collections_IEnumerator_get_Current_m6C9D8D133DEB7D9BCC1A75F686F35A63A7E8C46E ();
// 0x000000CF System.Void BootLoader_<>c::.cctor()
extern void U3CU3Ec__cctor_mC272616B5BCCC257601C3AB8662C3B9B874DEB94 ();
// 0x000000D0 System.Void BootLoader_<>c::.ctor()
extern void U3CU3Ec__ctor_mB7A616D84F40ED805A4B9DCEDA91C1A17D28A20E ();
// 0x000000D1 System.Void BootLoader_<>c::<HideSpeech>b__44_1(QuestionButton)
extern void U3CU3Ec_U3CHideSpeechU3Eb__44_1_mE08CD7F49730AFC93A2635106AE461B849B85D79 ();
// 0x000000D2 System.Void BootLoader_<>c::<OnTextComplete>b__45_0(QuestionButton)
extern void U3CU3Ec_U3COnTextCompleteU3Eb__45_0_m0F4C35E4C0E3370BCA1B5DFCEC9C06471937AF9D ();
// 0x000000D3 System.Void BootLoader_<>c::<UI_ShowMenu>b__46_0(QuestionButton)
extern void U3CU3Ec_U3CUI_ShowMenuU3Eb__46_0_m14A778F98E47EA84A9B806309C1FD014B4A787D6 ();
// 0x000000D4 System.Void LoadingScreen_<ScaleLogo>d__33::.ctor(System.Int32)
extern void U3CScaleLogoU3Ed__33__ctor_m3B94C7AFA02F179EB9F46E6E5E14C966CB09D479 ();
// 0x000000D5 System.Void LoadingScreen_<ScaleLogo>d__33::System.IDisposable.Dispose()
extern void U3CScaleLogoU3Ed__33_System_IDisposable_Dispose_m907D546BFD602C423B19E0CA3E72C3FD4978F7F8 ();
// 0x000000D6 System.Boolean LoadingScreen_<ScaleLogo>d__33::MoveNext()
extern void U3CScaleLogoU3Ed__33_MoveNext_mDFA4AF78E280A18170BE767F97AA48D418867653 ();
// 0x000000D7 System.Object LoadingScreen_<ScaleLogo>d__33::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CScaleLogoU3Ed__33_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m25D039FE2F6F2333995AB1B3A5D72A40A66F5565 ();
// 0x000000D8 System.Void LoadingScreen_<ScaleLogo>d__33::System.Collections.IEnumerator.Reset()
extern void U3CScaleLogoU3Ed__33_System_Collections_IEnumerator_Reset_m0583159CCA875C7B1EFB1E73C432CB6E8C8D71FB ();
// 0x000000D9 System.Object LoadingScreen_<ScaleLogo>d__33::System.Collections.IEnumerator.get_Current()
extern void U3CScaleLogoU3Ed__33_System_Collections_IEnumerator_get_Current_mFECE9CA26B8B74D72711F2A11F38F0CB71DED116 ();
// 0x000000DA System.Void LoadingScreen_<LoadingScreenSequence>d__34::.ctor(System.Int32)
extern void U3CLoadingScreenSequenceU3Ed__34__ctor_mA3C109F7C7106F666FF56735CC57B3B2880E6009 ();
// 0x000000DB System.Void LoadingScreen_<LoadingScreenSequence>d__34::System.IDisposable.Dispose()
extern void U3CLoadingScreenSequenceU3Ed__34_System_IDisposable_Dispose_m85ED26BFB68957B0D0D5FCE1355C80B0DEFB8EAE ();
// 0x000000DC System.Boolean LoadingScreen_<LoadingScreenSequence>d__34::MoveNext()
extern void U3CLoadingScreenSequenceU3Ed__34_MoveNext_m8E9D6E683B62B9B980F6ED1799B4C9EB5C1A3CC7 ();
// 0x000000DD System.Object LoadingScreen_<LoadingScreenSequence>d__34::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CLoadingScreenSequenceU3Ed__34_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0DF1293A07FBF1198442060DA87366F3C336A2A4 ();
// 0x000000DE System.Void LoadingScreen_<LoadingScreenSequence>d__34::System.Collections.IEnumerator.Reset()
extern void U3CLoadingScreenSequenceU3Ed__34_System_Collections_IEnumerator_Reset_mFD7D3672EDA3AF30AC576F00DC0812ED6557B9EB ();
// 0x000000DF System.Object LoadingScreen_<LoadingScreenSequence>d__34::System.Collections.IEnumerator.get_Current()
extern void U3CLoadingScreenSequenceU3Ed__34_System_Collections_IEnumerator_get_Current_m9FC8465B59B14D75397F7FDAE5D3826F098EE79D ();
// 0x000000E0 System.Void Menu_<>c::.cctor()
extern void U3CU3Ec__cctor_m3800B55D196E21565F6AFD81F0F5D02ADB63D2B9 ();
// 0x000000E1 System.Void Menu_<>c::.ctor()
extern void U3CU3Ec__ctor_mFE3BF264A0FD7756D7E8964846EA1BA6B58BD6CB ();
// 0x000000E2 System.Void Menu_<>c::<UI_Credits>b__13_1()
extern void U3CU3Ec_U3CUI_CreditsU3Eb__13_1_m6B9041AB7455F1BC2AF6D66B19C4716F0968C084 ();
static Il2CppMethodPointer s_methodPointers[226] = 
{
	AudioManager_PlaySound_m36B23BAC5E5A5A2671E9157B352A6400908A34F9,
	AudioManager_StopSound_m564B8B951F14E84B84D1C9F01A82861408CF4B7C,
	AudioManager_PlayMusic_mAA147D259ECFF426B4C57085ED16F2E439D2E922,
	AudioManager__ctor_m9FC47B3998693846C091FB4C3731ACEF0359AC48,
	Inventory_Start_mF9115FBB18A7772CAD4ED60B31A2F128DA55DF83,
	Inventory_UI_ShowInventory_m14E3051640B679BAC61BA3E2DBDBB5D7D3687942,
	Inventory_UI_ShowQuestions_m730D061C35845AB44030E09E8ED12316B7C8848D,
	Inventory_UI_HideQuestions_mFAD436F3DF04C224268A5C0A3274FCFC01225EE6,
	Inventory_UI_HideInventory_m4E6CB6B72B1258F859327663E98914DB874FCB34,
	Inventory__ctor_mB946DCD27224D66DDEE96C7EE8355A7E3FE91CC7,
	Inventory_U3CStartU3Eb__8_0_mDB42A7EF00F5F2BA16572DCD37A703C0C685A701,
	Inventory_U3CStartU3Eb__8_1_m517941B2DEBCC07899B222FBD088456FEBF96413,
	Inventory_U3CUI_ShowInventoryU3Eb__9_0_mAE8CF90C14C3045830D66B12F2AF095252E7B2BD,
	Inventory_U3CUI_ShowQuestionsU3Eb__10_0_m03BF8BC2AEBB7BB1A847168C8E79D625EFBF79BA,
	Inventory_U3CUI_HideQuestionsU3Eb__11_0_m78886BAB1C7A74DCA023C0455743B6D6A6F1E069,
	Inventory_U3CUI_HideInventoryU3Eb__12_0_mE5578E2216F31B280DD8844B8CABBF51C503F11C,
	Billboard_Start_m1AC12D68A41309EF5F07DBFD941B5AC1722FF3C3,
	Billboard_LateUpdate_mFAC2B55D6823DDFE7A9FEDE8A6F76807CEBCE849,
	Billboard__ctor_mE9B96D9746332E7B0C6FC0D2CB9610AA32DF5621,
	BrainData__ctor_mA5D7787A65E4529976F3742CE802023E4F0AC3A7,
	BrainData_Swap_m357BBA4288C852DB75D3B7AF414531E9BD4A8008,
	BrainData_ToString_m1FA7731A7C8B04ACB6C317424023129BB13ACBA5,
	Brain_Awake_m67E7FA9A40D77A58B7F9E524CB964A1F6472DD5B,
	Brain_Start_m3EBEACFA06EEA39DB275B65EC04B70B5D5E9EB9D,
	Brain_Reset_m6CEC3D2DB695244F92D8211DC809BAEB878C895B,
	Brain_Setup_m4A7682D4C51DEA0CE562824B65CDB8ED6B7A60BA,
	Brain_GatherBrainNodes_m56C8C494E6A3302FC5576E327CC23AD8C2A2C8A1,
	Brain_Update_m82EF8196BFA77ACB4B62B214231D088AC22197C7,
	Brain_OnNodeClick_mD70110CAE5913A5828C039A7C008DFEA10255CE5,
	Brain_Show_m477198BBD8D571AF9AE4E18B73A9F1379A0F4611,
	Brain_OnGUI_m856BE03F72378BB24596B7543E54D514FAD211CE,
	Brain_RefreshCursor_m31C49860F8079FBF3CE9484848AAE3BF7571E3B6,
	Brain_ValidateBrain_mABE1E5D2D0ACD1120A7CF5D71A27C1333D9D7EF1,
	Brain_GetFromLabel_mC2C190E70EC9ED0F4DC0EC8B3458504978321E3C,
	Brain_RefreshFromLabel_mDBD567275EEF808F765566B47F7A7E838631EF36,
	Brain_ShowInfoBox_m35E61EFB77C89BDAF67AB768019D96098DE62592,
	Brain_ShowRotateInfo_m902D5DBBE677060A3ACB2FE7DA381BE227CC9BFA,
	Brain__ctor_mC4EBB52ACB4919E67EFEE9D557E62CAF9FE335FE,
	BrainNode_Start_m958FBB01AAD9824AF67BE5923F1862600CA4B94A,
	BrainNode_Init_m3E33A45397AF196726B74D6FB95E2FDA8CB17CE3,
	BrainNode_OnMouseDown_mEA987A92BCCF0581B7A53A099403EA5E703C8944,
	BrainNode_OnMouseEnter_mFD58BE242A4A8FE55A17076F4660151DDF71F50D,
	BrainNode_RightClickReleased_mC5A868B9C6E3538A08E554086064A33245DF3248,
	BrainNode_OnMouseExit_m41D7D8052D1CCFFDE8283ABC0FC576998467EDDA,
	BrainNode_SetEnabled_m9258639CF244ACE898F5F15B53CF551408E107D0,
	BrainNode_SetReadyToSwap_m941A3791170E0850CF2B484CA22CB1A9F57B190E,
	BrainNode_Swap_m4A9B215E5DE0C6B7488D4B350996088D0DA9F373,
	BrainNode_Ping_m671D184B70F08752A6FF8FC0E4673DA2155762C8,
	BrainNode_DoStopPingAfterSeconds_mA75ACA677CA857E79ADB14B2F73B091614D15903,
	BrainNode__ctor_m4317AFD1ED4C9321DBD1E29E463C123BFBF3C646,
	BrainPart_Awake_mF2BDA675856A7197EEEA797B0137F8C479146BAF,
	BrainPart_OnMouseOver_m12436667D25700188B00A5C8826B2BEB2CF71D49,
	BrainPart__ctor_mEF9B87B2C7F5025F0243C9B1A08C02DB56ACBCF4,
	LevelQuestion__ctor_m2CFE5C11AEFF1DB164D13177184C3EB1DF746278,
	LevelBrainNode__ctor_m8E82565EDD3F650AB6959B9AB3FD8E6160B048CB,
	LevelProblem__ctor_m424BDF761C9D63A60921FE913F8F8D642C2E93F0,
	LevelSolution_ValidateBrain_m8C62AEC006E7087578B1C9CA3DBFD3B15E7696C1,
	LevelSolution_ValidateSolution_m5D0ECA7F0CED5442BE9A0C9994042D9780BE317A,
	LevelSolution__ctor_m18B2715214BC0EBF6D0619D7F1A7CCDE344D0665,
	LevelDefinition_GenerateBrainDataList_mA8AD8340ACBE723E4518F8D97840A5F2AFF8D3E4,
	LevelDefinition_FuckUp_m00C45F69C5F1403A753E2D862C3C4373297FE6C4,
	LevelDefinition__ctor_mBF4C9901FBF5805DFA42D9BC9694FF2C6223F18F,
	OrbitCamera_Start_m235E2D4C13DA3B3E9B581596012462CE08075B09,
	OrbitCamera_Update_m170BA9D94A3A8FCF69078EAF9A0E99859742B3D6,
	OrbitCamera_RefresPosition_m52519777DDC9338ADEA86317400C7C38901FDF12,
	OrbitCamera__ctor_mB47F990A2C47EE712316916E1B22D37EAFF5281F,
	QuestionButton_Awake_m63D03FEF74E190021DA752C55D40BCAA37D658B0,
	QuestionButton_Initialized_mF885417DEB9AF51FC23EECB6C5131E15931B10E5,
	QuestionButton_ScaleUp_m59D94C260AEF5D5B3D9D2DEEFC513F6704B877E7,
	QuestionButton__ctor_mAE80962AD92D39892A892D82B57118B9C651A7BB,
	QuestionButton_U3CScaleUpU3Eb__12_0_m55B2C5610D6C34B78442E25B5C3969895B8BE5C5,
	TextDiagnostic_BuildWordList_m2929E4E6917D71A141F59D864280A9E875426B0E,
	TextDiagnostic_GatherBrainData_m25CF469AA26E2F0A5918BAB03CF0C17CF11D80E4,
	TextDiagnostic__ctor_mA10957397DF9343BB0E5410B533FA6AF76598344,
	TextSpeachAnimation_Awake_mDE028C66F82A1B02BE7497E3B4EE6092EFA16A3E,
	TextSpeachAnimation_Start_m55E7755DBEB4BFC8906E7352AE2EB2EF8662BAC5,
	TextSpeachAnimation_ClearLine_mA0E2736647E116C2208AED54CAB939C0857C1878,
	TextSpeachAnimation_SetupLine_m6611A535BFD50FC3C711F17F98B42CE681C2E74A,
	TextSpeachAnimation_Update_mD976A2308F1902D01DD7CE3F28EA141F9C1BD341,
	TextSpeachAnimation_AnimateText_mC9D92E9E4FBFDCF1043770D5B9677B7BB612A6B5,
	TextSpeachAnimation__ctor_mE0D57FD0CBB39F349B34295D3109992DA8B617C0,
	Animate_Awake_m6F54AFC516F73A6168AC5CAFCDABB4B48269F6F1,
	Animate_Play_m5E9E38F7F77BC5642589137EA8D57D99E4B422D3,
	Animate_SpeedUp_m7F6E45A5DA94BCC62B2F3CE4BFA5E05D0912C884,
	Animate_Stop_m11FED75393F017DF0546F578B824BEF827ABD0A0,
	Animate_AnimateSprite_mF00398BF40AABF3D684E8DB51DED52BF3E0B73AC,
	Animate__ctor_m6B80057CA37ACCDE76F37CACC24126FA1E75A01E,
	BootLoader_Start_m5A7CC47839F69FD029B29DAB8E81B9CE7159CE39,
	BootLoader_OnSceneLoaded_m0DCD6FEFB4BEDF43E69B150A1B63E67759E2C640,
	BootLoader_NextLevel_m844FDF74EE2C4CD84293825F37996DDDDF26AFF3,
	BootLoader_EndOfGame_mDF2CF81EE6BC2C31379DDCBCD7D4E77958CC8A7E,
	BootLoader_InstantiateLevelObjects_m9E838FBC05AF4310B200C4F252D930A141FC10A5,
	BootLoader_UI_StartGame_m2C8E372FD6F0EBB03E9C12F9A7399EB897EE1C5A,
	BootLoader_ShowBubbleAfterAFewSeconds_m7967BF066B22A88D44510EC48B53DA518AFC23EF,
	BootLoader_NextLevelAfterAFewSeconds_m2D25553FB9CB245ADFEAAC871590AF482A3138ED,
	BootLoader_ShowSpeech_m42AAB4B82628E2563C09058759FFFB9C7AEDCCF5,
	BootLoader_HideSpeech_mB830D7254ECEED9FC1C16AE02DD36917C8A1849E,
	BootLoader_OnTextComplete_m95EF3798CEF043A8E4916624FC810156059FC07D,
	BootLoader_UI_ShowMenu_mD331D79A4808095F03CEC73F91C22096B4BAB456,
	BootLoader_UI_AskQuestion_m06553E3DA41C8068A63B171FF80A8C893A3427B3,
	BootLoader_UI_TestSolution_m9CBEE76F9EDA12B72564FF563EC7DE91EDD1BF65,
	BootLoader_UI_CloseScreen_m4BDCC045829184900AB823B40131CD577A2301F8,
	BootLoader_Update_m4D5CE00F24B31FB8AC6827BC3CBE89C64542AF20,
	BootLoader_StartGame_m98AC1B88F27E8FF25C2A9B47DE19E0E33E8D5BA8,
	BootLoader__ctor_mF3EC10EA4D8830389CE1A9B976963E689E778EEF,
	BootLoader_U3CUI_StartGameU3Eb__40_0_m3E351451115DC2DDF6D08C23A48D8481801AC763,
	BootLoader_U3CUI_StartGameU3Eb__40_1_m192F75931FF6F07854C8AC04D88B8E37CD83A32D,
	BootLoader_U3CShowSpeechU3Eb__43_0_m57FC470F94FB2909176225934B3489CD97017957,
	BootLoader_U3CHideSpeechU3Eb__44_0_m84EC88C700D7EDCDD14F13E44662831467C74D9C,
	BootLoader_U3CUI_ShowMenuU3Eb__46_1_m140D3238269922659322C9005DBE0A3BB79D7AA9,
	Client_Start_mE6BA86C48F3D3C40438044A472C3565A1A6A85D5,
	Client_Init_m0BA36703D6CCFD8C7BFC50F79D95F8D8CF31BDEB,
	Client_Talk_m0A70DD78A9DA6DE6F4D7464C8D0B01DDCEB3A250,
	Client_Shutup_m5CDBA5667A99D21BE82506FEB4A0502AA15111E1,
	Client_AskQuestion_m3B9FA1333D4C5729FFEEE1C92CD33B34B8A7309A,
	Client__ctor_m3ECF301B53E250235D807DA842698ADC0B7AAE4E,
	Downscale_OnRenderImage_m47623695F461FA94C453DFF541828F64BD217007,
	Downscale__ctor_m9E3D40E03F58753C8B81190185B36EC9A5766CB8,
	Downscale__cctor_m509BAF794616E0E7C963F1EC5919B457F917A6AB,
	FadeInOut_FadeOut_mA8281FDA135801735B68B8D9A08BC7827766CEC5,
	FadeInOut_FadeIn_m3B5206CA5EFD76FB306DCCF5FAEAC99CD2AE8252,
	FadeInOut_Update_m6A4A77E26E6C118589BF3FB10029BF378C0C2F8A,
	FadeInOut__ctor_mD4DACAA2F245971E56842C5141AB3E7CF8AC52E2,
	FadeInOut__cctor_m3E8E31753AF656A9DEB33F3E801BDC359138440A,
	InputManager_Awake_m44B8E66D7CD2B21235B19CDEE94A41DE98F27A57,
	InputManager_RegisterHovering_mE14837E1CA3EF23CA911222114E4FCF7A9A0185D,
	InputManager_UnregisterHovering_mF1E1452AA09E7EA8DB40B56FA7967403665C4597,
	InputManager_RegisterOrUnregisterForHovering_m544B7CC240392A4528AAF7CE70167E9718CD0F5F,
	InputManager_Update_mE33DE68FFB22D0E8C2B866E4B3122F1D645F421A,
	InputManager__ctor_m737855D101985541227BC2D1077149CB836C0360,
	LoadingScreen_Awake_mDE29F3E53E77F10C94EBFDCFFE3AF1481C0F95D5,
	LoadingScreen_Update_m202E092715604392C9D4DE8884259A2B41B09E76,
	LoadingScreen_StartSequences_m00CCC4247D902EE00DD97D40AA87CF52C05B3E19,
	LoadingScreen_ScaleLogo_m106F4C29FB600B46EF332584EBCDDFDB98696D71,
	LoadingScreen_LoadingScreenSequence_mD362D088405D61E74CB8BBD74EE95B1E4C19DB45,
	LoadingScreen_FadeOutThisScene_mF3413F956031CC02A6ECDE82DEC98B8708848D98,
	LoadingScreen_FadeOutInSeconds_m4C517ED72DC9E00423687842108FDEC066E5F03A,
	LoadingScreen__ctor_m3C1C0C2B4E0FD72B27554A19863037EE28C3F0F6,
	LoadingScreen__cctor_m24227D62786888EDF2F209FCD66A5571BA1A35DD,
	LoadingScreen_U3CLoadingScreenSequenceU3Eb__34_0_m4D7DCF684A9D98BC371D6271403489981350474C,
	LoadingScreen_U3CLoadingScreenSequenceU3Eb__34_1_mC5E08DBE998C657ED587D83A0F91257547A0C0B4,
	Menu_UI_MainMenu_m0B1303C3560397BE8DDC9BE58CCCDD10E4543338,
	Menu_UI_StartGame_m8C186A4FC0F787209E99277273620963996C2047,
	Menu_UI_EndofGame_m0472EEBD626E257A4019C74CF7D48EA553D3FDBB,
	Menu_UI_Credits_m639D93DF115AAB966C39661365A49D6834D51C97,
	Menu_UI_Controls_mF289C9AA6EC81FEFE6AB72CE01057103CC58F781,
	Menu__ctor_mD372D109F6554E1F9A25291964C852C9F6BFC463,
	Menu_U3CUI_StartGameU3Eb__11_0_m5EC38BFEB5B97D637CE585136AFDBB193EC222FB,
	Menu_U3CUI_CreditsU3Eb__13_0_m5E215482A8491B365C1EE9BC5F0D99D2A84F62F2,
	OnClickOutside_Awake_m708865BB3F060DFF411792133A324736635931F2,
	OnClickOutside_Update_mD188F2CE672051B3619A8799AFC15DD384A0B4BA,
	OnClickOutside__ctor_m13E20D9702B9F5B6141E8B4EAD5AA85E3B380151,
	SetCameraViewport_Awake_m7DD5D2D4BE3C127E95B941F343C98A4BED2F24A0,
	SetCameraViewport__ctor_mD54CD23F0BBA492E47F2F5F8EE6BD52725EA68CA,
	TextAnimate_get_IsAnimated_m9414B669F37591247B8BB34571DEA3AF117BF47E,
	TextAnimate_set_IsAnimated_mAAEDDF94783AAF9593DE7149C281D4683205F31F,
	TextAnimate_Awake_m40BA367DFA20C965A662AC6C17A6A0A71506FC2E,
	TextAnimate_ClearText_mDCE8248EE96F21EE93C0E26BB59A0EDEC6F647F7,
	TextAnimate_Update_m4F3473AA14E8FCDB622F1A379746165436B95191,
	TextAnimate__ctor_m145BB57E6C2EAF9F042A8621575D4D5888D07B2A,
	Upscale_OnRenderImage_m7451FB94B319B6A3D5385A6D2A2736FB04ADA376,
	Upscale__ctor_mFF5C1C9C2DD39EB1C45960711F496EC4FB705081,
	Upscale__cctor_m2260479F630BD03821A4DEA8589C1777E9593009,
	WorldButton_get_HoverEnabled_mC346EA6E632BACC0272992740EFCEA6D53B23928,
	WorldButton_GetInputManager_mE32338F8ACDD364AE5FF0C8F0AB9ED369494D8CB,
	WorldButton_Awake_m912CF3C5A3B95CA49D0CC037C6F9673A3584738A,
	WorldButton_OnEnable_m85A02BE32814508CCB14A05581DFE956757FCFB5,
	WorldButton_OnDisable_m9689600680827D31C11BFDF40D7576795D009F68,
	WorldButton_Click_m673DE527EC56F558B23632460218B1ADAB75DD63,
	WorldButton_IsHovering_m3FC642F477189C0066BD60D348C01A5B9FC5E553,
	WorldButton__ctor_m80BC75B16A25C4B60C0B6FA53ECAA7967DF1D36A,
	Word__ctor_mA2B34A8AB70451C4840D42321A61BE0B56BA24DB,
	Word__ctor_m1EAB275A01983E759CE2D0540E8BEF25D03CE0D3,
	Word_ExtractLabel_mC15FCEDFFA286AB455926C5D5EF1DB57BC503F55,
	Word_ToString_m096F89ADC63EE4C516E7A620CC3C8C1EF0C072BB,
	WordDisplayText__ctor_mCD293C76EB2CB0FFFD3BF010FEFF5514ADA303F2,
	WordDisplayText_IsFullyDisplayed_m0ABAF83AC80EE62F980787535861FA53B7557364,
	WordDisplayText_ColorFromPrefix_mDB370728617E07B3DBFEE99FE90B07F05E8A3EEA,
	WordDisplayText_Animate_mAA823A66B14F39272566F1447ECADB7B92028B3A,
	WordDisplayText_ShowLastLetter_mACFE94DDAFB351745BBDF7C00DEAD0E29F6638EF,
	WordDisplayText_ShowCharacters_m065899D17E3EF3AD7A18AC3BB2FBD43455014E56,
	WordDisplayText_Refresh_m3A7E250DF38C38E3DF552FCFB449D6388F08B748,
	U3CDoStopPingAfterSecondsU3Ed__26__ctor_m06128F1E46E7AEF2F074A9FAA1FB3CB9695D51C5,
	U3CDoStopPingAfterSecondsU3Ed__26_System_IDisposable_Dispose_m6B7BDC7F98DF704A292AD4278793D0AED5B6C4FF,
	U3CDoStopPingAfterSecondsU3Ed__26_MoveNext_mD62CE0C65EF748AD176808FC26AEF382BC571DA7,
	U3CDoStopPingAfterSecondsU3Ed__26_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mAAE6064EE2453A6A28BCB066E3AEA041D179D805,
	U3CDoStopPingAfterSecondsU3Ed__26_System_Collections_IEnumerator_Reset_m5F84A55D959BC4E441DC3A0799118DD8275E1B08,
	U3CDoStopPingAfterSecondsU3Ed__26_System_Collections_IEnumerator_get_Current_mF9D48A9955EEC6CEF6959245C0BC89DB985312D7,
	U3CAnimateSpriteU3Ed__15__ctor_m879500AFD4E4E9D791F1BADBFB7E1667E66CBD43,
	U3CAnimateSpriteU3Ed__15_System_IDisposable_Dispose_m750CC30682602F2B7C6EF037E84BBCCE406EA59E,
	U3CAnimateSpriteU3Ed__15_MoveNext_mA9E3297C2E0D8F368295FE6B2E98CFE24DCB1D1C,
	U3CAnimateSpriteU3Ed__15_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8373DFDD65DCFDA2865050D9BDCDE260731EE21C,
	U3CAnimateSpriteU3Ed__15_System_Collections_IEnumerator_Reset_m528F213AD3FA98DD6775CB7365880C09E3FC6533,
	U3CAnimateSpriteU3Ed__15_System_Collections_IEnumerator_get_Current_mEE4CBF87C9521AF0A12BD5B75822866E5BDC3F12,
	U3CShowBubbleAfterAFewSecondsU3Ed__41__ctor_mC92B4DC11DF2C637E1D6526E5E7F5F89867510A9,
	U3CShowBubbleAfterAFewSecondsU3Ed__41_System_IDisposable_Dispose_m3D652CADFC1B52B6ECCEF28A5DFAE23176AC95E9,
	U3CShowBubbleAfterAFewSecondsU3Ed__41_MoveNext_mFF2DA34337B6ADC4ED2EF395FE3D227CC8BF9D7C,
	U3CShowBubbleAfterAFewSecondsU3Ed__41_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC15030673C7A6E0DB40AFF28D7F35AC40929B7AC,
	U3CShowBubbleAfterAFewSecondsU3Ed__41_System_Collections_IEnumerator_Reset_mC0923D767368CFADB163AE119494093EE5D90551,
	U3CShowBubbleAfterAFewSecondsU3Ed__41_System_Collections_IEnumerator_get_Current_mB01BA0439E6D7BDEF334BA95C81388E02521B2E5,
	U3CNextLevelAfterAFewSecondsU3Ed__42__ctor_m9DFE3155B80A81DC0ADACDC397ABBE23767EAE94,
	U3CNextLevelAfterAFewSecondsU3Ed__42_System_IDisposable_Dispose_mE0C6A193102C0D2A094BD5BAA8824E4CDEA96214,
	U3CNextLevelAfterAFewSecondsU3Ed__42_MoveNext_mD8601CC12AB3C4EADBA3EA9CA106F4A50F3C7C55,
	U3CNextLevelAfterAFewSecondsU3Ed__42_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5CCBEFBFB319109BDAAF0167681BB3259AB40564,
	U3CNextLevelAfterAFewSecondsU3Ed__42_System_Collections_IEnumerator_Reset_mD934BEEC265453647D7E8542B970B807F2BA18DF,
	U3CNextLevelAfterAFewSecondsU3Ed__42_System_Collections_IEnumerator_get_Current_m6C9D8D133DEB7D9BCC1A75F686F35A63A7E8C46E,
	U3CU3Ec__cctor_mC272616B5BCCC257601C3AB8662C3B9B874DEB94,
	U3CU3Ec__ctor_mB7A616D84F40ED805A4B9DCEDA91C1A17D28A20E,
	U3CU3Ec_U3CHideSpeechU3Eb__44_1_mE08CD7F49730AFC93A2635106AE461B849B85D79,
	U3CU3Ec_U3COnTextCompleteU3Eb__45_0_m0F4C35E4C0E3370BCA1B5DFCEC9C06471937AF9D,
	U3CU3Ec_U3CUI_ShowMenuU3Eb__46_0_m14A778F98E47EA84A9B806309C1FD014B4A787D6,
	U3CScaleLogoU3Ed__33__ctor_m3B94C7AFA02F179EB9F46E6E5E14C966CB09D479,
	U3CScaleLogoU3Ed__33_System_IDisposable_Dispose_m907D546BFD602C423B19E0CA3E72C3FD4978F7F8,
	U3CScaleLogoU3Ed__33_MoveNext_mDFA4AF78E280A18170BE767F97AA48D418867653,
	U3CScaleLogoU3Ed__33_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m25D039FE2F6F2333995AB1B3A5D72A40A66F5565,
	U3CScaleLogoU3Ed__33_System_Collections_IEnumerator_Reset_m0583159CCA875C7B1EFB1E73C432CB6E8C8D71FB,
	U3CScaleLogoU3Ed__33_System_Collections_IEnumerator_get_Current_mFECE9CA26B8B74D72711F2A11F38F0CB71DED116,
	U3CLoadingScreenSequenceU3Ed__34__ctor_mA3C109F7C7106F666FF56735CC57B3B2880E6009,
	U3CLoadingScreenSequenceU3Ed__34_System_IDisposable_Dispose_m85ED26BFB68957B0D0D5FCE1355C80B0DEFB8EAE,
	U3CLoadingScreenSequenceU3Ed__34_MoveNext_m8E9D6E683B62B9B980F6ED1799B4C9EB5C1A3CC7,
	U3CLoadingScreenSequenceU3Ed__34_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0DF1293A07FBF1198442060DA87366F3C336A2A4,
	U3CLoadingScreenSequenceU3Ed__34_System_Collections_IEnumerator_Reset_mFD7D3672EDA3AF30AC576F00DC0812ED6557B9EB,
	U3CLoadingScreenSequenceU3Ed__34_System_Collections_IEnumerator_get_Current_m9FC8465B59B14D75397F7FDAE5D3826F098EE79D,
	U3CU3Ec__cctor_m3800B55D196E21565F6AFD81F0F5D02ADB63D2B9,
	U3CU3Ec__ctor_mFE3BF264A0FD7756D7E8964846EA1BA6B58BD6CB,
	U3CU3Ec_U3CUI_CreditsU3Eb__13_1_m6B9041AB7455F1BC2AF6D66B19C4716F0968C084,
};
static const int32_t s_InvokerIndices[226] = 
{
	586,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	14,
	23,
	23,
	23,
	26,
	26,
	23,
	26,
	31,
	23,
	23,
	9,
	28,
	582,
	624,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	31,
	31,
	26,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	9,
	9,
	23,
	14,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	290,
	23,
	14,
	23,
	23,
	1867,
	31,
	23,
	23,
	23,
	1529,
	1529,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	31,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	27,
	23,
	23,
	32,
	23,
	27,
	23,
	3,
	23,
	23,
	23,
	23,
	3,
	23,
	23,
	23,
	31,
	23,
	23,
	23,
	23,
	23,
	14,
	14,
	26,
	23,
	23,
	3,
	114,
	114,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	114,
	31,
	23,
	23,
	23,
	23,
	27,
	23,
	3,
	114,
	23,
	23,
	23,
	23,
	114,
	31,
	23,
	26,
	26,
	23,
	14,
	682,
	114,
	14,
	14,
	14,
	14,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	3,
	23,
	26,
	26,
	26,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	3,
	23,
	23,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	226,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
