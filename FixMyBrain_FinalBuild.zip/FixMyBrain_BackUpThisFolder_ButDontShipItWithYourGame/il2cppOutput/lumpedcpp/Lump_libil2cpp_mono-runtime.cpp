#include "il2cpp-config.h"
#include "D:\Programs\2019.3.0f6\Editor\Data\il2cpp\libil2cpp\mono-runtime\il2cpp-callbacks.cpp"
#include "D:\Programs\2019.3.0f6\Editor\Data\il2cpp\libil2cpp\mono-runtime\il2cpp-mono-support.cpp"
